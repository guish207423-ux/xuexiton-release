﻿# ============================================================
#  在线更新（Windows）：从 deploy.env 的 UPDATE_FEED 检查最新版并应用
#  由 在线更新.bat 调用；也可直接右键「使用 PowerShell 运行」。
# ============================================================
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# 找 deploy 目录（脚本所在目录，或它的 deploy 子目录）
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Test-Path (Join-Path $here 'deploy\panel.py')) { $Deploy = Join-Path $here 'deploy' }
elseif (Test-Path (Join-Path $here 'panel.py')) { $Deploy = $here }
else { Write-Host '找不到 deploy 目录。请把本脚本放在 deploy 文件夹里（或旁边）再运行。'; exit 1 }

# 读 deploy.env 的 UPDATE_FEED（环境变量优先其次）
$feed = $env:UPDATE_FEED
$envFile = Join-Path $Deploy 'deploy.env'
if (Test-Path $envFile) {
    foreach ($line in Get-Content -LiteralPath $envFile) {
        if ($line -match '^\s*UPDATE_FEED\s*=\s*(\S.*?)\s*$') { $feed = $Matches[1] }
    }
}
if (-not $feed) {
    # 内置默认更新源（无需在 deploy.env 配置即可用）
    $feed = 'https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json'
    Write-Host '（未在 deploy.env 配置 UPDATE_FEED，使用内置默认更新源）'
}

Write-Host "== 检查最新版本: $feed"
try { $info = Invoke-RestMethod -Uri $feed -TimeoutSec 30 }
catch { Write-Host '!! 检查更新失败（网络不通或地址不对）。可改用「收到文件后双击 更新.bat」方式。'; exit 1 }

$cur = '?'
$verFile = Join-Path $Deploy 'VERSION'
if (Test-Path $verFile) { $cur = (Get-Content -LiteralPath $verFile -First 1).Trim() }
Write-Host "   最新: $($info.version)    当前: $cur"
if ($info.notes) { Write-Host "   说明: $($info.notes)" }
if ($info.version -eq $cur) { Write-Host '== 已是最新版本，无需更新。'; exit 0 }
if (-not $info.url) { Write-Host '!! 版本清单里没有 url 字段'; exit 1 }

$tmp = Join-Path $env:TEMP ("xuexiton-online-" + (Get-Random))
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
$zip = Join-Path $tmp 'u.zip'
Write-Host "== 下载: $($info.url)"
try { Invoke-WebRequest -Uri $info.url -OutFile $zip -UseBasicParsing -TimeoutSec 180 }
catch { Write-Host '!! 下载失败（网络问题）。可让对方直接传更新包，双击 更新.bat 应用。'; exit 1 }

if ($info.sha256) {
    $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLower()
    if ($got -ne $info.sha256.ToLower()) { Write-Host '!! SHA256 校验失败，已中止，什么都没改。'; exit 1 }
    Write-Host '== SHA256 校验通过'
}

# 应用（复用 应用更新.bat）
$apply = Join-Path $Deploy '应用更新.bat'
if (-not (Test-Path $apply)) { Write-Host "没找到 应用更新.bat，请手动解压应用: $zip"; exit 1 }
& $apply $zip
if ($LASTEXITCODE -ne 0) { Write-Host '!! 应用更新失败，请检查上面的输出。'; exit 1 }
exit 0
