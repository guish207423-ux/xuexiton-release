#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""题库桥接服务（默认端口 8002）

把两个本地题库统一成浏览器用户脚本能识别的返回格式：
  POST /search  {question, type, options, key}
    → 命中:   {"code":1,"data":{"answer":"B"}}
    → 未命中: {"code":0,"msg":"未找到"}

  POST /adapter-service/search   (原生 tikuAdapter 格式，命令行版 CLI 用)
    → 命中:   {"answer":{"bestAnswer":["B"],...}}
    → 未命中: {"answer":{"bestAnswer":[],...}}

查询顺序:
  ① chaoxing-toolkit 题库   POST http://127.0.0.1:8001/api/search   (命中时 code == -1)
  ② tikuAdapter 聚合题库    POST http://127.0.0.1:8060/adapter-service/search

只依赖 Python 标准库。端口与上游地址可用环境变量覆盖:
  PORT(默认8002) / TIKU_PORT(8001) / ADAPTER_PORT(8060)
"""
import json
import os
import sys
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("PORT", "8002"))
TIKU = "http://127.0.0.1:%s" % os.environ.get("TIKU_PORT", "8001")
ADAPTER = "http://127.0.0.1:%s" % os.environ.get("ADAPTER_PORT", "8060")
_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # 绕过系统代理


def _post(url, payload, timeout):
    req = urllib.request.Request(url, json.dumps(payload).encode(),
                                 {"Content-Type": "application/json"})
    with _opener.open(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def query(payload):
    # ① 本地题库（chaoxing-toolkit）: 命中时 code == -1
    #    注意：8001 的 Pydantic 模型要求 type 为字符串（"0"），用户脚本传整数需转换
    try:
        p = dict(payload)
        p["type"] = str(p.get("type") or "0")
        d = _post(TIKU + "/api/search", p, 3)
        if d.get("code") == -1 and (d.get("data") or {}).get("answer"):
            return {"code": 1, "data": {"answer": d["data"]["answer"]}}
    except Exception:
        pass
    # ② 聚合题库（tikuAdapter）— 必须带 ?use=local 才查本地题库
    try:
        p = dict(payload)
        p["type"] = int(p.get("type") or 0)
        a = (_post(ADAPTER + "/adapter-service/search?use=local", p, 5).get("answer") or {})
        text = a.get("answerKeyText") or a.get("answerText")
        if text:
            return {"code": 1, "data": {"answer": text}}
    except Exception:
        pass
    return {"code": 0, "msg": "未找到"}


def native(payload):
    """原生 tikuAdapter 返回格式（命令行版 chaoxing CLI 的 TikuAdapter provider）"""
    p = dict(payload)
    p.setdefault("key", "")
    if isinstance(p.get("type"), int):
        p["type"] = str(p["type"])
    r = query(p)
    ans = (r.get("data") or {}).get("answer") if r.get("code") == 1 else None
    return {
        "plat": "local-bridge",
        "question": p.get("question", ""),
        "options": p.get("options", []),
        "type": p.get("type", 0),
        "answer": {
            "answerKey": "",
            "answerKeyText": "",
            "answerIndex": "",
            "answerText": ans or "",
            "bestAnswer": [ans] if ans else [],
            "allAnswer": [ans] if ans else [],
        },
    }


class Handler(BaseHTTPRequestHandler):
    def _send(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send({"code": 1, "msg": "bridge ok"})

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.end_headers()

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            payload = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            payload = {}
        if self.path.rstrip("/") == "/adapter-service/search":
            self._send(native(payload))
        else:
            self._send(query(payload))

    def log_message(self, format, *args):  # noqa: A002 (与标准库签名一致)
        pass


def _selfcheck():
    global _post
    orig = _post
    # ① 8001 命中（type 转字符串后应成功）
    _post = lambda url, payload, timeout: {"code": -1, "data": {"answer": "B"}} if TIKU in url else {}
    assert query({}) == {"code": 1, "data": {"answer": "B"}}
    assert query({"type": 0}) == {"code": 1, "data": {"answer": "B"}}  # 整数 type 也能命中
    # ② 8001 未命中，回退到 8060（带 ?use=local）
    _post = lambda url, payload, timeout: {"code": 0} if TIKU in url else {"answer": {"answerKeyText": "AC"}}
    assert query({}) == {"code": 1, "data": {"answer": "AC"}}
    # ③ 两边都未命中
    _post = lambda url, payload, timeout: {"code": 0}
    assert query({})["code"] == 0
    # ④ 原生格式（native）命中
    _post = lambda url, payload, timeout: {"code": -1, "data": {"answer": "B"}} if TIKU in url else {}
    assert native({"question": "q", "type": 0})["answer"]["bestAnswer"] == ["B"]
    assert native({"question": "q", "type": 0})["answer"]["answerText"] == "B"
    _post = orig
    print("selfcheck ok")


if __name__ == "__main__":
    if "--selfcheck" in sys.argv:
        _selfcheck()
    else:
        print("bridge on 0.0.0.0:%d  (tiku=%s adapter=%s)" % (PORT, TIKU, ADAPTER))
        ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
