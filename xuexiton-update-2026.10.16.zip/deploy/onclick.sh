#!/usr/bin/env bash
# 学习通本地套件一键管理（Linux）
# 用法: ./onclick.sh start|stop [服务名...] | status | check | browser | run | panel
set -u
cd "$(dirname "$0")"

# ---------- 配置（可复制 deploy.env.example 为 deploy.env 覆盖） ----------
[ -f deploy.env ] && . ./deploy.env

LLAMA_BIN="${LLAMA_BIN:-$HOME/llama.cpp/build/bin/llama-server}"
MODEL_PATH="${MODEL_PATH:-$HOME/models/qwen3-4b/Qwen3-4B-Q4_K_M.gguf}"
# gguf 自动归位：默认路径不存在时，扫描常见位置找第一个 .gguf（对齐 Windows 侧逻辑）
if [ ! -f "$MODEL_PATH" ]; then
  for d in "$HOME/models" "$(pwd)" "$(pwd)/models" "$HOME/Downloads"; do
    [ -d "$d" ] || continue
    found="$(find "$d" -maxdepth 3 -name '*.gguf' -type f 2>/dev/null | head -1)"
    if [ -n "$found" ]; then MODEL_PATH="$found"; break; fi
  done
fi
TOOLKIT_DIR="${TOOLKIT_DIR:-$HOME/Projects/chaoxing-lab/chaoxing-toolkit}"
TIKU_ADAPTER_BIN="${TIKU_ADAPTER_BIN:-$HOME/Projects/chaoxing-lab/tiku-run/tikuAdapter}"
TIKU_ADAPTER_DIR="${TIKU_ADAPTER_DIR:-$(dirname "$TIKU_ADAPTER_BIN")}"
LLAMA_PORT="${LLAMA_PORT:-8080}"
TIKU_PORT="${TIKU_PORT:-8001}"
ADAPTER_PORT="${ADAPTER_PORT:-8060}"
BRIDGE_PORT="${BRIDGE_PORT:-8002}"
PANEL_PORT="${PANEL_PORT:-8003}"
LLAMA_NGL="${LLAMA_NGL:-99}"
LLAMA_DEV="${LLAMA_DEV-Vulkan0}"
LLAMA_CTX="${LLAMA_CTX:-4096}"
LOG_DIR="${LOG_DIR:-/tmp/xuexiton-deploy}"
PY="${PY:-python3}"

mkdir -p "$LOG_DIR"

say() { printf '%s\n' "$*"; }
ok()  { curl -sf -m 3 "$1" >/dev/null 2>&1; }   # 需要 2xx
up()  { curl -s  -m 3 "$1" >/dev/null 2>&1; }   # 有响应即可

# 后台启动并写 pid 文件: spawn_bg <名字> <工作目录> <命令...>
spawn_bg() {
  local name="$1" cwd="$2"; shift 2
  if [ ! -d "$cwd" ]; then say "!!  [$name] 目录不存在: $cwd"; return 1; fi
  "$PY" - "$LOG_DIR/$name.log" "$LOG_DIR/$name.pid" "$cwd" "$@" <<'EOF'
import subprocess, sys
log, pidfile, cwd, cmd = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:]
p = subprocess.Popen(cmd, cwd=cwd, stdin=subprocess.DEVNULL,
                     stdout=open(log, "ab"), stderr=subprocess.STDOUT,
                     start_new_session=True, close_fds=True)
open(pidfile, "w").write(str(p.pid))
EOF
}

# 等待 URL 就绪: wait_ok <名字> <url> [次数]
wait_ok() {
  local name="$1" url="$2" i
  local tries="${3:-40}" total=$(( ${3:-40} * 5 ))
  for i in $(seq 1 "$tries"); do
    if ok "$url"; then
      [ "$i" -le 1 ] && say "OK  [$name] 就绪" || say "OK  [$name] 就绪（用时约 $((i*5))s）"
      return 0
    fi
    [ $((i % 2)) -eq 0 ] && say "  ...[$name] 启动中（$((i*5))s/${total}s，日志: $LOG_DIR/$name.log）"
    sleep 5
  done
  say "!!  [$name] 等待超时（日志: $LOG_DIR/$name.log）"; return 1
}

stop_one() {
  local name="$1" f="$LOG_DIR/$1.pid" pid
  if [ ! -f "$f" ]; then say "跳过 [$name]（未由本脚本启动）"; return 0; fi
  pid="$(cat "$f")"
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null
    for _ in 1 2 3 4 5; do kill -0 "$pid" 2>/dev/null || break; sleep 1; done
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
    say "已停止 [$name] (pid $pid)"
  else
    say "跳过 [$name]（进程已退出）"
  fi
  rm -f "$f"
}

# 服务名过滤：无参数=全部；支持 llama→llama-server、adapter→tikuAdapter 别名
wants() {
  local w="$1"; shift
  [ "$#" -eq 0 ] && return 0
  local s; for s in "$@"; do [ "$s" = "$w" ] && return 0; done
  return 1
}

start() {
  local sel=() a
  for a in "$@"; do
    case "$a" in llama) a=llama-server ;; adapter) a=tikuAdapter ;; esac
    sel+=("$a")
  done

  # 直接从外置盘运行？警告并默认拒绝（数据会写外置盘、无法安全弹出）
  local _onusb=0
  case "$(findmnt -no FSTYPE -T . 2>/dev/null || true)" in
    vfat|exfat|ntfs|ntfs3|msdos|iso9660|udf) _onusb=1 ;;
    *) case "$(pwd)" in /run/media/*|/media/*) _onusb=1 ;; esac ;;
  esac
  if [ "$_onusb" = 1 ]; then
      say "!!  注意：你正在直接从 U 盘/外置盘运行本工具（$(pwd)）。"
      say "    账号、进度、日志等数据会写进 U 盘，并且 U 盘将无法安全弹出。"
      say "    正确做法：在 U 盘根目录运行  bash 安装.sh（Windows 双击 安装.bat），"
      say "    装好后从桌面 xuexiton/deploy 启动。"
      if [ -t 0 ]; then
        read -r -p "  仍要从 U 盘临时运行？[y/N] " a
        case "$a" in y|Y|yes|YES) ;; *) say "  已退出。"; return 0 ;; esac
      elif [ -z "${XUEXITON_FORCE:-}" ]; then
        say "  （非交互模式：已停止。确定要从 U 盘运行请设置 XUEXITON_FORCE=1）"
        return 0
      fi
  fi

  # 1) AI 模型 llama-server
  if wants llama-server "${sel[@]}"; then
  if ok "http://127.0.0.1:$LLAMA_PORT/health"; then
    say "跳过 AI 模型（已在运行 :$LLAMA_PORT）"
  elif [ -x "$LLAMA_BIN" ] && [ -f "$MODEL_PATH" ]; then
    say "启动 AI 模型 llama-server（首次加载模型约 1-3 分钟）..."
    local dev=(); [ -n "$LLAMA_DEV" ] && dev=(-dev "$LLAMA_DEV")
    spawn_bg llama-server "$HOME" "$LLAMA_BIN" -m "$MODEL_PATH" \
      -ngl "$LLAMA_NGL" "${dev[@]}" -c "$LLAMA_CTX" --parallel 1 \
      -n 1024 --temp 0.7 --top-p 0.95 --top-k 20 --reasoning off \
      --host 127.0.0.1 --port "$LLAMA_PORT" --no-webui
    wait_ok llama-server "http://127.0.0.1:$LLAMA_PORT/health" 40 || true
  else
    say "!!  跳过 AI 模型：找不到 $LLAMA_BIN 或模型 $MODEL_PATH"
    say "    （复制 deploy.env.example 为 deploy.env 后修改路径）"
  fi
  fi

  # 2) 本地题库 Web 管理后台（chaoxing-toolkit）
  if wants tiku "${sel[@]}"; then
  if up "http://127.0.0.1:$TIKU_PORT/"; then
    say "跳过 题库后台（已在运行 :$TIKU_PORT）"
  elif [ -f "$TOOLKIT_DIR/tiku/main.py" ]; then
    # 题库后台前端未构建（static/index.html 缺失）时自动构建（需要 Node/npm）
    if [ ! -f "$TOOLKIT_DIR/tiku/static/index.html" ] && [ -d "$TOOLKIT_DIR/tiku/frontend" ]; then
      if command -v npm >/dev/null 2>&1; then
        say "首次准备：构建题库后台前端（约 1 分钟，日志 $LOG_DIR/tiku-build.log）..."
        if ( cd "$TOOLKIT_DIR/tiku/frontend" && npm install --no-audit --no-fund && npm run build && mkdir -p ../static && cp -r dist/* ../static/ ) >>"$LOG_DIR/tiku-build.log" 2>&1; then
          say "题库后台前端构建完成"
        else
          say "!!  题库后台前端构建失败（日志 $LOG_DIR/tiku-build.log），后台页可能显示构建提示"
        fi
      else
        say "!!  题库后台前端未构建且未装 Node/npm；后台页可能显示构建提示（不影响其他功能）"
      fi
    fi
    local venv="$TOOLKIT_DIR/tiku/.venv"
    if [ ! -x "$venv/bin/python" ]; then
      say "初始化题库服务 venv ..."
      "$PY" -m venv "$venv" && "$venv/bin/pip" install -q -r "$TOOLKIT_DIR/tiku/requirements.txt"
    fi
    say "启动 题库后台 :$TIKU_PORT ..."
    ( export PORT="$TIKU_PORT"; spawn_bg tiku "$TOOLKIT_DIR/tiku" "$venv/bin/python" main.py )
    wait_ok tiku "http://127.0.0.1:$TIKU_PORT/" 12 || true
  else
    say "跳过 题库后台（未找到 $TOOLKIT_DIR/tiku/main.py）"
  fi
  fi

  # 3) 聚合题库 tikuAdapter（可选）
  if wants tikuAdapter "${sel[@]}"; then
  if up "http://127.0.0.1:$ADAPTER_PORT/"; then
    say "跳过 tikuAdapter（已在运行 :$ADAPTER_PORT）"
  elif [ -x "$TIKU_ADAPTER_BIN" ]; then
    say "启动 tikuAdapter :$ADAPTER_PORT ..."
    spawn_bg tikuAdapter "$TIKU_ADAPTER_DIR" "./$(basename "$TIKU_ADAPTER_BIN")"
    wait_ok tikuAdapter "http://127.0.0.1:$ADAPTER_PORT/" 6 || true
  else
    say "跳过 tikuAdapter（未找到 $TIKU_ADAPTER_BIN，可选组件）"
  fi
  fi

  # 4) 题库桥接（把 ①② 统一成用户脚本格式）
  if wants bridge "${sel[@]}"; then
  if up "http://127.0.0.1:$BRIDGE_PORT/"; then
    say "跳过 题库桥接（已在运行 :$BRIDGE_PORT）"
  else
    say "启动 题库桥接 :$BRIDGE_PORT ..."
    ( export PORT="$BRIDGE_PORT" TIKU_PORT ADAPTER_PORT
      spawn_bg bridge "$(pwd)" "$PY" bridge.py )
    wait_ok bridge "http://127.0.0.1:$BRIDGE_PORT/" 6 || true
  fi
  fi

  # 5) 管理控制台 panel
  if wants panel "${sel[@]}"; then
  if up "http://127.0.0.1:$PANEL_PORT/"; then
    say "跳过 管理控制台（已在运行 :$PANEL_PORT）"
  else
    say "启动 管理控制台 :$PANEL_PORT ..."
    ( export PORT="$PANEL_PORT"; spawn_bg panel "$(pwd)" "$PY" panel.py "$PANEL_PORT" )
    wait_ok panel "http://127.0.0.1:$PANEL_PORT/" 4 || true
  fi
  fi

  [ ${#sel[@]} -eq 0 ] || { say "已处理: ${sel[*]}"; return 0; }

  say ""
  say "================= 就绪情况 ================="
  ok "http://127.0.0.1:$LLAMA_PORT/health" && say "AI 模型      : http://127.0.0.1:$LLAMA_PORT/v1/chat/completions"
  up "http://127.0.0.1:$TIKU_PORT/"        && say "题库管理后台 : http://127.0.0.1:$TIKU_PORT/  （浏览器打开）"
  up "http://127.0.0.1:$ADAPTER_PORT/"     && say "聚合题库页   : http://127.0.0.1:$ADAPTER_PORT/  （浏览器打开）"
  up "http://127.0.0.1:$BRIDGE_PORT/"      && say "题库桥接     : http://127.0.0.1:$BRIDGE_PORT/search"
  up "http://127.0.0.1:$PANEL_PORT/"       && say "管理控制台   : http://127.0.0.1:$PANEL_PORT/  （浏览器打开）"
  # Docker 刷课镜像状态（命令行版参考）
  if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    if docker image inspect chaoxing:local >/dev/null 2>&1; then
      say "Docker 镜像  : 已就绪（命令行刷课可用）"
    else
      say "Docker 镜像  : 未导入（首次命令行刷课自动导入，或先跑 ./onclick.sh docker）"
    fi
  fi
  say ""
  say "打开专用浏览器（免装油猴，登录一次免重复登录）: ./onclick.sh browser"
  say "面板（右下角）里填："
  say "  自定义题库地址 = http://127.0.0.1:$BRIDGE_PORT/search"
  say "  AI API 地址    = http://127.0.0.1:$LLAMA_PORT/v1/chat/completions"
  say "  AI 模型名称    = bonsai（任意非空）  AI 密钥 = local（任意非空）"
  say ""
  say "命令行版（可选，不用浏览器）: ./onclick.sh run   （按提示填账号/课程后自动开刷）"
  say "管理控制台（多账号/课程/速率）: ./onclick.sh panel   （浏览器打开 http://127.0.0.1:$PANEL_PORT/）"
  say "日志: $LOG_DIR"
  # 自动打开管理控制台（图形环境）
  open_panel
}

browser() {
  local bin="" prof="${XXT_PROFILE:-$HOME/.xuexiton-browser}" ext="$(pwd)/browser-ext"
  for c in chromium chromium-browser google-chrome google-chrome-stable microsoft-edge-stable microsoft-edge; do
    if command -v "$c" >/dev/null 2>&1; then bin="$c"; break; fi
  done
  if [ -z "$bin" ]; then say "!!  未找到 Chromium / Chrome / Edge，请先安装一个浏览器"; return 1; fi
  if [ ! -f "$ext/bundle.js" ]; then say "!!  browser-ext/bundle.js 缺失（扩展未构建）"; return 1; fi
  say "启动专用浏览器（首次登录学习通即可；数据目录: $prof，下次免重复登录）..."
  setsid nohup "$bin" --user-data-dir="$prof" --load-extension="$ext" --disable-extensions-except="$ext" \
    --no-first-run --no-default-browser-check "https://i.chaoxing.com" >/dev/null 2>&1 &
  say "已启动：登录后进入课程页，右下角出现脚本面板（面板配置见 ./onclick.sh start 的输出）。"
}

run() {
  local cfg="$(pwd)/config.ini" cookies="$(pwd)/cookies.txt"
  if ! command -v docker >/dev/null 2>&1; then
    say "!!  未检测到 Docker（命令行版需要）。Linux 安装 docker；Windows 装 Docker Desktop。"
    say "    （也可以改用浏览器版: ./onclick.sh browser）"
    return 1
  fi
  # 自动部署镜像：①已有 → 跳过；②本地 tar.gz → docker load；③源码目录 → docker build
  if docker image inspect chaoxing:local >/dev/null 2>&1; then
    say "  [OK] Docker 镜像已在（chaoxing:local）"
  else
    local loaded=0 tb
    for tb in "$(pwd)/docker/chaoxing-local.tar.gz" "$(pwd)/../docker/chaoxing-local.tar.gz"; do
      if [ -f "$tb" ]; then
        say "  导入 Docker 镜像（$tb；约 1-2 分钟）..."
        if gzip -dc "$tb" | docker load >/dev/null 2>&1; then loaded=1; break; fi
        say "   导入失败，尝试其他方式..."
      fi
    done
    if [ "$loaded" = 0 ]; then
      if [ -f "$(pwd)/chaoxing/Dockerfile" ]; then
        say "  构建 Docker 镜像 chaoxing:local（首次约 2-5 分钟，需联网）..."
        docker build -t chaoxing:local "$(pwd)/chaoxing" || { say "!!  Docker 镜像构建失败"; return 1; }
      else
        say "!!  没有可用镜像：既无 docker/chaoxing-local.tar.gz，也无 chaoxing/ 源码目录"
        say "    （重插 U 盘重新安装，或联网后手动: cd chaoxing && docker build -t chaoxing:local .）"
        return 1
      fi
    fi
    say "  [OK] Docker 镜像已就绪"
  fi
  [ -f "$cfg" ] || { say "!!  缺少 config.ini"; return 1; }

  local username password courses courses_input=""
  IFS=$'\t' read -r username password courses < <("$PY" - "$cfg" <<'PY'
import sys
d = {}
for line in open(sys.argv[1], encoding="utf-8"):
    s = line.strip()
    if not s or s[0] in ";#[" or "=" not in s:
        continue
    k, v = s.split("=", 1)
    d[k.strip()] = v.strip()
print(d.get("username", ""), d.get("password", ""), d.get("course_list", ""), sep="\t")
PY
)

  say ""
  say "===== 命令行版：填账号开始刷课 ====="
  if [ "$username" = "unused" ] || [ "$username" = "xxx" ] || [ -z "$username" ]; then
    printf "学习通手机号/账号（= 你自己学校的账号，工具不提供）: "
    read -r username
  else
    say "账号: $username（已保存；换账号请编辑 config.ini）"
  fi
  if [ "$password" = "unused" ] || [ "$password" = "xxx" ] || [ -z "$password" ]; then
    printf "密码: "
    read -r -s password; printf "\n"
  fi
  if [ -z "$username" ] || [ -z "$password" ]; then say "!!  账号/密码不能为空"; return 1; fi
  printf "课程ID（逗号分隔；不知道直接回车 → 运行后列出课程让你选）: "
  read -r courses_input
  [ -n "$courses_input" ] && courses="$courses_input"

  "$PY" - "$cfg" "$username" "$password" "$courses" <<'PY'
import sys
cfg = sys.argv[1]
user, pw, courses = sys.argv[2], sys.argv[3], sys.argv[4]
out = []
for line in open(cfg, encoding="utf-8").read().split("\n"):
    s = line.strip()
    if s.startswith("username"): line = "username = " + user
    elif s.startswith("password"): line = "password = " + pw
    elif s.startswith("course_list"): line = "course_list = " + courses
    out.append(line)
open(cfg, "w", encoding="utf-8").write("\n".join(out))
PY

  start

  touch "$cookies"
  say ""
  say "启动刷课容器（登录成功后 cookies 自动保存，下次免重复登录）..."
  local it=(); [ -z "$courses" ] && it=(-it)
  docker run --rm "${it[@]}" --network host \
    -v "$cfg:/config/config.ini" -v "$cookies:/app/cookies.txt" chaoxing:local
  say "运行结束。"
}

open_panel() {
  if up "http://127.0.0.1:$PANEL_PORT/"; then
    if command -v xdg-open >/dev/null 2>&1 && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
      ( setsid xdg-open "http://127.0.0.1:$PANEL_PORT/" >/dev/null 2>&1 & )
      say "已在浏览器打开管理控制台: http://127.0.0.1:$PANEL_PORT/"
    else
      say "管理控制台: http://127.0.0.1:$PANEL_PORT/  （浏览器打开）"
    fi
  else
    say "（管理控制台未就绪，稍后可手动打开 http://127.0.0.1:$PANEL_PORT/）"
  fi
}

panel() {
  # start 已包含全部服务（含管理控制台）与「自动打开控制台」逻辑
  start
}

stop() {
  local sel=() a s
  for a in "$@"; do
    case "$a" in llama) a=llama-server ;; adapter) a=tikuAdapter ;; esac
    sel+=("$a")
  done
  for s in panel bridge tikuAdapter tiku llama-server; do
    wants "$s" "${sel[@]}" && stop_one "$s"
  done
}

status() {
  if ok "http://127.0.0.1:$LLAMA_PORT/health"; then say "llama-server :$LLAMA_PORT  运行中"; else say "llama-server :$LLAMA_PORT  未运行"; fi
  if up "http://127.0.0.1:$TIKU_PORT/"; then say "题库后台     :$TIKU_PORT  运行中"; else say "题库后台     :$TIKU_PORT  未运行"; fi
  if up "http://127.0.0.1:$ADAPTER_PORT/"; then say "tikuAdapter  :$ADAPTER_PORT  运行中"; else say "tikuAdapter  :$ADAPTER_PORT  未运行"; fi
  if up "http://127.0.0.1:$BRIDGE_PORT/"; then say "题库桥接     :$BRIDGE_PORT  运行中"; else say "题库桥接     :$BRIDGE_PORT  未运行"; fi
  if up "http://127.0.0.1:$PANEL_PORT/"; then say "管理控制台   :$PANEL_PORT  运行中"; else say "管理控制台   :$PANEL_PORT  未运行"; fi
}

check() {
  local miss=0
  say "== 依赖自检（换新电脑先跑这个） =="
  for c in bash "$PY" curl; do
    if command -v "$c" >/dev/null 2>&1; then say "  [必需] $c             OK"; else say "  [必需] $c             缺失"; miss=1; fi
  done
  if [ -x "$LLAMA_BIN" ]; then say "  [AI  ] llama-server    OK  ($LLAMA_BIN)"; else say "  [AI  ] llama-server    缺失 → $LLAMA_BIN（纯题库模式可无视）"; fi
  if [ -f "$MODEL_PATH" ]; then say "  [AI  ] 模型文件        OK  ($MODEL_PATH)"; else say "  [AI  ] 模型文件        缺失 → $MODEL_PATH（纯题库模式可无视）"; fi
  if [ -f "$TOOLKIT_DIR/tiku/main.py" ]; then say "  [题库] 本地题库后台    OK  ($TOOLKIT_DIR)"; else say "  [题库] 本地题库后台    缺失 → $TOOLKIT_DIR（不存在则启动时跳过该服务）"; fi
  if [ -x "$TIKU_ADAPTER_BIN" ]; then say "  [聚合] tikuAdapter     OK  ($TIKU_ADAPTER_BIN)"; else say "  [聚合] tikuAdapter     缺失 → $TIKU_ADAPTER_BIN（可选，跳过）"; fi
  if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then say "  [选装] docker          OK"; else say "  [选装] docker          不可用（仅命令行版 run 需要）"; fi
  if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    if docker image inspect chaoxing:local >/dev/null 2>&1; then
      say "  [选装] 镜像 chaoxing:local  OK"
    elif [ -f docker/chaoxing-local.tar.gz ] || { [ -f chaoxing/Dockerfile ] && [ -d chaoxing ]; }; then
      say "  [选装] 镜像 chaoxing:local  未导入（首次 run 自动导入/构建）"
    else
      say "  [选装] 镜像 chaoxing:local  未找到（无镜像包也无源码，命令行版不可用）"
    fi
  fi
  if command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1; then say "  [选装] node/npm        OK"; else say "  [选装] node/npm        缺失（仅题库后台前端「首次构建」需要）"; fi
  if command -v chromium >/dev/null 2>&1 || command -v chromium-browser >/dev/null 2>&1 || command -v google-chrome >/dev/null 2>&1; then say "  [选装] 浏览器          OK"; else say "  [选装] 浏览器          未找到 chromium/chrome（browser 子命令需要）"; fi
  if [ -d console-dist ]; then say "  [控制] 控制台已构建    OK  (console-dist/)"; else say "  [控制] 控制台未构建    缺失 → 在 console/ 运行: npm install && npm run build"; fi
  say ""
  say "== 配置 =="
  if [ -f deploy.env ]; then say "  deploy.env  已存在（覆盖默认配置）"; else say "  deploy.env  未使用（当前用 deploy.env.example 的默认值）；改路径: cp deploy.env.example deploy.env 再编辑"; fi
  say ""
  say "== 端口 =="
  local p
  for p in "$LLAMA_PORT" "$TIKU_PORT" "$ADAPTER_PORT" "$BRIDGE_PORT" "$PANEL_PORT"; do
    if ss -ltn 2>/dev/null | grep -q ":$p "; then say "  :$p  已监听"; else say "  :$p  空闲"; fi
  done
  say ""
  if [ "$miss" -eq 1 ]; then say "自检：缺少必需组件，请先补齐（见 README-一键部署.md 第二节）"; return 1; fi
  say "自检：必需组件就绪。缺失的可选组件，其服务启动时会自动跳过，纯 AI / 纯题库模式仍可用。"
}

docker_prep() {
  command -v docker >/dev/null 2>&1 || { say "未检测到 Docker（仅命令行自动刷课需要它）"; return 1; }
  docker info >/dev/null 2>&1 || { say "Docker 守护进程未运行，请先启动 Docker 再试"; return 1; }
  if docker image inspect chaoxing:local >/dev/null 2>&1; then
    say "[OK] 刷课镜像 chaoxing:local 已就绪"
    return 0
  fi
  if [ -f docker/chaoxing-local.tar.gz ]; then
    say "正在导入刷课镜像（约 1-2 分钟，下方为加载进度）..."
    if docker load -i docker/chaoxing-local.tar.gz; then say "[OK] 导入完成"; return 0; fi
    say "[!!] 导入失败"
  fi
  if [ -f chaoxing/Dockerfile ]; then
    say "从源码构建镜像（约 2-5 分钟，需联网）..."
    if docker build -t chaoxing:local chaoxing; then say "[OK] 构建完成"; return 0; fi
    say "[!!] 构建失败"
  fi
  say "[!!] 既没有镜像文件也没有源码目录"
  return 1
}

case "${1:-start}" in
  start)  [ $# -gt 0 ] && shift; start "$@" ;;
  stop)   [ $# -gt 0 ] && shift; stop "$@" ;;
  status)  status ;;
  check)  check ;;
  browser) browser ;;
  run)    run ;;
  panel)  panel ;;
  docker) docker_prep ;;
  *) say "用法: $0 start|stop [服务名...] | status | check | browser | run | panel | docker" ;;
esac
