#!/usr/bin/env bash
# ============================================================
# 在线更新 deploy 程序文件（保留账号/配置等私有数据）
#
# 用法:
#   ./update.sh --latest             # 从 UPDATE_FEED 检查并更新到最新版（推荐）
#   ./update.sh                      # deploy.env 里有 UPDATE_FEED 就走最新版；否则用 UPDATE_URL
#   ./update.sh https://.../x.zip    # 指定下载地址
#   ./update.sh /path/to/x.zip       # 本地 zip 文件
#
# deploy.env 可配置:
#   UPDATE_FEED=https://cdn.jsdelivr.net/gh/用户名/仓库@main/latest.json
#   UPDATE_URL=https://.../x.zip     # 固定包直链（无 feed 时用）
#
# 安全设计:
#   - 只覆盖程序文件；accounts.json / cookies / config.ini / deploy.env /
#     tasks.json 等私有文件永不被触碰（rsync 不带 --delete + 显式排除）
#   - 更新前自动备份当前程序到 备份-更新前-时间戳/
#   - feed 提供 sha256 时自动校验；版本相同自动跳过
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

[ -f deploy.env ] && . ./deploy.env

ARG="${1:-}"
FEED=""
SHA_EXPECT=""
NOTES=""

case "$ARG" in
  --latest) FEED="${UPDATE_FEED:-}" ;;
  "")       [ -n "${UPDATE_FEED:-}" ] && FEED="$UPDATE_FEED" || true ;;
esac

if [ -n "$FEED" ]; then
  echo "== 检查最新版本: $FEED"
  INFO="$(python3 - "$FEED" 2>/dev/null <<'PYEOF' || true
import json, sys, urllib.request
from urllib.parse import urljoin
req = urllib.request.Request(sys.argv[1], headers={'User-Agent': 'xuexiton-update/1.0'})
with urllib.request.urlopen(req, timeout=25) as r:
    d = json.load(r)
url = str(d.get('url', '') or '')
if url and not url.startswith(('http://', 'https://')):
    url = urljoin(sys.argv[1], url)
print('\t'.join([str(d.get('version', '?')), url, str(d.get('sha256', '') or ''),
                 str(d.get('notes', '') or '').replace('\t', ' ').replace('\n', ' ')]))
PYEOF
)"
  if [ -z "$INFO" ]; then
    echo "!! 检查更新失败（网络不通或 feed 地址不对）"
    echo "   若持续失败，可改用「直接传文件」方式更新：把新 zip 发给对方按本地方式应用"
    exit 1
  fi
  IFS=$'\t' read -r VER_NEW URL SHA_EXPECT NOTES <<<"$INFO"
  VER_CUR="$(cat VERSION 2>/dev/null || echo '?')"
  echo "   最新: $VER_NEW    当前: $VER_CUR"
  [ -n "$NOTES" ] && echo "   说明: $NOTES"
  if [ "$VER_NEW" = "$VER_CUR" ]; then
    echo "== 已是最新版本，无需更新。"
    exit 0
  fi
  [ -n "$URL" ] || { echo "!! feed 中缺少 url 字段"; exit 1; }
else
  URL="${ARG:-${UPDATE_URL:-}}"
fi

if [ -z "$URL" ]; then
  echo "用法:"
  echo "  ./update.sh --latest            # 检查并更新到最新版（需在 deploy.env 配置 UPDATE_FEED）"
  echo "  ./update.sh <更新包地址或本地zip>"
  echo "  （也可以先在 deploy.env 里设置 UPDATE_FEED 或 UPDATE_URL）"
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "== 获取更新包: $URL"
case "$URL" in
  http://*|https://*)
    curl -fL --retry 2 --connect-timeout 15 -o "$TMP/u.zip" "$URL" || {
      echo "!! 下载失败。若为 GitHub 直链，国内网络可能不稳定，换用其他分发方式（网盘直链/对方发文件）。"
      exit 1
    } ;;
  file://*)
    python3 - "$URL" "$TMP/u.zip" <<'PYEOF'
import shutil, sys, urllib.request
with urllib.request.urlopen(sys.argv[1], timeout=25) as r, open(sys.argv[2], 'wb') as f:
    shutil.copyfileobj(r, f)
PYEOF
    ;;
  *)
    [ -f "$URL" ] || { echo "!! 找不到文件: $URL"; exit 1; }
    cp -f "$URL" "$TMP/u.zip" ;;
esac

# SHA256 校验（feed 提供时）
if [ -n "$SHA_EXPECT" ]; then
  GOT="$(sha256sum "$TMP/u.zip" | cut -d' ' -f1)"
  if [ "$GOT" != "$SHA_EXPECT" ]; then
    echo "!! SHA256 校验失败（下载不完整或文件被改动），已中止，什么都没改"
    echo "   期望: $SHA_EXPECT"
    echo "   实际: $GOT"
    exit 1
  fi
  echo "== SHA256 校验通过"
fi

# 解压（优先 unzip，没有则用 python3；两者本机与对方机至少有一个）
if command -v unzip >/dev/null 2>&1; then
  unzip -q "$TMP/u.zip" -d "$TMP/x"
else
  python3 - "$TMP/u.zip" "$TMP/x" <<'PYEOF'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    z.extractall(sys.argv[2])
PYEOF
fi
SRC="$TMP/x/deploy"
[ -d "$SRC" ] || SRC="$TMP/x"
[ -f "$SRC/panel.py" ] || { echo "!! 更新包结构不对（缺 panel.py），已中止，什么都没改"; exit 1; }

# 更新前备份当前程序（只备份程序文件，快，几 MB）
BK="备份-更新前-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
rsync -a --exclude '备份-更新前-*' --exclude 'deploy.env' --exclude 'config*.ini' \
      --exclude 'accounts.json*' --exclude 'cookies*.txt' \
      --exclude 'tasks.json*' --exclude 'events.json' --exclude 'settings.json' \
      --exclude 'harvest*.json' --exclude 'signwatch.json' --exclude 'cache*.json' \
      --exclude '__pycache__' ./ "$BK/" 2>/dev/null || true
echo "== 已备份当前程序到: $BK/（若更新出问题，把里面的文件拷回来即可）"

# 覆盖程序文件（排除私有文件，绝不 --delete）
rsync -a \
  --exclude 'accounts.json*' --exclude 'cookies*.txt' --exclude 'config.ini' \
  --exclude 'config.run.*' --exclude 'deploy.env' --exclude 'tasks.json*' \
  --exclude 'events.json' --exclude 'settings.json' --exclude 'harvest*.json' \
  --exclude 'signwatch.json' --exclude 'cache*.json' --exclude '__pycache__/' \
  --exclude '备份-更新前-*' \
  "$SRC/" ./

VER="$(cat VERSION 2>/dev/null || echo '?')"
# 确保关键脚本保持可执行
chmod +x onclick.sh update.sh 2>/dev/null || true
echo ""
echo "================ 更新完成 ================"
echo "当前版本: $VER"
echo "如果服务正在运行，请重启:"
echo "   ./onclick.sh stop && ./onclick.sh start"
echo "（或控制台里逐个重启；浏览器刷新一次页面即可用上新版界面）"
