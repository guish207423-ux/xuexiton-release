@echo off
chcp 65001 >nul
rem ============================================================
rem  在线更新（Windows）：从 deploy.env 的 UPDATE_FEED 检查最新版并应用
rem  双击运行即可。首次使用前在 deploy.env 里配置：
rem    UPDATE_FEED=https://cdn.jsdelivr.net/gh/xxx/latest.json
rem ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0在线更新.ps1"
echo.
pause
