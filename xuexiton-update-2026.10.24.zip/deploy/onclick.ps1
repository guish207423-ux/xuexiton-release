﻿param([string]$Action = "start", [string]$Service = "")
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

# ---------- 配置（deploy.env 可覆盖） ----------
$cfg = @{}
if (Test-Path "deploy.env") {
  foreach ($line in Get-Content "deploy.env" -Encoding UTF8) {
    $t = $line.Trim()
    if ($t -eq "" -or $t.StartsWith("#")) { continue }
    $i = $t.IndexOf("=")
    if ($i -gt 0) {
      $k = $t.Substring(0, $i).Trim()
      $v = $t.Substring($i + 1).Trim().Trim('"')
      $v = $v.Replace('$HOME', $env:USERPROFILE)
      $cfg[$k] = $v
    }
  }
}

function CfgVal([string]$k, [string]$d) {
  if ($cfg.ContainsKey($k) -and $cfg[$k] -ne "") { return $cfg[$k] }
  return $d
}

# 服务过滤：onclick.ps1 start [服务名] / stop [服务名]（供控制台守护与切模型重启使用）
function Want([string]$name) {
  if ($Service -eq "") { return $true }
  $alias = @{ "llama" = "llama-server"; "adapter" = "tikuAdapter" }
  $s = $Service
  if ($alias.ContainsKey($s)) { $s = $alias[$s] }
  return ($s -eq $name)
}

$LlamaBin = CfgVal "LLAMA_BIN" ""
if (-not $LlamaBin) {
  foreach ($c in @("$PSScriptRoot\llama-server.exe", "$env:USERPROFILE\llama.cpp\build\bin\llama-server.exe", "$env:USERPROFILE\llama.cpp\llama-server.exe")) {
    if (Test-Path $c) { $LlamaBin = $c; break }
  }
}
$ModelPath = CfgVal "MODEL_PATH" ""
if (-not $ModelPath) { $ModelPath = "$env:USERPROFILE\models\qwen3-4b\Qwen3-4B-Q4_K_M.gguf" }
# gguf 自动归位：默认路径不存在时，扫描常见位置找第一个 .gguf
if (-not (Test-Path $ModelPath)) {
  foreach ($md in @("$env:USERPROFILE\models", $PSScriptRoot, (Join-Path $PSScriptRoot "models"), "$env:USERPROFILE\Downloads")) {
    if (-not (Test-Path $md)) { continue }
    $g = Get-ChildItem $md -Recurse -Filter *.gguf -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($g) { $ModelPath = $g.FullName; break }
  }
}
$ToolkitDir = CfgVal "TOOLKIT_DIR" "$env:USERPROFILE\Projects\chaoxing-lab\chaoxing-toolkit"
$AdapterBin = CfgVal "TIKU_ADAPTER_BIN" "$env:USERPROFILE\Projects\chaoxing-lab\tiku-run\tikuAdapter.exe"
$AdapterDir = CfgVal "TIKU_ADAPTER_DIR" (Split-Path $AdapterBin)
$LlamaPort   = [int](CfgVal "LLAMA_PORT" "8080")
$TikuPort    = [int](CfgVal "TIKU_PORT" "8001")
$AdapterPort = [int](CfgVal "ADAPTER_PORT" "8060")
$BridgePort  = [int](CfgVal "BRIDGE_PORT" "8002")
$PanelPort   = [int](CfgVal "PANEL_PORT" "8003")
$LlamaNgl    = CfgVal "LLAMA_NGL" "99"
$LlamaDev    = if ($cfg.ContainsKey("LLAMA_DEV")) { $cfg["LLAMA_DEV"] } else { "Vulkan0" }
$LlamaCtx    = CfgVal "LLAMA_CTX" "4096"
$LogDir      = CfgVal "LOG_DIR" "$env:TEMP\xuexiton-deploy"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$PyCmd = if (Get-Command python -ErrorAction SilentlyContinue) { "python" } else { "py" }

# ---------- 工具函数 ----------
function TestOk([string]$url) {
  try {
    $r = Invoke-WebRequest -Uri $url -TimeoutSec 3 -UseBasicParsing
    return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300)
  } catch { return $false }
}
function TestOkPat([string]$url, [string]$pat) {
  try {
    $r = Invoke-WebRequest -Uri $url -TimeoutSec 3 -UseBasicParsing
    return ($r.Content -match [regex]::Escape($pat))
  } catch { return $false }
}
function TestUp([string]$url) {
  try { Invoke-WebRequest -Uri $url -TimeoutSec 3 -UseBasicParsing | Out-Null; return $true }
  catch { return ($null -ne $_.Exception.Response) }
}
function WaitOk([string]$name, [string]$url, [int]$tries = 40, [string]$pat = "") {
  $total = $tries * 5
  for ($i = 1; $i -le $tries; $i++) {
    $readyNow = if ($pat) { TestOkPat $url $pat } else { TestOk $url }
    if ($readyNow) {
      if ($i -le 1) { Write-Host "OK  [$name] 就绪" } else { Write-Host "OK  [$name] 就绪（用时约 $($i*5)s）" }
      return $true
    }
    if ($i % 2 -eq 0) { Write-Host "  ...[$name] 启动中（$($i*5)s/${total}s）" }
    Start-Sleep -Seconds 5
  }
  Write-Host "!!  [$name] 等待超时（${total}s）"
  return $false
}
function SpawnBg([string]$name, [string]$cwd, [string]$exe, [string]$arguments) {
  if (-not (Test-Path $cwd)) { Write-Host "!!  [$name] 目录不存在: $cwd"; return $null }
  $sp = @{
    FilePath = $exe; WorkingDirectory = $cwd; WindowStyle = "Hidden"; PassThru = $true
    RedirectStandardOutput = "$LogDir\$name.out.log"; RedirectStandardError = "$LogDir\$name.err.log"
  }
  if ($arguments) { $sp["ArgumentList"] = $arguments }
  $p = Start-Process @sp
  Set-Content -Path "$LogDir\$name.pid" -Value $p.Id
  return $p
}
function StopOne([string]$name) {
  $pf = "$LogDir\$name.pid"
  if (-not (Test-Path $pf)) { Write-Host "跳过 [$name]（未由本脚本启动）"; return }
  $procId = [int](Get-Content $pf)
  if (Get-Process -Id $procId -ErrorAction SilentlyContinue) {
    Stop-Process -Id $procId -Force
    Write-Host "已停止 [$name] (pid $procId)"
  } else {
    Write-Host "跳过 [$name]（进程已退出）"
  }
  Remove-Item $pf -Force -ErrorAction SilentlyContinue
}

# ---------- start ----------
# 是否从 U 盘（可移动盘）直接运行
function Test-OnUsb {
  if ($PSScriptRoot -match '^([A-Za-z]):') {
    try { return ((Get-Volume -DriveLetter $Matches[1] -ErrorAction Stop).DriveType -eq 'Removable') } catch {}
  }
  return $false
}

function DoStart {
  if (Test-OnUsb) {
    Write-Host "!!  注意：你正在直接从 U 盘运行本工具（$PSScriptRoot）。"
    Write-Host "    账号、进度、日志等数据会写进 U 盘，并且 U 盘将无法安全弹出。"
    Write-Host "    正确做法：运行 U 盘根目录的 安装.bat 装到本机，"
    Write-Host "    再从 桌面\xuexiton\deploy\onclick.bat 启动。"
    $a = ""
    try { $a = Read-Host "  仍要从 U 盘临时运行？(y/N)" } catch { $a = "" }
    if ($a -notin @("y", "Y", "yes", "YES")) { Write-Host "  已退出。"; return }
  }
  # 1) AI 模型 llama-server
  if (Want "llama-server") {
  if (TestOkPat "http://127.0.0.1:$LlamaPort/health" '"status"') {
    Write-Host "跳过 AI 模型（已在运行 :$LlamaPort）"
  } elseif (TestUp "http://127.0.0.1:$LlamaPort/") {
    Write-Host "!!  端口 :$LlamaPort 已被其他程序占用（不是本套件的 AI 模型）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$LlamaPort）"
  } elseif ((Test-Path $LlamaBin) -and (Test-Path $ModelPath)) {
    Write-Host "启动 AI 模型 llama-server（首次加载模型约 1-3 分钟）..."
    $devArg = if ($LlamaDev) { " -dev $LlamaDev" } else { "" }
    $llamaArgs = "-m `"$ModelPath`" -ngl $LlamaNgl -c $LlamaCtx --parallel 1 -n 1024 --temp 0.7 --top-p 0.95 --top-k 20 --reasoning off --host 127.0.0.1 --port $LlamaPort --no-webui$devArg"
    [void](SpawnBg "llama-server" $env:USERPROFILE $LlamaBin $llamaArgs)
    [void](WaitOk "llama-server" "http://127.0.0.1:$LlamaPort/health" 40 '"status"')
  } else {
    Write-Host "!!  跳过 AI 模型：找不到 $LlamaBin 或模型 $ModelPath"
    Write-Host "    （复制 deploy.env.example 为 deploy.env 后修改路径）"
  }
  }

  # 2) 本地题库 Web 管理后台（chaoxing-toolkit）
  if (Want "tiku") {
  if (TestOkPat "http://127.0.0.1:$TikuPort/" '題庫管理') {
    Write-Host "跳过 题库后台（已在运行 :$TikuPort）"
  } elseif (TestUp "http://127.0.0.1:$TikuPort/") {
    Write-Host "!!  端口 :$TikuPort 已被其他程序占用（不是本套件的题库后台）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$TikuPort）"
  } elseif (Test-Path "$ToolkitDir\tiku\main.py") {
    # 题库后台前端未构建（static\index.html 缺失）时自动构建（需要 Node/npm）
    $feDir = "$ToolkitDir\tiku\frontend"
    if ((-not (Test-Path "$ToolkitDir\tiku\static\index.html")) -and (Test-Path $feDir)) {
      if (Get-Command npm -ErrorAction SilentlyContinue) {
        Write-Host "首次准备：构建题库后台前端（约 1 分钟，日志 $LogDir\tiku-build.log）..."
        Push-Location $feDir
        & npm install --no-audit --no-fund *> "$LogDir\tiku-build.log"
        $ok = ($LASTEXITCODE -eq 0)
        if ($ok) { & npm run build *>> "$LogDir\tiku-build.log"; $ok = ($LASTEXITCODE -eq 0) }
        if ($ok) {
          New-Item -ItemType Directory -Force -Path "$ToolkitDir\tiku\static" | Out-Null
          Copy-Item -Recurse -Force "$feDir\dist\*" "$ToolkitDir\tiku\static\"
          Write-Host "题库后台前端构建完成"
        } else {
          Write-Host "!!  题库后台前端构建失败（日志 $LogDir\tiku-build.log），后台页可能显示构建提示"
        }
        Pop-Location
      } else {
        Write-Host "!!  题库后台前端未构建且未装 Node/npm；后台页可能显示构建提示（不影响其他功能）"
      }
    }
    $venvPy = "$ToolkitDir\tiku\.venv\Scripts\python.exe"
    if (-not (Test-Path $venvPy)) {
      Write-Host "初始化题库服务 venv（联网安装依赖，约 1-2 分钟）..."
      & $PyCmd -m venv "$ToolkitDir\tiku\.venv"
      & $venvPy -m pip install -q -r "$ToolkitDir\tiku\requirements.txt"
    }
    Write-Host "启动 题库后台 :$TikuPort ..."
    $env:PORT = "$TikuPort"
    [void](SpawnBg "tiku" "$ToolkitDir\tiku" $venvPy "main.py")
    Remove-Item Env:PORT -ErrorAction SilentlyContinue
    [void](WaitOk "tiku" "http://127.0.0.1:$TikuPort/" 12 '題庫管理')
  } else {
    Write-Host "跳过 题库后台（未找到 $ToolkitDir\tiku\main.py）"
  }
  }

  # 3) 聚合题库 tikuAdapter（可选）
  if (Want "tikuAdapter") {
  if (TestOkPat "http://127.0.0.1:$AdapterPort/" 'chunk-vendors') {
    Write-Host "跳过 tikuAdapter（已在运行 :$AdapterPort）"
  } elseif (TestUp "http://127.0.0.1:$AdapterPort/") {
    Write-Host "!!  端口 :$AdapterPort 已被其他程序占用（不是本套件的聚合题库）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$AdapterPort）"
  } elseif (Test-Path $AdapterBin) {
    Write-Host "启动 tikuAdapter :$AdapterPort ..."
    [void](SpawnBg "tikuAdapter" $AdapterDir $AdapterBin "")
    [void](WaitOk "tikuAdapter" "http://127.0.0.1:$AdapterPort/" 6 'chunk-vendors')
  } else {
    Write-Host "跳过 tikuAdapter（未找到 $AdapterBin，可选组件）"
  }
  }

  # 4) 题库桥接
  if (Want "bridge") {
  if (TestOkPat "http://127.0.0.1:$BridgePort/" 'bridge ok') {
    Write-Host "跳过 题库桥接（已在运行 :$BridgePort）"
  } elseif (TestUp "http://127.0.0.1:$BridgePort/") {
    Write-Host "!!  端口 :$BridgePort 已被其他程序占用（不是本套件的题库桥接）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$BridgePort）"
  } else {
    Write-Host "启动 题库桥接 :$BridgePort ..."
    $env:PORT = "$BridgePort"; $env:TIKU_PORT = "$TikuPort"; $env:ADAPTER_PORT = "$AdapterPort"
    [void](SpawnBg "bridge" $PSScriptRoot $PyCmd "bridge.py")
    Remove-Item Env:PORT, Env:TIKU_PORT, Env:ADAPTER_PORT -ErrorAction SilentlyContinue
    [void](WaitOk "bridge" "http://127.0.0.1:$BridgePort/" 6 'bridge ok')
  }
  }

  # 5) 管理控制台 panel
  if (Want "panel") {
  if (TestOkPat "http://127.0.0.1:$PanelPort/" '刷课控制台') {
    Write-Host "跳过 管理控制台（已在运行 :$PanelPort）"
  } elseif (TestUp "http://127.0.0.1:$PanelPort/") {
    Write-Host "!!  端口 :$PanelPort 已被其他程序占用（不是本套件的管理控制台）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$PanelPort）"
  } else {
    Write-Host "启动 管理控制台 :$PanelPort ..."
    $env:PORT = "$PanelPort"
    [void](SpawnBg "panel" $PSScriptRoot $PyCmd "panel.py $PanelPort")
    Remove-Item Env:PORT -ErrorAction SilentlyContinue
    [void](WaitOk "panel" "http://127.0.0.1:$PanelPort/" 4 '刷课控制台')
  }
  }

  Write-Host ""
  Write-Host "================= 就绪情况 ================="
  if (TestOkPat "http://127.0.0.1:$LlamaPort/health" '"status"') { Write-Host "AI 模型      : http://127.0.0.1:$LlamaPort/v1/chat/completions" }
  if (TestOkPat "http://127.0.0.1:$TikuPort/" '題庫管理') { Write-Host "题库管理后台 : http://127.0.0.1:$TikuPort/  （浏览器打开）" }
  if (TestOkPat "http://127.0.0.1:$AdapterPort/" 'chunk-vendors') { Write-Host "聚合题库页   : http://127.0.0.1:$AdapterPort/  （浏览器打开）" }
  if (TestOkPat "http://127.0.0.1:$BridgePort/" 'bridge ok') { Write-Host "题库桥接     : http://127.0.0.1:$BridgePort/search" }
  if (TestOkPat "http://127.0.0.1:$PanelPort/" '刷课控制台') { Write-Host "管理控制台   : http://127.0.0.1:$PanelPort/  （浏览器打开）" }
  if (Get-Command docker -ErrorAction SilentlyContinue) {
    docker info *> $null
    if ($LASTEXITCODE -eq 0) {
      docker image inspect chaoxing:local *> $null
      if ($LASTEXITCODE -eq 0) { Write-Host "Docker 镜像  : 已就绪（命令行刷课可用）" }
      else { Write-Host "Docker 镜像  : 未导入（首次命令行刷课自动导入，或跑 onclick.bat docker）" }
    }
  }
  Write-Host ""
  Write-Host "打开专用浏览器（免装油猴，登录一次免重复登录）: onclick.bat browser"
  Write-Host "面板（右下角）里填："
  Write-Host "  自定义题库地址 = http://127.0.0.1:$BridgePort/search"
  Write-Host "  AI API 地址    = http://127.0.0.1:$LlamaPort/v1/chat/completions"
  Write-Host "  AI 模型名称    = bonsai（任意非空）  AI 密钥 = local（任意非空）"
  Write-Host ""
  Write-Host "日志: $LogDir"
  Write-Host "命令行开刷（不用浏览器）: onclick.bat run"
  Write-Host "多课程并行（统一管理面板）: onclick.bat panel"
}

# ---------- status ----------
function DoStatus {
  if (TestOkPat "http://127.0.0.1:$LlamaPort/health" '"status"') { Write-Host "llama-server :$LlamaPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$LlamaPort/") { Write-Host "llama-server :$LlamaPort  端口被其他程序占用" }
  else { Write-Host "llama-server :$LlamaPort  未运行" }
  if (TestOkPat "http://127.0.0.1:$TikuPort/" '題庫管理') { Write-Host "题库后台     :$TikuPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$TikuPort/") { Write-Host "题库后台     :$TikuPort  端口被其他程序占用" }
  else { Write-Host "题库后台     :$TikuPort  未运行" }
  if (TestOkPat "http://127.0.0.1:$AdapterPort/" 'chunk-vendors') { Write-Host "tikuAdapter  :$AdapterPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$AdapterPort/") { Write-Host "tikuAdapter  :$AdapterPort  端口被其他程序占用" }
  else { Write-Host "tikuAdapter  :$AdapterPort  未运行" }
  if (TestOkPat "http://127.0.0.1:$BridgePort/" 'bridge ok') { Write-Host "题库桥接     :$BridgePort  运行中" }
  elseif (TestUp "http://127.0.0.1:$BridgePort/") { Write-Host "题库桥接     :$BridgePort  端口被其他程序占用" }
  else { Write-Host "题库桥接     :$BridgePort  未运行" }
  if (TestOkPat "http://127.0.0.1:$PanelPort/" '刷课控制台') { Write-Host "管理控制台   :$PanelPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$PanelPort/") { Write-Host "管理控制台   :$PanelPort  端口被其他程序占用" }
  else { Write-Host "管理控制台   :$PanelPort  未运行" }
}

# ---------- check（依赖自检，换新电脑先跑这个） ----------
function DoCheck {
  Write-Host "== 依赖自检（换新电脑先跑这个） =="
  if (Get-Command python -ErrorAction SilentlyContinue) { Write-Host "  [必需] python          OK" }
  else { Write-Host "  [必需] python          缺失（控制台/桥接需要；安装 Python 3 时请勾选 Add to PATH）" }
  if ($LlamaBin -and (Test-Path $LlamaBin)) { Write-Host "  [AI  ] llama-server    OK  ($LlamaBin)" }
  else { Write-Host "  [AI  ] llama-server    缺失 → $LlamaBin（纯题库模式可无视）" }
  if (Test-Path $ModelPath) { Write-Host "  [AI  ] 模型文件        OK  ($ModelPath)" }
  else { Write-Host "  [AI  ] 模型文件        缺失 → $ModelPath（纯题库模式可无视；缺失时启动会自动扫描常见位置）" }
  if (Test-Path (Join-Path $ToolkitDir "tiku\main.py")) { Write-Host "  [题库] 本地题库后台    OK  ($ToolkitDir)" }
  else { Write-Host "  [题库] 本地题库后台    缺失 → $ToolkitDir（不存在则启动时跳过该服务）" }
  if (Test-Path $AdapterBin) { Write-Host "  [聚合] tikuAdapter     OK  ($AdapterBin)" }
  else { Write-Host "  [聚合] tikuAdapter     缺失 → $AdapterBin（可选，跳过）" }
  if (Get-Command docker -ErrorAction SilentlyContinue) {
    $dok = $false
    try { docker info *> $null; $dok = ($LASTEXITCODE -eq 0) } catch { $dok = $false }
    if ($dok) {
      Write-Host "  [选装] docker          OK"
      $img = $false
      try { docker image inspect chaoxing:local *> $null; $img = ($LASTEXITCODE -eq 0) } catch { $img = $false }
      if ($img) { Write-Host "  [选装] 镜像 chaoxing:local  OK" }
      else { Write-Host "  [选装] 镜像 chaoxing:local  未导入（首次 run 自动导入/构建）" }
    } else { Write-Host "  [选装] docker          已安装但未启动（仅命令行版 run 需要）" }
  } else { Write-Host "  [选装] docker          不可用（仅命令行版 run 需要）" }
  if ((Get-Command node -ErrorAction SilentlyContinue) -and (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Host "  [选装] node/npm        OK"
  } else { Write-Host "  [选装] node/npm        缺失（仅题库后台前端「首次构建」需要）" }
  $chrome = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
  ) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
  if ($chrome) { Write-Host "  [选装] 浏览器          OK  ($chrome)" }
  else { Write-Host "  [选装] 浏览器          未找到 Chrome/Edge（browser 子命令需要）" }
  if (Test-Path (Join-Path $PSScriptRoot "console-dist")) { Write-Host "  [控制] 控制台已构建    OK  (console-dist\)" }
  else { Write-Host "  [控制] 控制台未构建    缺失 → 在 console/ 运行: npm install && npm run build" }
  Write-Host ""
  Write-Host "== 配置 =="
  if (Test-Path "deploy.env") { Write-Host "  deploy.env  已存在（覆盖默认配置）" }
  else { Write-Host "  deploy.env  未使用（当前用默认值）；改路径: 复制 deploy.env.example 为 deploy.env 再编辑" }
}

# ---------- browser（专用浏览器，免装油猴） ----------
function Start-LocalBrowser {
  $ext = Join-Path $PSScriptRoot "browser-ext"
  if (-not (Test-Path (Join-Path $ext "bundle.js"))) { Write-Host "!! browser-ext\bundle.js 缺失（扩展未构建）"; return }
  $prof = Join-Path $env:USERPROFILE ".xuexiton-browser"
  $cands = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
  )
  $bin = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
  if (-not $bin) { Write-Host "!! 未找到 Chrome / Edge，请先安装一个浏览器"; return }
  Write-Host "启动专用浏览器（首次登录学习通即可；数据目录: $prof，下次免重复登录）..."
  Start-Process $bin -ArgumentList "--user-data-dir=`"$prof`"", "--load-extension=`"$ext`"", "--disable-extensions-except=`"$ext`"", "--no-first-run", "--no-default-browser-check", "https://i.chaoxing.com"
  Write-Host "已启动：登录后进入课程页，右下角出现脚本面板。"
}

# ---------- run（命令行版：填账号/课程后自动开刷） ----------
function EnsureImage {
  # 刷课镜像准备：①已有 → 跳过；②本地 tar.gz → docker load；③源码目录 → docker build
  docker image inspect chaoxing:local *> $null
  if ($LASTEXITCODE -eq 0) { return $true }
  $loaded = $false
  $tbs = @((Join-Path $PSScriptRoot "docker\chaoxing-local.tar.gz"), (Join-Path (Split-Path $PSScriptRoot) "docker\chaoxing-local.tar.gz"))
  foreach ($tb in $tbs) {
    if (-not (Test-Path $tb)) { continue }
    Write-Host "  导入 Docker 镜像（约 1-2 分钟，请稍候）..."
    docker load -i "$tb"
    if ($LASTEXITCODE -eq 0) { $loaded = $true; break }
    # tar.gz 直载失败时用系统 tar 解压再载
    $tmpTar = Join-Path $env:TEMP "chaoxing-local.tar"
    tar -xzf "$tb" -C $env:TEMP 2>$null
    if (Test-Path $tmpTar) {
      docker load -i "$tmpTar"
      Remove-Item $tmpTar -ErrorAction SilentlyContinue
      if ($LASTEXITCODE -eq 0) { $loaded = $true; break }
    }
    Write-Host "   导入失败，尝试其他方式..."
  }
  if (-not $loaded) {
    $srcDir = Join-Path $PSScriptRoot "chaoxing"
    if (Test-Path (Join-Path $srcDir "Dockerfile")) {
      Write-Host "  构建 Docker 镜像 chaoxing:local（首次约 2-5 分钟，需联网）..."
      docker build -t chaoxing:local $srcDir
      if ($LASTEXITCODE -ne 0) { Write-Host "!!  Docker 镜像构建失败"; return $false }
    } else {
      Write-Host "!!  没有可用镜像：既无 docker\chaoxing-local.tar.gz，也无 chaoxing\ 源码目录"
      return $false
    }
  }
  Write-Host "  [OK] Docker 镜像已就绪"
  return $true
}

function DoDocker {
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Write-Host "!!  未检测到 Docker（仅命令行自动刷课需要它）"; return }
  docker info *> $null
  if ($LASTEXITCODE -ne 0) { Write-Host "!!  Docker 守护进程未运行，请先启动 Docker Desktop 再试"; return }
  docker image inspect chaoxing:local *> $null
  if ($LASTEXITCODE -eq 0) { Write-Host "[OK] 刷课镜像 chaoxing:local 已就绪"; return }
  [void](EnsureImage)
}

function DoRun {
  $cfgPath = Join-Path $PSScriptRoot "config.ini"
  $cookies = Join-Path $PSScriptRoot "cookies.txt"
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "!!  未检测到 Docker。Windows 可直接用官方 exe 版（见 README 方式 B），或安装 Docker Desktop 后重试。"
    return
  }
  if (-not (EnsureImage)) { return }
  if (-not (Test-Path $cfgPath)) { Write-Host "!!  缺少 config.ini"; return }

  $txt = Get-Content $cfgPath -Encoding UTF8
  $uLine = $txt | Where-Object { $_ -match '^\s*username\s*=' } | Select-Object -First 1
  $pLine = $txt | Where-Object { $_ -match '^\s*password\s*=' } | Select-Object -First 1
  $cLine = $txt | Where-Object { $_ -match '^\s*course_list\s*=' } | Select-Object -First 1
  $user = if ($uLine) { ($uLine -replace '^\s*username\s*=\s*','').Trim() } else { "" }
  $pass = if ($pLine) { ($pLine -replace '^\s*password\s*=\s*','').Trim() } else { "" }
  $courses = if ($cLine) { ($cLine -replace '^\s*course_list\s*=\s*','').Trim() } else { "" }

  Write-Host ""
  Write-Host "===== 命令行版：填账号开始刷课 ====="
  if (-not $user -or $user -eq "unused" -or $user -eq "xxx") { $user = (Read-Host "学习通手机号/账号（= 你自己学校的账号，工具不提供）").Trim() }
  else { Write-Host "账号: $user（已保存；换账号请编辑 config.ini）" }
  if (-not $pass -or $pass -eq "unused" -or $pass -eq "xxx") { $pass = (Read-Host "密码").Trim() }
  if (-not $user -or -not $pass) { Write-Host "!!  账号/密码不能为空"; return }
  $coursesInput = (Read-Host "课程ID（逗号分隔；不知道直接回车 → 运行后列出课程让你选）").Trim()
  if ($coursesInput) { $courses = $coursesInput }

  $newTxt = foreach ($line in $txt) {
    if ($line -match '^\s*username\s*=') { "username = $user" }
    elseif ($line -match '^\s*password\s*=') { "password = $pass" }
    elseif ($line -match '^\s*course_list\s*=') { "course_list = $courses" }
    else { $line }
  }
  [System.IO.File]::WriteAllLines($cfgPath, [string[]]$newTxt)

  DoStart
  if (-not (Test-Path $cookies)) { New-Item -ItemType File -Path $cookies | Out-Null }

  $runCfg = $cfgPath
  $nowTxt = Get-Content $cfgPath -Encoding UTF8
  if ($nowTxt -match 'http://127\.0\.0\.1:') {
    $runCfg = Join-Path $PSScriptRoot "config.docker.ini"
    $swapped = $nowTxt -replace 'http://127\.0\.0\.1:', 'http://host.docker.internal:'
    [System.IO.File]::WriteAllLines($runCfg, [string[]]$swapped)
    Write-Host "（容器内访问本机：本地地址已自动换为 host.docker.internal）"
  }

  Write-Host ""
  Write-Host "启动刷课容器（登录成功后 cookies 自动保存，下次免重复登录）..."
  $dockerArgs = @("run", "--rm", "-v", "${runCfg}:/config/config.ini", "-v", "${cookies}:/app/cookies.txt")
  if (-not $courses) { $dockerArgs += "-it" }
  $dockerArgs += "chaoxing:local"
  & docker @dockerArgs
  if ($runCfg -ne $cfgPath) { Remove-Item $runCfg -ErrorAction SilentlyContinue }  # 临时配置含密码副本，用完即删
  Write-Host "运行结束。"
}

# ---------- panel（多课程并行管理面板） ----------
function OpenPanel {
  if (TestUp "http://127.0.0.1:$PanelPort/") {
    try { Start-Process "http://127.0.0.1:$PanelPort/" | Out-Null } catch {}
    Write-Host "已在浏览器打开管理面板: http://127.0.0.1:$PanelPort/"
  } else {
    Write-Host "（管理面板未就绪，稍后可手动打开 http://127.0.0.1:$PanelPort/）"
  }
}
function DoPanel {
  DoStart
  OpenPanel
}

# ---------- 入口 ----------
function ShowHelp {
  Write-Host "学习通本地套件 · 常用命令"
  Write-Host ""
  Write-Host "  onclick.bat start              启动全部服务并自动打开控制台（最常用）"
  Write-Host "  onclick.bat stop               停止全部服务"
  Write-Host "  onclick.bat status             查看五个服务运行状态"
  Write-Host "  onclick.bat check              依赖自检（换新电脑先跑这个）"
  Write-Host "  onclick.bat browser            打开专用浏览器开刷（免装油猴）"
  Write-Host "  onclick.bat run                命令行版刷课（不用浏览器）"
  Write-Host "  onclick.bat panel              打开管理控制台"
  Write-Host "  onclick.bat docker             检查/导入刷课镜像"
  Write-Host "  onclick.bat start tiku         单独启动某个服务（llama-server/tiku/tikuAdapter/bridge/panel）"
  Write-Host "  onclick.bat stop  tiku         单独停止某个服务"
  Write-Host ""
  Write-Host "  完整文档：本目录 README-一键部署.md ｜ 各版改进：CHANGELOG.md"
}

switch ($Action.ToLower()) {
  "start"   { DoStart; if (-not $Service) { OpenPanel } }
  "stop"    { foreach ($s in @("panel", "bridge", "tikuAdapter", "tiku", "llama-server")) { if (Want $s) { StopOne $s } } }
  "status"  { DoStatus }
  "check"   { DoCheck }
  "browser" { Start-LocalBrowser }
  "run"     { DoRun }
  "panel"   { DoPanel }
  "docker"  { DoDocker }
  "help"    { ShowHelp }
  "h"       { ShowHelp }
  default   { Write-Host "用法: onclick.bat start|stop|status|check|browser|run|panel|docker|help [服务名]" }
}
