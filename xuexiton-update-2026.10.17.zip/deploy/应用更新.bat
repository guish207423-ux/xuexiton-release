@echo off
chcp 65001 >nul
rem ============================================================
rem  应用更新包（核心步骤，由 更新.bat / 在线更新.bat 调用）
rem  用法: 应用更新.bat <zip路径>
rem  退出码: 0 = 成功；1 = 失败
rem  安全: 只覆盖程序文件；accounts.json / cookies / config.ini /
rem        deploy.env / tasks.json 等私有文件永不被触碰。
rem ============================================================
setlocal enabledelayedexpansion
if "%~1"=="" ( echo 用法: 应用更新.bat ^<zip路径^> & exit /b 1 )
if not exist "%~1" ( echo !! 找不到文件: %~1 & exit /b 1 )

if exist "%~dp0deploy\panel.py" ( set "DEPLOY=%~dp0deploy" ) else if exist "%~dp0panel.py" ( set "DEPLOY=%~dp0" ) else (
  echo 找不到 deploy 目录。请把本脚本放在 deploy 文件夹里（或旁边）再运行。
  exit /b 1
)

set "ZIP=%~1"
set "TMP=%TEMP%\xuexiton-apply-%RANDOM%%RANDOM%"
mkdir "%TMP%"

echo == 解压...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Expand-Archive -Force -LiteralPath '%ZIP%' -DestinationPath '%TMP%\x'"
if not exist "%TMP%\x\deploy\panel.py" if not exist "%TMP%\x\panel.py" (
  echo !! 更新包结构不对（缺 panel.py），已中止，什么都没改。
  rmdir /s /q "%TMP%" & exit /b 1
)
if exist "%TMP%\x\deploy\panel.py" ( set "SRC=%TMP%\x\deploy" ) else ( set "SRC=%TMP%\x" )

echo == 备份当前程序...
set "BK=%DEPLOY%\备份-更新前"
if exist "%BK%" rd /s /q "%BK%" 2>nul
if exist "%BK%" rmdir /s /q "%BK%" 2>nul
robocopy "%DEPLOY%" "%BK%" /E /XF accounts.json accounts.json.bak cookies.txt cookies*.txt config.ini config.run.*.ini deploy.env tasks.json tasks.json.bak-smart events.json settings.json harvest.json harvest-quarantine.json signwatch.json cache.json /XD __pycache__ 备份-更新前* /NFL /NDL /NJH /NJS >nul

echo == 覆盖程序文件（私有文件保留）...
robocopy "%SRC%" "%DEPLOY%" /E ^
  /XF accounts.json accounts.json.bak cookies.txt cookies*.txt config.ini config.run.*.ini deploy.env tasks.json tasks.json.bak-smart events.json settings.json harvest.json harvest-quarantine.json signwatch.json cache.json cache.*.json ^
  /XD __pycache__ "备份-更新前" ^
  /NFL /NDL /NJH /NJS >nul
if %ERRORLEVEL% GEQ 8 (
  echo !! 覆盖过程中有错误（robocopy code %ERRORLEVEL%）请检查。
  rmdir /s /q "%TMP%" 2>nul & exit /b 1
)

rem 清理已知的无用运行时残留（白名单；绝不触碰账号/配置等私有数据）
del /f /q "%DEPLOY%\chaoxing.log" "%DEPLOY%\config.docker.ini" "%DEPLOY%\nohup.out" 2>nul
if exist "%DEPLOY%\__pycache__" rd /s /q "%DEPLOY%\__pycache__" 2>nul

rem 更新后自检：关键文件完整性
set "MISS="
for %%F in (panel.py onclick.bat onclick.ps1 bridge.py) do (
  if not exist "%DEPLOY%\%%F" set "MISS=!MISS! %%F"
)
if not "!MISS!"=="" (
  echo !! 警告：更新后缺少关键文件:!MISS!
  echo    备份在 %BK% 中，可把缺的文件拷回来，或重跑一次更新。
  rmdir /s /q "%TMP%" 2>nul & exit /b 1
)

rmdir /s /q "%TMP%" 2>nul
echo.
echo ================ 更新完成 ================
type "%DEPLOY%\VERSION" 2>nul && echo  ^<- 当前版本
echo 如果服务正在运行: 先 onclick.bat stop 再 onclick.bat start（或控制台里重启）
echo 浏览器里 Ctrl+F5 刷新一次即可用上新版界面。
exit /b 0
