#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""刷课控制台 v2 —— 本地统一管理（无需登录）

功能:
    账号管理: 多账号（手机号/密码/备注）；密码仅存本机、界面打码；每账号独立登录缓存
    课程管理: 每账号课程列表；手动添加 / 一键拉取（用该账号登录一次列出全部课程）
    速率设置: speed / jobs / 错题重做 / 未开放章节 / 重试间隔（不用再手改配置文件）
    任务队列: 任务 = 账号 × 课程；同账号串行排队（防风控）、不同账号可并行
    实时日志: 每 3 秒刷新；单任务停止 / 移除 / 清理已完成

用法:
    python3 panel.py [端口]     # 默认 8003
    浏览器打开 http://127.0.0.1:8003/

数据（全部仅存本机 deploy/ 目录）:
    accounts.json            账号（权限 600）
    tasks.json               任务队列
    config.run.<账号>.ini    每账号运行配置（自动生成，源自 config.ini 模板）
    cookies.<账号>.txt       每账号登录缓存（登录成功自动保存）

仅依赖: Python 标准库 + 本机 docker。
"""
import hashlib
import json
import mimetypes
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

HERE = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS = os.path.join(HERE, "accounts.json")
TASKS = os.path.join(HERE, "tasks.json")
CFG_TEMPLATE = os.path.join(HERE, "config.template.ini")
CFG_TEMPLATE_FALLBACK = os.path.join(HERE, "config.ini")


def cfg_template_path():
    """模板文件：优先 config.template.ini（随更新分发）；旧安装回退 config.ini。"""
    if os.path.isfile(CFG_TEMPLATE):
        return CFG_TEMPLATE
    if os.path.isfile(CFG_TEMPLATE_FALLBACK):
        return CFG_TEMPLATE_FALLBACK
    return CFG_TEMPLATE


def cfg_overlay_path():
    """私有覆盖文件（config.ini）：用户改的通知等设置写这里，更新不会覆盖。
    仅当模板就是 config.ini 本身（旧安装）时，避免自覆盖。"""
    if cfg_template_path() == CFG_TEMPLATE_FALLBACK:
        return None  # 旧安装：模板即 config.ini，就地写
    return CFG_TEMPLATE_FALLBACK


def parse_ini_lines(text):
    """把 ini 文本解析成 {(section, key): value}。"""
    out, sec = {}, ""
    for line in text.split("\n"):
        s = line.strip()
        if not s or s.startswith((";", "#")):
            continue
        if s.startswith("[") and s.endswith("]"):
            sec = s[1:-1].strip()
            continue
        if "=" in s:
            k, v = s.split("=", 1)
            out[(sec, k.strip())] = v.strip()
    return out


def apply_ini_overlay(text, overlay):
    """把 overlay 的键值合并进 text（同 section+key 覆盖，其他保持原样）。"""
    lines, sec, changed = [], "", False
    for line in text.split("\n"):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            sec = s[1:-1].strip()
        elif s and not s.startswith((";", "#")) and "=" in s:
            k = s.split("=", 1)[0].strip()
            if (sec, k) in overlay and overlay[(sec, k)] != "":
                indent = line[:len(line) - len(line.lstrip())]
                line = "%s%s = %s" % (indent, k, overlay[(sec, k)])
                changed = True
        lines.append(line)
    return "\n".join(lines)
PORT = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 8003
PREFIX = "xxt-"
IMAGE = "chaoxing:local"
LOCK = threading.RLock()  # 可重入：tick 持锁期间会再调用 add_event 等加锁函数（普通 Lock 会自锁死）

STATUS_CN = {"queued": "排队中", "running": "运行中", "done": "已完成",
             "error": "出错", "stopped": "已停止"}

# 服务/日志/设置相关常量（服务名与 onclick.sh 过滤参数一致）
LOG_DIR = os.environ.get("LOG_DIR", "/tmp/xuexiton-deploy")
CONSOLE_DIST = os.path.join(HERE, "console-dist")
DEPLOY_ENV = os.path.join(HERE, "deploy.env")
ENV_EXAMPLE = os.path.join(HERE, "deploy.env.example")
SERVICES = [
    ("llama-server", "AI 模型", "LLAMA_PORT", "/health"),
    ("tiku", "题库后台", "TIKU_PORT", "/"),
    ("tikuAdapter", "聚合题库", "ADAPTER_PORT", "/"),
    ("bridge", "题库桥接", "BRIDGE_PORT", "/"),
    ("panel", "控制台", "PANEL_PORT", "/"),
]
LOG_SVCS = {s[0] for s in SERVICES}
ENV_KEYS = ["LLAMA_BIN", "MODEL_PATH", "MODELS_DIR", "LOG_DIR", "TOOLKIT_DIR",
            "TIKU_ADAPTER_BIN", "TIKU_ADAPTER_DIR", "LLAMA_PORT",
            "TIKU_PORT", "ADAPTER_PORT", "BRIDGE_PORT", "PANEL_PORT", "LLAMA_NGL",
            "LLAMA_DEV", "LLAMA_CTX"]

SETTINGS_FILE = os.path.join(HERE, "settings.json")
EVENTS_FILE = os.path.join(HERE, "events.json")
SIGNWATCH_FILE = os.path.join(HERE, "signwatch.json")
DEFAULT_SETTINGS = {"smart_retry": True, "max_retries": 3, "watchdog": True, "notify": True}
WATCH_LAST = {}
SIGN_WATCH_LAST = {}  # 签到守护重启速率限制（每账号，避免抖动）


# ---------- 基础工具 ----------

def mask(u):
    if not u:
        return ""
    if len(u) <= 4:
        return "*" * len(u)
    return u[:3] + "****" + u[-2:]


def now_str():
    return time.strftime("%m-%d %H:%M")


def docker(*args, timeout=20):
    try:
        p = subprocess.run(
            ["docker", *args], capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout,
        )
        return p.returncode, p.stdout, p.stderr
    except FileNotFoundError:
        return 127, "", "未检测到 docker"
    except subprocess.TimeoutExpired:
        return 1, "", "docker 命令超时"


def docker_ready():
    rc, _, _ = docker("version", "--format", "{{.Server.Version}}", timeout=10)
    return rc == 0


def ps_names_status():
    """{容器名: 状态描述}（含已退出）。"""
    rc, out, _ = docker("ps", "-a", "--format", "{{.Names}}\t{{.Status}}")
    d = {}
    if rc == 0:
        for line in out.splitlines():
            if "\t" in line:
                n, s = line.split("\t", 1)
                d[n] = s
    return d


def container_logs(name, tail=40):
    rc, out, err = docker("logs", "--tail", str(tail), name)
    return (out + err).strip()


def exit_code(name):
    rc, out, _ = docker("inspect", "-f", "{{.State.ExitCode}}", name, timeout=10)
    try:
        return int(out.strip())
    except (ValueError, TypeError):
        return None


# ---------- 引擎后端：原生（包内 Python）优先，Docker 作为回退 ----------
# 引擎源码随包分发在 deploy/chaoxing/（GPL-3.0，见其 LICENSE）。原生跑法与镜像内
# `python3 main.py -c /config/config.ini` 等价：以"每任务运行目录"为 cwd，
# 把 config/cookies/cache 放进去，退出后回收 cookies 与 cache。
ENGINE_DIR = os.path.join(HERE, "chaoxing")   # 引擎源码（随包分发；依赖在其 _vendor/）
ENGINE_MAIN = os.path.join(ENGINE_DIR, "main.py")
RUNS_DIR = os.path.join(HERE, "runs")
RUNNER = os.path.join(HERE, "_engine_run.py")


def pycmd():
    """包内免安装 Python（Windows: ../py/python.exe）；找不到则退回当前解释器。"""
    cands = []
    env_py = os.environ.get("CHAOXING_PY")  # 高级用法/测试：指定解释器
    if env_py:
        cands.append(env_py)
    if os.name == "nt":
        cands.append(os.path.join(HERE, "..", "py", "python.exe"))
    cands.append(os.path.join(HERE, "..", "py", "bin", "python3"))
    cands.append(sys.executable)
    for c in cands:
        if c and (os.path.isfile(c) or shutil.which(c)):
            return c
    return None


_ENGINE_OK = None   # 探测结果缓存：起子进程不便宜，不能每次 /api/state 都付这个代价


def engine_ready():
    """原生引擎是否可用：引擎源码 + Python + 依赖真能导入（跑一次 `main.py -h` 就够验完）。

    只看文件存在会骗人：依赖随包分发在 chaoxing/_vendor（Windows）或 chaoxing/_vendor_linux
    （其它平台），缺了照样选原生，然后每次启动都在 import 处崩，还把面板状态显示成「引擎正常」。
    """
    global _ENGINE_OK
    if _ENGINE_OK is None:
        _ENGINE_OK = bool(pycmd()) and os.path.isfile(ENGINE_MAIN)
        if _ENGINE_OK:
            try:
                p = subprocess.run([pycmd(), ENGINE_MAIN, "-h"], cwd=ENGINE_DIR,
                                   capture_output=True, timeout=90, env=engine_env())
                _ENGINE_OK = p.returncode == 0
            except (OSError, subprocess.SubprocessError):
                _ENGINE_OK = False
    return _ENGINE_OK


def engine_backend():
    """当前生效的后端：native / docker / None。

    原生引擎优先（这正是去掉 Docker 硬依赖的目的）：Windows 用 chaoxing/_vendor，
    非 Windows 用 chaoxing/_vendor_linux（两个平台的依赖分开随包分发）。Docker 仅作回退。
    """
    if engine_ready():
        return "native"
    if docker_ready():
        return "docker"
    return None


def engine_env():
    """引擎运行环境：把 engine/_vendor 挂到 PYTHONPATH（依赖随包分发，离线可用）。"""
    env = dict(os.environ)
    v = os.path.join(ENGINE_DIR, "_vendor" if os.name == "nt" else "_vendor_linux")
    if os.path.isdir(v):
        prev = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = (prev + os.pathsep + v) if prev else v   # 追加：不遮蔽已有依赖
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    return env


def _rundir(name):
    d = os.path.join(RUNS_DIR, name)
    os.makedirs(d, exist_ok=True)
    return d


def _pid_alive(pidfile):
    try:
        pid = int(open(pidfile, encoding="utf-8").read().strip())
    except (OSError, ValueError):
        return False, None
    try:
        if os.name == "nt":
            out = subprocess.run(["tasklist", "/FI", "PID eq %d" % pid], capture_output=True,
                                 text=True, encoding="utf-8", errors="replace", timeout=15).stdout
            return (str(pid) in out), pid
        os.kill(pid, 0)
        return True, pid
    except (OSError, subprocess.SubprocessError):
        return False, pid


def engine_syncback(name, cookies=None, cache=None):
    """把运行目录里的 cookies/cache 收回 deploy/（登录态与题库缓存要跨任务保留）。"""
    d = os.path.join(RUNS_DIR, name)
    for src_name, dst in (("cookies.txt", cookies), ("cache.json", cache)):
        s = os.path.join(d, src_name)
        if dst and os.path.isfile(s) and os.path.getsize(s) > 0:
            try:
                shutil.copyfile(s, dst)
            except OSError:
                pass


def engine_start(name, cfg, cookies, cache=None, args=(), detach=True, timeout=600):
    """启动引擎（等价于 docker run）。返回 (rc, out, err)。"""
    if engine_backend() == "native":
        d = _rundir(name)
        shutil.copyfile(cfg, os.path.join(d, "config.ini"))
        for s, t in ((cookies, "cookies.txt"), (cache, "cache.json")):
            dst = os.path.join(d, t)
            if s and os.path.isfile(s) and os.path.getsize(s) > 0:
                shutil.copyfile(s, dst)
            else:
                open(dst, "a").close()
        cfg_in = os.path.join(d, "config.ini")
        if detach:
            open(os.path.join(d, "stdout.log"), "ab").close()
            rcfile = os.path.join(d, "rc")
            if os.path.isfile(rcfile):
                os.remove(rcfile)
            cmd = [pycmd(), RUNNER, ENGINE_MAIN, cfg_in, rcfile, *args]
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = 0x00000008 | 0x00000200  # DETACHED_PROCESS|NEW_PROCESS_GROUP
            else:
                kw["start_new_session"] = True
            try:
                p = subprocess.Popen(cmd, cwd=d, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL, **kw)
            except OSError as e:
                return 1, "", "启动失败: %s" % e
            time.sleep(0.6)
            return 0, "", ""
        try:
            p = subprocess.run([pycmd(), ENGINE_MAIN, "-c", cfg_in, *args], cwd=d,
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=timeout, env=engine_env())
            return p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired:
            return 1, "", "运行超时"
        except OSError as e:
            return 1, "", "启动失败: %s" % e
    # ---- Docker 回退 ----
    net = [] if os.name == "nt" else ["--network", "host"]
    vols = ["-v", cfg + ":/config/config.ini", "-v", cookies + ":/app/cookies.txt"]
    if cache:
        vols += ["-v", cache + ":/app/cache.json"]
    if detach:
        docker("rm", "-f", name, timeout=30)
        return docker("run", "-d", "--name", name, *net, *vols, IMAGE, *args, timeout=60)
    try:
        p = subprocess.run(["docker", "run", "--rm", *net, *vols, IMAGE, *args],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 1, "", "拉取超时（4 分钟）。可改用手动添加课程ID。"
    except FileNotFoundError:
        return 1, "", "未检测到 docker"


def engine_stop(name, cookies=None, cache=None):
    """停止并移除引擎进程（等价于 docker stop + rm -f）。"""
    if engine_backend() == "native":
        d = os.path.join(RUNS_DIR, name)
        alive, pid = _pid_alive(os.path.join(d, "pid"))
        if alive and pid:
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                                   capture_output=True, timeout=20)
                else:
                    os.killpg(os.getpgid(pid), 15)
                    time.sleep(0.8)
                    if _pid_alive(os.path.join(d, "pid"))[0]:
                        os.killpg(os.getpgid(pid), 9)
            except (OSError, subprocess.SubprocessError):
                pass
        time.sleep(0.3)
        engine_syncback(name, cookies, cache)
        return 0, "", ""
    docker("stop", name, timeout=30)
    docker("rm", "-f", name, timeout=20)
    return 0, "", ""


def engine_status():
    """{名称: 状态描述}，语义对齐 docker ps -a（含已退出）。"""
    if engine_backend() == "native":
        out = {}
        if os.path.isdir(RUNS_DIR):
            for n in sorted(os.listdir(RUNS_DIR)):
                d = os.path.join(RUNS_DIR, n)
                if not os.path.isdir(d):
                    continue
                alive, _ = _pid_alive(os.path.join(d, "pid"))
                if alive:
                    out[n] = "Up"
                else:
                    rc = None
                    try:
                        rc = int(open(os.path.join(d, "rc"), encoding="utf-8").read().strip())
                    except (OSError, ValueError):
                        pass
                    out[n] = "Exited (%s)" % ("?" if rc is None else rc)
        return out
    return ps_names_status()


def engine_logs(name, tail=40):
    """引擎输出末尾若干行（等价于 docker logs --tail N）。"""
    if engine_backend() == "native":
        p = os.path.join(RUNS_DIR, name, "stdout.log")
        try:
            data = open(p, encoding="utf-8", errors="replace").read()
        except OSError:
            return ""
        return "\n".join(data.splitlines()[-tail:]).strip()
    return container_logs(name, tail)


def engine_exit_code(name):
    """引擎退出码（等价于 docker inspect .State.ExitCode）。"""
    if engine_backend() == "native":
        try:
            return int(open(os.path.join(RUNS_DIR, name, "rc"), encoding="utf-8").read().strip())
        except (OSError, ValueError):
            return None
    return exit_code(name)



# ---------- 数据层 ----------

def _load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _save(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
    if os.name != "nt":
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass


def load_accounts():
    return _load(ACCOUNTS, [])


def save_accounts(a):
    _save(ACCOUNTS, a)


def load_tasks():
    return _load(TASKS, [])


def save_tasks(t):
    _save(TASKS, t)


def find_account(accounts, aid):
    for a in accounts:
        if a["id"] == aid:
            return a
    return None


def upsert_account(data):
    """保存或更新账号；密码留空 = 保持原样。"""
    name = str(data.get("name") or "").strip()
    username = str(data.get("username") or "").strip()
    password = str(data.get("password") or "")
    if not name:
        return False, "请填写账号名称"
    if not username:
        return False, "请填写学习通手机号/账号"
    aid = str(data.get("id") or "").strip()
    accounts = load_accounts()
    acc = find_account(accounts, aid) if aid else None
    is_new = acc is None
    if is_new:
        if not password:
            return False, "新账号必须填写密码"
        acc = {"id": "a" + uuid.uuid4().hex[:6], "courses": [], "created": now_str()}
        accounts.append(acc)
    acc.update({
        "name": name,
        "username": username,
        "remark": str(data.get("remark") or "").strip(),
        "speed": 2 if str(data.get("speed")) == "2" else 1,
        "jobs": max(1, min(16, int(data.get("jobs") or 4))),
        "work_redo": bool(data.get("work_redo")),
        "work_max_retries": max(0, min(20, int(data.get("work_max_retries") or 3))),
        "notopen_action": "continue" if data.get("notopen_action") == "continue" else "retry",
        "retry_interval": max(0.0, float(data.get("retry_interval") or 1.0)),
        "auto_sign": bool(data.get("auto_sign")),
    })
    if password:
        acc["password"] = password
    save_accounts(accounts)
    return True, "已保存" + ("(新账号)" if is_new else "")


def delete_account(aid):
    accounts = load_accounts()
    acc = find_account(accounts, aid)
    if acc is None:
        return False, "账号不存在"
    tasks = load_tasks()
    if any(t["account"] == aid and t["status"] in ("queued", "running") for t in tasks):
        return False, "该账号还有排队/运行中的任务，请先停止"
    save_accounts([a for a in accounts if a["id"] != aid])
    save_tasks([t for t in tasks if t["account"] != aid])
    set_signwatch_wanted(aid, False)  # 账号已删，清除常驻意愿避免无效重启
    return True, "已删除"


def parse_course_input(text):
    """'123,456 高数, 789:线代' → [{'cid','name'}]（非法段忽略）。"""
    items = []
    for seg in re.split(r"[,，;；\n]+", str(text)):
        seg = seg.strip()
        if not seg:
            continue
        m = re.match(r"^(\d+)\s*[:：]?\s*(.*)$", seg)
        if not m:
            continue
        cid = m.group(1)
        rest = m.group(2).strip()
        # '456 高数' 或 '789:线代' 都取后面的名称
        name = re.sub(r"^[\s:：]+", "", rest)
        items.append({"cid": cid, "name": name})
    return items


def parse_course_table(text):
    """解析 CLI 课程表: 'ID: {cid} 班级ID: {clazz} 课程名: {title}'。"""
    out = []
    for line in str(text).splitlines():
        m = re.search(r"ID[:：]\s*(\d+).*?班级ID[:：]\s*(\d+).*?课程名[:：]\s*(\S.*?)\s*$", line)
        if m:
            out.append({"cid": m.group(1), "name": m.group(3), "clazz": m.group(2)})
    return out


def write_run_config(acc, course_list=""):
    """基于 config.ini 模板生成该账号的运行配置。返回 (路径, 错误)。"""
    tpl = cfg_template_path()
    try:
        txt = open(tpl, encoding="utf-8").read()
    except OSError as e:
        return None, ("缺少配置模板（%s 与 config.ini 均不存在）: %s" % (os.path.basename(CFG_TEMPLATE), e))
    # 私有覆盖（config.ini）：用户改过的键（如通知设置）优先于模板
    overlay = cfg_overlay_path()
    if overlay and os.path.isfile(overlay):
        try:
            ov = parse_ini_lines(open(overlay, encoding="utf-8").read())
            if ov:
                txt = apply_ini_overlay(txt, ov)
        except OSError:
            pass
    repl = {
        "username": acc["username"],
        "password": acc.get("password", ""),
        "course_list": course_list,
        "speed": str(acc.get("speed", 1)),
        "jobs": str(acc.get("jobs", 4)),
        "work_redo_enabled": "true" if acc.get("work_redo") else "false",
        "work_max_retries": str(acc.get("work_max_retries", 3)),
        "notopen_action": acc.get("notopen_action", "retry"),
        "retry_interval": str(acc.get("retry_interval", 1.0)),
    }
    lines = []
    for line in txt.split("\n"):
        m = re.match(r"^(\s*)([A-Za-z_]+)(\s*=\s*).*$", line)
        if m and m.group(2) in repl:
            line = "%s%s%s%s" % (m.group(1), m.group(2), m.group(3), repl[m.group(2)])
        lines.append(line)
    out = "\n".join(lines)
    if os.name == "nt":
        # Windows Docker Desktop 不支持 host 网络：容器内 127.0.0.1 不通
        # 但 host.docker.internal 在 Windows Docker Desktop 上也不可靠
        # 改用 10.0.75.1（Windows Docker Desktop 的默认网关 IP，指向宿主机）
        out = out.replace("http://127.0.0.1:", "http://10.0.75.1:")
    path = os.path.join(HERE, "config.run.%s.ini" % acc["id"])
    with open(path, "w", encoding="utf-8") as f:
        f.write(out)
    return path, ""


def cookies_path(aid):
    return os.path.join(HERE, "cookies.%s.txt" % aid)


def cache_path(aid):
    return os.path.join(HERE, "cache.%s.json" % aid)


# ---------- 签到守护（--sign-watch 常驻容器） ----------

def sign_container(aid):
    return "xxt-sign-%s" % aid


def load_signwatch(path=None):
    """{aid: true}：希望常驻签到守护的账号（掉线由服务守护自动重启）。"""
    data = _load(path or SIGNWATCH_FILE, {})
    return data if isinstance(data, dict) else {}


def save_signwatch(d, path=None):
    _save(path or SIGNWATCH_FILE, d)


def set_signwatch_wanted(aid, wanted, path=None):
    """记录/清除「希望签到守护常驻」的意愿（path 仅自检用，落盘到临时文件）。"""
    with LOCK:
        d = load_signwatch(path)
        if wanted:
            d[aid] = True
        else:
            d.pop(aid, None)
        save_signwatch(d, path)


def signwatch_status(aid):
    """容器状态描述（含已退出）；未创建返回 ""。"""
    return engine_status().get(sign_container(aid), "")


def launch_signwatch(aid):
    """启动签到守护容器：登录后常驻轮询签到活动。返回 (ok, message)。"""
    with LOCK:
        accounts = load_accounts()
        acc = find_account(accounts, aid)
        if acc is None:
            return False, "账号不存在"
        courses = acc.get("courses", [])
        if not courses:
            return False, "该账号还没有课程，请先在「课程」页拉取课程，再启动签到守护"
        if not acc.get("username") or not acc.get("password"):
            return False, "该账号缺少账号/密码，请先去「账号」页补全"
        cfg, err = write_run_config(acc, ",".join(str(c.get("cid", "")) for c in courses))
        if err or not cfg:
            return False, err or "配置生成失败"
        cookies = cookies_path(aid)
        open(cookies, "a").close()  # docker 挂载文件须存在
        name = sign_container(aid)
        acc_name = acc.get("name", aid)
    # 清掉可能的同名残留（Exited 保留以便读日志）
    engine_stop(name, cookies=cookies)
    rc, out, cerr = engine_start(name, cfg, cookies, args=("--sign-watch",), detach=True)
    if rc != 0:
        return False, "启动失败: " + (cerr.strip() or out.strip())
    set_signwatch_wanted(aid, True)  # 记录常驻意愿：掉线由服务守护自动重启
    add_event("sign", "签到守护", "已为「%s」启动签到守护" % acc_name)
    return True, "签到守护已启动"


def stop_signwatch(aid):
    """停止并移除签到守护容器。返回 (ok, message)。"""
    with LOCK:
        accounts = load_accounts()
        acc = find_account(accounts, aid)
        name = sign_container(aid)
        acc_name = (acc.get("name", aid) if acc else aid)
        if acc is not None:
            set_signwatch_wanted(aid, False)  # 清除常驻意愿：不可被守护拉起
    if not signwatch_status(aid):
        return False, "签到守护未在运行"
    engine_stop(name, cookies=cookies_path(aid))
    add_event("sign", "签到守护", "已停止「%s」的签到守护" % acc_name)
    return True, "签到守护已停止"


def api_signwatch():
    """每账号签到守护状态（含最新日志尾 20 行）。"""
    accounts = load_accounts()
    dockers = engine_status()
    out = []
    for a in accounts:
        name = sign_container(a["id"])
        exists = name in dockers
        out.append({
            "id": a["id"], "name": a.get("name", ""),
            "running": dockers.get(name, "").startswith("Up"),
            "container": name,
            "logs": engine_logs(name, tail=20) if exists else "",
        })
    return {"accounts": out}


def apply_autosign(accounts, aid, value):
    """仅设置该账号的 auto_sign 字段，不触碰其它字段；返回是否命中账号。"""
    acc = find_account(accounts, aid)
    if acc is None:
        return False
    acc["auto_sign"] = bool(value)
    return True


def api_account_autosign(aid, value):
    """专用自动签到开关（避免 /api/account/save 重置未提交字段）。"""
    with LOCK:
        accounts = load_accounts()
        if not apply_autosign(accounts, aid, value):
            return False, "账号不存在"
        save_accounts(accounts)
    return True, ("自动签到已开启" if value else "自动签到已关闭")


# ---------- 任务 ----------

def add_tasks(account_id, cids):
    accounts = load_accounts()
    acc = find_account(accounts, account_id)
    if acc is None:
        return False, "账号不存在"
    if not acc.get("username") or not acc.get("password"):
        return False, "该账号缺少账号/密码，请先编辑补全"
    tasks = load_tasks()
    added = skipped = 0
    for cid in cids:
        cid = str(cid).strip()
        if not re.fullmatch(r"\d+", cid):
            continue
        if any(t["account"] == account_id and t["cid"] == cid
               and t["status"] in ("queued", "running") for t in tasks):
            skipped += 1
            continue
        title = next((c.get("name") or "" for c in acc.get("courses", []) if c["cid"] == cid), "")
        tasks.append({
            "id": uuid.uuid4().hex[:8], "account": account_id, "cid": cid, "title": title,
            "status": "queued", "container": PREFIX + account_id + "-" + cid,
            "created": now_str(), "finished": "", "exit": None, "note": "",
        })
        added += 1
    save_tasks(tasks)
    msg = "已加入队列 %d 门" % added
    if skipped:
        msg += "；%d 门已在队列中，自动跳过" % skipped
    return True, msg


def stop_task(tid):
    tasks = load_tasks()
    t = next((x for x in tasks if x["id"] == tid), None)
    if t is None:
        return False, "任务不存在"
    if t["status"] == "queued":
        t["status"] = "stopped"
        t["finished"] = now_str()
    elif t["status"] == "running":
        engine_stop(t["container"], cookies=cookies_path(t["account"]),
                    cache=cache_path(t["account"]))
        t["status"] = "stopped"
        t["finished"] = now_str()
    else:
        return False, "该任务已结束"
    save_tasks(tasks)
    return True, "已停止"


def remove_task(tid):
    tasks = load_tasks()
    t = next((x for x in tasks if x["id"] == tid), None)
    if t is None:
        return False, "任务不存在"
    engine_stop(t["container"], cookies=cookies_path(t["account"]),
                cache=cache_path(t["account"]))
    save_tasks([x for x in tasks if x["id"] != tid])
    return True, "已移除"


def clear_done():
    tasks = load_tasks()
    keep = [t for t in tasks if t["status"] in ("queued", "running")]
    save_tasks(keep)
    return True, "已清理 %d 条已完成任务" % (len(tasks) - len(keep))


def launch(account, t):
    """启动一个任务容器。返回空字符串=成功，否则为错误信息。"""
    cfg, err = write_run_config(account, t["cid"])
    if err or not cfg:
        return err or "配置生成失败"
    cookies = cookies_path(account["id"])
    open(cookies, "a").close()  # docker 挂载文件须存在
    cache = cache_path(account["id"])
    open(cache, "a").close()  # 缓存文件（题目->答案），任务结束后收割入库
    # 同名残留（Exited 保留以便读日志）先清掉
    engine_stop(t["container"], cookies=cookies, cache=cache)
    extra = ("--auto-sign",) if account.get("auto_sign") else ()
    rc, out, cerr = engine_start(t["container"], cfg, cookies, cache=cache,
                                 args=("-l", str(t["cid"]), *extra), detach=True)
    if rc != 0:
        return "启动失败: " + (cerr.strip() or out.strip())
    return ""


def diagnose_error(text):
    """把常见异常翻译成可操作的中文提示。无匹配返回空串。"""
    s = text or ""
    pairs = [
        ("用户名或密码错误", "账号或密码错误：去「账号」页检查手机号 / 密码后重试"),
        ("LoginError", "登录失败：去「账号」页检查手机号 / 密码后重试"),
        ("InputFormatError", "任务缺少课程参数导致中断：直接点「重试」即可"),
        ("输入格式错误", "任务缺少课程参数导致中断：直接点「重试」即可"),
        ("EOFError", "任务缺少课程参数导致中断：直接点「重试」即可"),
        ("验证码", "需要验证码：稍后重试，或先用专用浏览器手动登录一次"),
        ("captcha", "需要验证码：稍后重试，或先用专用浏览器手动登录一次"),
        ("cookies 已失效", "登录缓存已失效：重试会自动改用密码重新登录"),
        ("超时", "网络超时：稍后重试"),
        ("Timeout", "网络超时：稍后重试"),
    ]
    for key, hint in pairs:
        if key in s:
            return hint
    return ""


def classify_error(text):
    """错误分类：transient/cookies/captcha/unknown 可自动重试；auth/permanent 不可。"""
    s = text or ""
    if ("用户名或密码错误" in s) or ("LoginError" in s):
        return "auth"
    if "cookies 已失效" in s:
        return "cookies"
    if ("验证码" in s) or ("captcha" in s.lower()):
        return "captcha"
    if ("InputFormatError" in s) or ("输入格式错误" in s):
        return "permanent"
    for k in ("超时", "Timeout", "timeout", "Connection", "refused", "EOF",
              "502", "503", "500", "reset by peer", "unreachable"):
        if k in s:
            return "transient"
    return "unknown"


_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def parse_progress(text, prev=None):
    """从容器日志解析学习进度（字段见 /api/state task.progress）。"""
    s = _ANSI_RE.sub("", text or "")
    out = dict(prev or {})
    m = list(re.finditer(r"开始任务[:：]\s*(.+?),\s*总时长[:：]\s*(\d+)s", s))
    if m:
        out["current"] = m[-1].group(1).strip()[:120]
        out["video_secs"] = int(m[-1].group(2))
    m = list(re.finditer(r"当前章节[:：]\s*(.+?)\s*$", s, re.M))
    if m:
        out["chapter"] = m[-1].group(1).strip()[:120]
    ms = re.findall(r"unfinished task[:：]\s*(\d+)", s)
    if ms:
        rem = int(ms[-1])
        ini = max(int(out.get("initial") or 0), int(ms[0]), rem)
        out["initial"] = ini
        out["remaining"] = rem
        if ini > 0:
            out["percent"] = max(0, min(100, int(round((ini - rem) * 100.0 / ini))))
    out["updated"] = now_str()
    return out


def load_settings():
    try:
        data = json.loads(open(SETTINGS_FILE, encoding="utf-8").read())
    except (OSError, ValueError):
        data = {}
    out = dict(DEFAULT_SETTINGS)
    if isinstance(data, dict):
        for k in DEFAULT_SETTINGS:
            if k in data:
                out[k] = data[k]
    return out


def save_settings(data):
    cur = load_settings()
    for k in DEFAULT_SETTINGS:
        if k not in data:
            continue
        if k == "max_retries":
            try:
                cur[k] = max(0, min(10, int(data[k])))
            except (TypeError, ValueError):
                pass
        else:
            cur[k] = bool(data[k])
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(cur, ensure_ascii=False, indent=1))
    except OSError as e:
        return False, "保存设置失败: %s" % e
    return True, "智能系统设置已保存"


def load_events():
    try:
        data = json.loads(open(EVENTS_FILE, encoding="utf-8").read())
    except (OSError, ValueError):
        data = []
    return data if isinstance(data, list) else []


def add_event(kind, title, message=""):
    with LOCK:
        evs = load_events()
        evs.insert(0, {"ts": now_str(), "kind": kind, "title": title, "message": message})
        del evs[300:]
        try:
            with open(EVENTS_FILE, "w", encoding="utf-8") as f:
                f.write(json.dumps(evs, ensure_ascii=False, indent=1))
        except OSError:
            pass


def notify_send(title, message):
    """经 config.ini [notification] 的 url 发送通知（尽力而为，不阻塞主流程）。"""
    url = (notify_payload().get("url") or "").strip()
    if not url:
        return False, "未配置通知 url"
    try:
        from urllib.parse import urlencode
        data = urlencode({"title": title, "desp": message}).encode("utf-8")
        with urlopen(url, data=data, timeout=8) as r:
            return (getattr(r, "status", 200) == 200), "已发送"
    except Exception as e:  # noqa: BLE001 - 通知失败不影响主流程
        return False, "发送失败: %s" % e


def svc_cmd(*args):
    """构造调用 onclick 脚本的命令（跨平台；Windows 用 powershell 调 onclick.ps1）。"""
    if os.name == "nt":
        return ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", os.path.join(HERE, "onclick.ps1")] + list(args)
    return ["bash", os.path.join(HERE, "onclick.sh")] + list(args)


def watchdog_once():
    """服务守护：巡检除 panel 外的服务，掉线则自动拉起（带速率限制）。"""
    if not load_settings().get("watchdog"):
        return
    now = time.time()
    for spec in SERVICES:
        svc = spec[0]
        if svc == "panel":
            continue
        try:
            alive = service_running(spec)
        except Exception:  # noqa: BLE001 - 探活失败按存活处理，避免误拉起
            alive = True
        if alive:
            WATCH_LAST[svc] = 0.0
            continue
        gap = 300 if svc == "llama-server" else 60
        if now - WATCH_LAST.get(svc, 0.0) < gap:
            continue
        WATCH_LAST[svc] = now
        try:
            subprocess.Popen(svc_cmd("start", svc), cwd=HERE, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except OSError:
            continue
        add_event("service", "服务守护", "检测到「%s」掉线，已自动拉起" % spec[1])

    # 签到守护：wanted=true 但容器未运行 → 自动重启（每账号 60s 速率限制）
    wanted = load_signwatch()
    if wanted:
        dockers = engine_status()
        for aid in list(wanted):
            if not wanted.get(aid):
                continue
            name = sign_container(aid)
            if dockers.get(name, "").startswith("Up"):
                SIGN_WATCH_LAST[aid] = 0.0
                continue
            if now - SIGN_WATCH_LAST.get(aid, 0.0) < 60:
                continue
            SIGN_WATCH_LAST[aid] = now
            ok, _ = launch_signwatch(aid)
            if ok:
                add_event("sign", "签到守护掉线，已自动重启", "账号 %s" % aid)


def prune_once():
    """智能清理：已退出容器保留最近 30 个；任务记录保留 200 条（活跃不剪）。"""
    try:
        if engine_backend() == "native":
            dirs = []
            if os.path.isdir(RUNS_DIR):
                for n in os.listdir(RUNS_DIR):
                    d = os.path.join(RUNS_DIR, n)
                    if os.path.isdir(d):
                        dirs.append((os.path.getmtime(d), n))
            exited = [(m, n) for m, n in dirs
                      if not engine_status().get(n, "").startswith("Up")]
            if len(exited) > 30:
                exited.sort()
                for _, n in exited[: len(exited) - 30]:
                    engine_stop(n)
                    shutil.rmtree(os.path.join(RUNS_DIR, n), ignore_errors=True)
                    add_event("clean", "自动清理", "已清理旧任务 %s" % n)
        else:
            out = subprocess.run(["docker", "ps", "-a", "--filter", "name=" + PREFIX,
                                  "--format", "{{.Names}}\t{{.Status}}\t{{.CreatedAt}}"],
                                 capture_output=True, text=True, timeout=30)
            exited = []
            for line in (out.stdout or "").splitlines():
                parts = line.split("\t")
                if len(parts) == 3 and parts[0].startswith(PREFIX) and not parts[1].startswith("Up"):
                    exited.append(parts)
            if len(exited) > 30:
                exited.sort(key=lambda x: x[2])
                for name, _, _ in exited[: len(exited) - 30]:
                    subprocess.run(["docker", "rm", "-f", name], capture_output=True, timeout=30)
                    add_event("clean", "自动清理", "已清理旧容器 %s" % name)
    except Exception:  # noqa: BLE001 - 清理失败不影响主流程
        pass
    with LOCK:
        tasks = load_tasks()
        if len(tasks) > 200:
            active = [t for t in tasks if t["status"] in ("running", "queued")]
            rest = [t for t in tasks if t["status"] not in ("running", "queued")]
            save_tasks(active + rest[-200:])


def retry_task(tid):
    """手动立即重试：清除等待时间并重新排队。"""
    with LOCK:
        tasks = load_tasks()
        t = next((x for x in tasks if x["id"] == tid), None)
        if t is None:
            return False, "任务不存在"
        if t["status"] == "running":
            return False, "任务正在运行"
        t["status"] = "queued"
        t["next_ts"] = 0
        t["note"] = "已手动加入重试队列"
        save_tasks(tasks)
        return True, "已重新排队，稍后自动启动"


def parse_scores(text):
    """从容器日志解析章节检测成绩。返回 (scores, accuracy)。"""
    s = _ANSI_RE.sub("", text or "")
    scores = []
    for m in re.finditer(r"章节检测全部正确（成绩 ([\d.]+) 分）", s):
        scores.append({"score": float(m.group(1)), "wrong": 0, "total": 0})
    for m in re.finditer(r"成绩 ([\d.]+) 分达到满分", s):
        scores.append({"score": float(m.group(1)), "wrong": 0, "total": 0})
    for m in re.finditer(r"章节检测有 (\d+)/(\d+) 题回答错误（成绩 ([\d.]+) 分）", s):
        scores.append({"score": float(m.group(3)), "wrong": int(m.group(1)), "total": int(m.group(2))})
    correct = sum(x["total"] - x["wrong"] for x in scores if x["total"])
    total = sum(x["total"] for x in scores if x["total"])
    accuracy = {"correct": correct, "total": total,
                "percent": int(round(correct * 100.0 / total)) if total else 0}
    return scores, accuracy


def harvest_log_path():
    return os.path.join(HERE, "harvest.json")


def harvest_record(n):
    """累计入库计数（harvest.json）。返回最新记录。"""
    with LOCK:
        d = {}
        try:
            d = json.load(open(harvest_log_path(), encoding="utf-8"))
        except (OSError, ValueError):
            d = {}
        d["total"] = int(d.get("total", 0)) + int(n)
        d["last_ts"] = now_str()
        d["last_added"] = int(n)
        try:
            with open(harvest_log_path(), "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False)
        except OSError:
            pass
        return d


def harvest_note_skipped(n):
    """累计「隔离」计数（无来源支持、未入库），供题库页观测闸门效果。"""
    n = int(n or 0)
    if n <= 0:
        return
    with LOCK:
        d = {}
        try:
            d = json.load(open(harvest_log_path(), encoding="utf-8"))
        except (OSError, ValueError):
            d = {}
        d["skipped_total"] = int(d.get("skipped_total", 0)) + n
        d["last_skipped"] = n
        try:
            with open(harvest_log_path(), "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False)
        except OSError:
            pass


def quarantine_path():
    return os.path.join(HERE, "harvest-quarantine.json")


def _guess_type(a):
    if re.fullmatch(r"[A-Za-z]{1,4}", a):
        return "0"
    if a in ("正确", "错误", "对", "错", "是", "否", "√", "×"):
        return "3"
    return "0"


def load_quarantine():
    try:
        d = json.load(open(quarantine_path(), encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return d if isinstance(d, list) else []


def _save_quarantine(items):
    try:
        with open(quarantine_path(), "w", encoding="utf-8") as f:
            json.dump(items[-200:], f, ensure_ascii=False)
    except OSError:
        pass


def quarantine_add(items):
    """把被闸门隔离的题暂存，待人工复核采纳（最新的在前，最多留 200 条）。"""
    if not items:
        return
    keep = load_quarantine()
    seen = {x.get("question") for x in keep}
    for q, a in items:
        if q in seen:
            continue
        seen.add(q)
        keep.append({"question": q, "answer": a, "type": _guess_type(a), "ts": now_str()})
    _save_quarantine(keep)


def quarantine_remove(question):
    keep = [x for x in load_quarantine() if x.get("question") != question]
    _save_quarantine(keep)


def adopt_quarantine(question):
    """把隔离区的一条题采纳入库（人工确认可信）。返回 (ok, message)。"""
    item = next((x for x in load_quarantine() if x.get("question") == question), None)
    if not item:
        return False, "隔离区无此题"
    tdir = os.path.expanduser(os.path.expandvars(
        env_values().get("TOOLKIT_DIR") or "~/Projects/chaoxing-lab/chaoxing-toolkit"))
    db = os.path.join(tdir, "tiku", "questions.db")
    if not os.path.exists(db):
        return False, "本地题库不存在"
    try:
        conn = sqlite3.connect(db, timeout=10)
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM questions WHERE question = ? LIMIT 1", (question,))
            if not cur.fetchone():
                cur.execute(
                    "INSERT INTO questions (question, type, options, answer, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
                    (question, item.get("type") or "0", "[]", item.get("answer") or ""),
                )
            conn.commit()
        finally:
            conn.close()
    except sqlite3.Error:
        return False, "写库失败"
    quarantine_remove(question)
    return True, "已采纳入库"

def harvest_all_caches():
    """手动触发：遍历所有账号的 cache 文件并收割入库。返回 (ok, message)。"""
    accounts = load_accounts()
    if not accounts:
        return False, "没有账号"
    total_added = 0
    total_skipped = 0
    for acc in accounts:
        aid = acc["id"]
        cache_file = cache_path(aid)
        if not os.path.exists(cache_file):
            continue
        try:
            data = json.load(open(cache_file, encoding="utf-8"))
            if not isinstance(data, dict) or not data:
                continue
            # 调用 harvest_cache 收割
            added = harvest_cache(aid)
            total_added += added
        except (OSError, ValueError):
            continue
    # 统计隔离区
    skipped = len(load_quarantine())
    msg = "收割完成：新增 %d 题" % total_added
    if skipped:
        msg += "，隔离区 %d 题待复核" % skipped
    harvest_record(total_added)
    return True, msg


def clear_quarantine():
    """清空隔离区（不入库）。返回 (ok, message)。"""
    q = load_quarantine()
    if not q:
        return False, "隔离区已为空"
    _save_quarantine([])
    return True, "已清空 %d 条隔离题" % len(q)





def _answer_matches(a, b):
    """宽松比对两个答案（覆盖 字母/内容 两种格式）：归一后相等或互为子串。"""
    def norm(x):
        return re.sub(r"[\s,，;；、.。:：()（）\[\]【】'\"-]+", "", str(x or "")).lower()
    na, nb = norm(a), norm(b)
    return bool(na and nb and (na == nb or na in nb or nb in na))


def _adapter_confirm(q, a):
    """向聚合题库(8060)求证：题目被来源收录才允许入库（fail-closed）。
    字母答案无法在无选项时逐字核对，故只要求来源已知该题；内容/判断答案则需一致。"""
    port = env_values().get("ADAPTER_PORT") or "8060"
    url = "http://127.0.0.1:%s/adapter-service/search" % port
    body = json.dumps({"question": q, "options": [], "type": 0}).encode("utf-8")
    try:
        with urlopen(Request(url, data=body, headers={"Content-Type": "application/json"}),
                     timeout=5) as r:
            res = json.loads(r.read().decode("utf-8", "ignore"))
    except (HTTPError, URLError, OSError, ValueError):
        return False
    ans = res.get("answer") or {}
    key, text = ans.get("answerKeyText"), ans.get("answerText")
    best = list(ans.get("bestAnswer") or [])
    if not (key or text or best):
        return False
    if re.fullmatch(r"[A-Za-z]{1,4}", a):
        return _answer_matches(a, key) if key else True
    return any(_answer_matches(a, c) for c in ([text, key] + best) if c)


def harvest_cache(aid):
    """把 cache.<aid>.json（题目 -> 答案）收割进本地题库。返回新增题数。"""
    path = cache_path(aid)
    if not os.path.exists(path):
        return 0
    try:
        data = json.load(open(path, encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    if not isinstance(data, dict) or not data:
        return 0
    tdir = os.path.expanduser(os.path.expandvars(
        env_values().get("TOOLKIT_DIR") or "~/Projects/chaoxing-lab/chaoxing-toolkit"))
    db = os.path.join(tdir, "tiku", "questions.db")
    if not os.path.exists(db):
        return 0
    added = 0
    skipped = 0
    skipped_items = []
    try:
        conn = sqlite3.connect(db, timeout=10)
        try:
            cur = conn.cursor()
            for q, a in data.items():
                q = str(q or "").strip()
                a = str(a or "").strip()
                if not q or not a:
                    continue
                cur.execute("SELECT 1 FROM questions WHERE question = ? LIMIT 1", (q,))
                if cur.fetchone():
                    continue
                # 只收割有来源支持的答案；AI 裸猜的隔离不入库，避免污染题库
                if not _adapter_confirm(q, a):
                    skipped += 1
                    skipped_items.append((q, a))
                    continue
                typ = _guess_type(a)
                cur.execute(
                    "INSERT INTO questions (question, type, options, answer, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
                    (q, typ, "[]", a),
                )
                added += 1
            conn.commit()
        finally:
            conn.close()
    except sqlite3.Error:
        return 0
    if skipped:
        print("harvest: 新增 %d 题，隔离 %d 题（无来源支持，未入库）" % (added, skipped))
        harvest_note_skipped(skipped)
        quarantine_add(skipped_items)
    return added


def tick():
    """调度周期：对账运行中任务；每个账号推进队首任务（同账号串行）。"""
    with LOCK:
        tasks = load_tasks()
        accounts = load_accounts()
        changed = False
        dockers = engine_status()
        settings = load_settings()
        name_of = {a["id"]: a.get("name", "") for a in accounts}
        for t in tasks:
            if t["status"] == "running":
                st = dockers.get(t["container"], "")
                if st.startswith("Up"):
                    t["progress"] = parse_progress(engine_logs(t["container"], tail=500), t.get("progress"))
                    changed = True
                else:
                    code = engine_exit_code(t["container"])
                    t["exit"] = code
                    t["finished"] = now_str()
                    full = engine_logs(t["container"], tail=5000)
                    t["logs_tail"] = full[-8000:] if len(full) > 8000 else full
                    sc, acc = parse_scores(full)
                    if sc:
                        t["scores"] = sc
                        t["accuracy"] = acc
                    # 原生后端：把运行目录里的 cookies/cache 收回 deploy/（收割与登录态复用都靠它）
                    engine_syncback(t["container"], cookies=cookies_path(t["account"]),
                                    cache=cache_path(t["account"]))
                    n_harvested = harvest_cache(t["account"])
                    if n_harvested > 0:
                        rec = harvest_record(n_harvested)
                        add_event("bank", "题库入库", "新增 %d 题（累计 %d 题）" % (
                            n_harvested, rec.get("total", n_harvested)))
                    if code == 0:
                        t["status"] = "done"
                        if settings.get("notify"):
                            notify_send("任务完成", "%s × %s 已完成" % (
                                name_of.get(t["account"], ""), t.get("title", t["cid"])))
                    else:
                        hint = diagnose_error(t["logs_tail"])
                        cls = classify_error(t["logs_tail"])
                        t["err_class"] = cls
                        maxr = int(settings.get("max_retries", 3))
                        if (settings.get("smart_retry")
                                and cls in ("transient", "cookies", "captcha", "unknown")
                                and int(t.get("retries", 0)) < maxr):
                            n = int(t.get("retries", 0)) + 1
                            backoff = [60, 300, 900][min(n - 1, 2)]
                            t["retries"] = n
                            t["next_ts"] = time.time() + backoff
                            t["status"] = "queued"
                            t["note"] = "自动重试排队中（第 %d/%d 次，约 %d 分钟后）%s" % (
                                n, maxr, backoff // 60, ("；" + hint) if hint else "")
                            add_event("task", "自动重试", "%s：第 %d/%d 次重试将在约 %d 分钟后开始" % (
                                t.get("title", t["cid"]), n, maxr, backoff // 60))
                        else:
                            t["status"] = "error"
                            if hint:
                                t["note"] = hint
                            if settings.get("notify"):
                                notify_send("任务失败", "%s × %s\n%s" % (
                                    name_of.get(t["account"], ""), t.get("title", t["cid"]),
                                    (t.get("note") or hint or "未知错误")[:200]))
                            add_event("task", "任务失败", "%s：%s" % (
                                t.get("title", t["cid"]), (t.get("note") or hint or "未知错误")[:120]))
                    changed = True
        for acc in accounts:
            busy = any(x["status"] == "running" and x["account"] == acc["id"] for x in tasks)
            if busy:
                continue
            now_ts = time.time()
            nxt = None
            for x in tasks:
                if x["account"] == acc["id"] and x["status"] == "queued" and x.get("next_ts", 0) <= now_ts:
                    nxt = x
                    break
            if nxt is None:
                continue
            err = launch(acc, nxt)
            if err:
                nxt["status"] = "error"
                nxt["note"] = err
                nxt["finished"] = now_str()
            else:
                nxt["status"] = "running"
            changed = True
        if changed:
            save_tasks(tasks)


def scheduler_loop():
    last_wd = 0.0
    last_prune = 0.0
    while True:
        try:
            tick()
        except Exception:
            pass
        now = time.time()
        if now - last_wd >= 15:
            last_wd = now
            try:
                watchdog_once()
            except Exception:
                pass
        if now - last_prune >= 3600:
            last_prune = now
            try:
                prune_once()
            except Exception:
                pass
        time.sleep(5)


def fetch_courses(aid):
    """用该账号登录一次，抓取课程表（非交互）。返回 (ok, message, courses)。"""
    with LOCK:
        accounts = load_accounts()
        acc = find_account(accounts, aid)
        if acc is None:
            return False, "账号不存在", []
        if not acc.get("username") or not acc.get("password"):
            return False, "该账号缺少账号/密码", []
        cfg, err = write_run_config(acc)
        if err or not cfg:
            return False, err or "配置生成失败", []
        cookies = cookies_path(aid)
        open(cookies, "a").close()
        net = [] if os.name == "nt" else ["--network", "host"]
    rc, out, cerr = engine_start("fetch-" + aid, cfg, cookies, detach=False, timeout=240)
    text = (out or "") + "\n" + (cerr or "")
    engine_syncback("fetch-" + aid, cookies=cookies)
    if rc == 127 or (not parse_course_table(text) and "未检测到 docker" in text):
        return False, "引擎不可用：包内引擎依赖不完整，且本机没有可用 docker。", []
    found = parse_course_table(text)
    if not found:
        return False, "没解析到课程列表（登录失败或课程为空）。可手动添加。输出末尾：\n" + text[-500:], []
    with LOCK:
        accounts = load_accounts()
        acc = find_account(accounts, aid)
        if acc is None:
            return False, "账号不存在", []
        # 存量去重：同 cid 只保留第一条
        seen_cids = set()
        deduped = []
        for c in acc.get("courses", []):
            if c.get("cid") in seen_cids:
                continue
            seen_cids.add(c.get("cid"))
            deduped.append(c)
        acc["courses"] = deduped
        known = {c["cid"]: c for c in acc["courses"]}
        added = 0
        for c in found:
            if c["cid"] in known:
                if c.get("name") and not known[c["cid"]].get("name"):
                    known[c["cid"]]["name"] = c["name"]
            else:
                entry = {"cid": c["cid"], "name": c.get("name", "")}
                acc.setdefault("courses", []).append(entry)
                known[c["cid"]] = entry
                added += 1
        save_accounts(accounts)
        return True, "拉取成功：新增 %d 门，共 %d 门课程" % (added, len(acc["courses"])), acc["courses"]


# ---------- 页面 ----------

PAGE = r"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>刷课控制台</title>
<style>
body{font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;margin:0;background:#f5f6f8;color:#1f2329}
header{background:#1f2329;color:#fff;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
h1{font-size:16px;margin:0}
header a{color:#93c5fd;text-decoration:none;font-size:13px;margin-left:14px}
.badge{font-size:12px;padding:2px 8px;border-radius:999px;background:#374151;color:#d1d5db;margin-left:10px}
main{padding:16px 20px;max-width:1100px;margin:0 auto}
.tabs{display:flex;gap:8px;margin-bottom:14px}
.tabs button{background:#e5e7eb;color:#374151}.tabs button.on{background:#2563eb;color:#fff}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:14px 16px;margin-bottom:14px}
h3{margin:0 0 10px;font-size:14px;color:#374151}
input,select{padding:7px 10px;border:1px solid #d0d5dd;border-radius:8px;font-size:13px;margin:2px 6px 2px 0}
input.wide{width:min(300px,80vw)}
button{padding:7px 13px;border:0;border-radius:8px;background:#2563eb;color:#fff;font-size:13px;cursor:pointer;margin:2px 6px 2px 0}
button.gray{background:#6b7280}button.red{background:#dc2626}button.green{background:#16a34a}
pre{background:#0f172a;color:#d1e0ff;padding:10px;border-radius:8px;font-size:12px;max-height:220px;overflow:auto;white-space:pre-wrap;word-break:break-all;margin:8px 0 0}
.task{border-bottom:1px solid #eef0f3;padding:10px 0}.task:last-child{border-bottom:0}
.st{font-weight:600;font-size:13px}.st-running{color:#2563eb}.st-queued{color:#b45309}.st-done{color:#16a34a}.st-error{color:#dc2626}.st-stopped{color:#9ca3af}
.hint{color:#b45309;font-size:13px;margin-top:6px}
.muted{color:#6b7280;font-size:12px}
.chip{display:inline-block;background:#eef2ff;color:#3730a3;border-radius:999px;padding:2px 10px;font-size:12px;margin:3px 6px 3px 0}
.chip b{font-weight:600}.chip span{cursor:pointer;color:#9ca3af;margin-left:6px}
.editor{background:#f9fafb;border:1px dashed #d1d5db;border-radius:8px;padding:10px;margin-top:10px}
label{font-size:12px;color:#6b7280;display:inline-block;min-width:64px}
code{background:#eef0f3;padding:1px 5px;border-radius:4px;font-size:12px}
.row{margin:6px 0}
</style></head><body>
<header>
  <h1>刷课控制台 <span class="badge" id="docker">检测中…</span></h1>
  <div>
    <a href="http://127.0.0.1:8001/" target="_blank">题库管理</a>
    <a href="#" onclick="return false" id="gaptip" style="cursor:default;color:#6b7280">聚合题库(高级) http://127.0.0.1:8060/</a>
  </div>
</header>
<main>
<div class="tabs">
  <button id="tab-acc" onclick="showTab('acc')">账号管理</button>
  <button id="tab-task" onclick="showTab('task')">任务</button>
</div>

<div id="pane-acc">
  <div class="card">
    <button class="green" onclick="editAccount(null)">＋ 新增账号</button>
    <span class="muted">每个账号独立配置：课程 / 速率 / 登录缓存。密码只存本机（accounts.json，权限 600）。</span>
    <div id="editor-box"></div>
  </div>
  <div id="accounts"></div>
</div>

<div id="pane-task" style="display:none">
  <div class="card">
    <h3>添加任务（同账号串行排队，不同账号可并行）</h3>
    <div class="row">
      <label>账号</label><select id="task-acc" onchange="renderCoursePick()"></select>
    </div>
    <div class="row" id="course-pick"></div>
    <div class="row">
      <button onclick="queueTasks()">加入队列</button>
      <button class="gray" onclick="clearDone()">清理已完成</button>
      <span id="task-msg" class="hint"></span>
    </div>
  </div>
  <div class="card"><h3>任务（每 3 秒自动刷新）</h3><div id="tasks">加载中…</div></div>
</div>
</main>
<script>
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let STATE = {docker:false, accounts:[], tasks:[]};
let acctSig = "", editingId = undefined;

async function api(path, body){
  const opt = body ? {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)} : {};
  return await (await fetch(path, opt)).json();
}
function showTab(t){
  document.getElementById("pane-acc").style.display = t==="acc" ? "" : "none";
  document.getElementById("pane-task").style.display = t==="task" ? "" : "none";
  document.getElementById("tab-acc").className = t==="acc" ? "on" : "";
  document.getElementById("tab-task").className = t==="task" ? "on" : "";
}
function refresh(){
  api("/api/state").then(d => {
    STATE = d;
    document.getElementById("docker").textContent = d.engine === "native" ? "引擎正常·原生"
        : (d.engine === "docker" ? "引擎正常·docker" : "引擎未就绪");
    const sig = JSON.stringify(d.accounts);
    renderTasks();
    if(sig !== acctSig){ acctSig = sig; renderAccounts(); renderTaskAccSelect(); }
  }).catch(e => { document.getElementById("tasks").textContent = "连接面板失败: " + e; });
}
/* ---------- 账号 ---------- */
function renderAccounts(){
  const box = document.getElementById("accounts");
  if(!STATE.accounts.length){ box.innerHTML = '<div class="card hint">还没有账号。点上方「新增账号」添加你的学习通账号。</div>'; return; }
  box.innerHTML = STATE.accounts.map(a => `
    <div class="card">
      <div><b>${esc(a.name)}</b> <span class="muted">${esc(a.username)}</span>
        ${a.remark ? '<span class="muted">（' + esc(a.remark) + '）</span>' : ""}
        <span class="chip">速率 x${a.speed} · 并发 ${a.jobs}</span>
        <span class="chip">${a.cookies ? "已缓存登录" : "未见登录缓存"}</span>
      </div>
      <div style="margin-top:8px">${a.courses.length ? a.courses.map(c =>
        `<span class="chip"><b>${esc(c.cid)}</b> ${esc(c.name || "")}<span onclick="delCourse('${a.id}','${c.cid}')">✕</span></span>`).join("") :
        '<span class="muted">还没有课程，先在下面添加或点「拉取课程」</span>'}</div>
      <div style="margin-top:8px">
        <input class="wide" id="ci-${a.id}" placeholder="添加课程：123 或 123 高数（可逗号分隔）">
        <button onclick="addCourses('${a.id}')">添加</button>
        <button class="gray" onclick="fetchCourses('${a.id}', this)">拉取课程（需登录一次）</button>
        <button class="gray" onclick="editAccount('${a.id}')">编辑 / 速率</button>
        <button class="red" onclick="delAccount('${a.id}')">删除账号</button>
      </div>
      <div id="fc-msg-${a.id}" class="hint"></div>
    </div>`).join("");
}
function editAccount(id){
  editingId = id;
  const a = id ? STATE.accounts.find(x => x.id === id) : null;
  document.getElementById("editor-box").innerHTML = `
    <div class="editor">
      <div class="row"><label>名称</label><input id="f-name" class="wide" value="${a ? esc(a.name) : ""}" placeholder="例如：我的账号"></div>
      <div class="row"><label>手机号</label><input id="f-user" class="wide" value="${a ? esc(a.username) : ""}" placeholder="学习通登录手机号"></div>
      <div class="row"><label>密码</label><input id="f-pass" class="wide" type="password" placeholder="${a ? "留空则不修改" : "学习通密码"}"></div>
      <div class="row"><label>备注</label><input id="f-remark" class="wide" value="${a ? esc(a.remark || "") : ""}" placeholder="可留空"></div>
      <div class="row">
        <label>速率</label>
        <select id="f-speed"><option value="1"${!a || a.speed === 1 ? " selected" : ""}>x1（正常）</option><option value="2"${a && a.speed === 2 ? " selected" : ""}>x2（两倍速）</option></select>
        <label>章节并发</label><input id="f-jobs" style="width:60px" value="${a ? a.jobs : 4}">
      </div>
      <div class="row">
        <label style="min-width:auto"><input type="checkbox" id="f-redo"${a && a.work_redo ? " checked" : ""}> 答错自动重做</label>
        <label>最多</label><input id="f-retry" style="width:60px" value="${a ? a.work_max_retries : 3}"> 次
      </div>
      <div class="row">
        <label>未开放章节</label>
        <select id="f-notopen"><option value="retry"${!a || a.notopen_action === "retry" ? " selected" : ""}>重试</option><option value="continue"${a && a.notopen_action === "continue" ? " selected" : ""}>跳过</option></select>
        <label>重试间隔</label><input id="f-interval" style="width:64px" value="${a ? a.retry_interval : 1.0}"> 秒
      </div>
      <div class="row">
        <button class="green" onclick="saveAccount()">保存</button>
        <button class="gray" onclick="document.getElementById('editor-box').innerHTML=''">取消</button>
      </div>
    </div>`;
  window.scrollTo(0, 0);
}
async function saveAccount(){
  const d = await api("/api/account/save", {
    id: editingId || "",
    name: document.getElementById("f-name").value,
    username: document.getElementById("f-user").value,
    password: document.getElementById("f-pass").value,
    remark: document.getElementById("f-remark").value,
    speed: document.getElementById("f-speed").value,
    jobs: document.getElementById("f-jobs").value,
    work_redo: document.getElementById("f-redo").checked,
    work_max_retries: document.getElementById("f-retry").value,
    notopen_action: document.getElementById("f-notopen").value,
    retry_interval: document.getElementById("f-interval").value,
  });
  alert(d.message || "");
  if(d.ok){ document.getElementById("editor-box").innerHTML = ""; acctSig = ""; refresh(); }
}
async function delAccount(id){
  if(!confirm("删除该账号？（其课程与任务记录一并删除）")) return;
  const d = await api("/api/account/delete", {id});
  if(!d.ok) alert(d.message); acctSig = ""; refresh();
}
async function addCourses(id){
  const el = document.getElementById("ci-" + id);
  const v = el.value.trim();
  if(!v) return;
  const d = await api("/api/course/save", {account: id, text: v});
  if(!d.ok) alert(d.message); else el.value = "";
  acctSig = ""; refresh();
}
async function delCourse(id, cid){
  const d = await api("/api/course/delete", {account: id, cid});
  if(!d.ok) alert(d.message); acctSig = ""; refresh();
}
async function fetchCourses(id, btn){
  const msg = document.getElementById("fc-msg-" + id);
  msg.textContent = "正在用该账号登录并拉取课程（最长 4 分钟）…";
  btn.disabled = true;
  const d = await api("/api/account/fetch", {id});
  btn.disabled = false;
  msg.textContent = d.message + (d.courses ? "（共 " + d.courses.length + " 门，已自动去重合并）" : "");
  acctSig = ""; refresh();
}
/* ---------- 任务 ---------- */
function renderTaskAccSelect(){
  const sel = document.getElementById("task-acc");
  sel.innerHTML = STATE.accounts.map(a => `<option value="${a.id}">${esc(a.name)}（${esc(a.username)}）</option>`).join("");
  renderCoursePick();
}
function renderCoursePick(){
  const id = document.getElementById("task-acc").value;
  const a = STATE.accounts.find(x => x.id === id);
  const box = document.getElementById("course-pick");
  if(!a || !a.courses.length){ box.innerHTML = '<span class="hint">该账号还没有课程，先到「账号管理」添加或拉取。</span>'; return; }
  box.innerHTML = a.courses.map(c =>
    `<label style="min-width:auto;color:#1f2329"><input type="checkbox" class="pk" value="${c.cid}"> ${esc(c.cid)} ${esc(c.name || "")}</label>`).join(" ") +
    ' <button class="gray" onclick="document.querySelectorAll(\'.pk\').forEach(x=>x.checked=true)">全选</button>';
}
async function queueTasks(){
  const acc = document.getElementById("task-acc").value;
  const cids = [...document.querySelectorAll(".pk:checked")].map(x => x.value);
  if(!cids.length){ document.getElementById("task-msg").textContent = "先勾选课程"; return; }
  const d = await api("/api/task/start", {account: acc, cids});
  document.getElementById("task-msg").textContent = d.message || "";
  refresh();
}
async function clearDone(){
  const d = await api("/api/task/clear", {});
  document.getElementById("task-msg").textContent = d.message || "";
  refresh();
}
function renderTasks(){
  const box = document.getElementById("tasks");
  if(!STATE.tasks.length){ box.innerHTML = '<div class="hint">暂无任务。切到上方「添加任务」勾选课程并加入队列。</div>'; return; }
  box.innerHTML = STATE.tasks.map(t => `
    <div class="task">
      <div>
        <span class="st st-${esc(t.status)}">${esc(t.status_cn)}</span>
        <b>${esc(t.acct_name)}</b> · ${esc(t.cid)} ${esc(t.title || "")}
        <span class="muted">${esc(t.status_desc || "")} ${t.created ? "· 创建 " + esc(t.created) : ""} ${t.finished ? "· 结束 " + esc(t.finished) : ""}</span>
        ${t.status === "running" || t.status === "queued"
          ? `<button class="gray" onclick="taskAct('stop','${t.id}')">停止</button>` : ""}
        <button class="red" onclick="taskAct('remove','${t.id}')">移除</button>
      </div>
      ${t.note ? `<div class="hint">${esc(t.note)}</div>` : ""}
      ${t.status === "queued" ? "" : `<pre>${esc(t.logs || "（暂无日志）")}</pre>`}
    </div>`).join("");
}
async function taskAct(op, id){
  const d = await api("/api/task/" + op, {id});
  if(!d.ok) alert(d.message);
  refresh();
}
refresh(); setInterval(refresh, 3000);
</script></body></html>"""


# ---------- 服务 / 日志 / 题库 / 设置 ----------

def env_values():
    """deploy.env 覆盖 deploy.env.example 的键值（用于端口等配置）。"""
    vals = {}
    for path in (ENV_EXAMPLE, DEPLOY_ENV):
        try:
            for line in open(path, encoding="utf-8"):
                s = line.strip()
                if not s or s.startswith("#") or "=" not in s:
                    continue
                k, v = s.split("=", 1)
                vals[k.strip()] = v.strip().strip('"').strip("'")
        except OSError:
            continue
    return vals


def svc_url(spec):
    """由服务定义算出探测 URL（端口可被 deploy.env 覆盖）。"""
    key, _label, port_key, path = spec
    default = {"LLAMA_PORT": "8080", "TIKU_PORT": "8001", "ADAPTER_PORT": "8060",
               "BRIDGE_PORT": "8002", "PANEL_PORT": "8003"}.get(port_key, "8000")
    port = str(PORT) if key == "panel" else (env_values().get(port_key) or default)
    return "http://127.0.0.1:%s%s" % (port, path)


def service_running(spec):
    """有 HTTP 响应（含 4xx）即视为运行中；连接失败=未运行。"""
    try:
        urlopen(svc_url(spec), timeout=2)
        return True
    except HTTPError:
        return True
    except Exception:
        return False


def api_services():
    out = []
    for spec in SERVICES:
        out.append({"id": spec[0], "label": spec[1], "url": svc_url(spec),
                    "running": service_running(spec)})
    return {"services": out}


def api_logs(svc, tail=200):
    if svc not in LOG_SVCS:
        return {"error": "未知服务"}
    path = os.path.join(LOG_DIR, svc + ".log")
    try:
        lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
    except OSError:
        return {"logs": "", "path": path, "note": "暂无日志（服务可能未由脚本启动过）"}
    tail = max(1, min(1000, int(tail or 200)))
    return {"logs": "\n".join(lines[-tail:]), "path": path}


# ---------- 题库自动扩充（tiku-augment 集成，2026.10.21） ----------
AUG = {"running": False, "done": 0, "total": 0, "msg": "", "started": 0.0}


def _augment_tool(*args, timeout=180):
    """调用题库扩充引擎（同目录 tiku-augment.py），返回 (returncode, 输出)。"""
    tool = os.path.join(HERE, "tiku-augment.py")
    if not os.path.isfile(tool):
        return 1, "缺少 tiku-augment.py（请先更新到最新版）"
    try:
        p = subprocess.run([sys.executable, tool, *args],
                           capture_output=True, text=True, timeout=timeout, cwd=HERE)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return 1, "执行超时（AI 补答请用后台任务）"
    except OSError as exc:
        return 1, "执行失败: %s" % exc


def bank_augment_stats():
    """待处理题 + 建议的统计与明细（一次调用拿全，供控制台面板）。"""
    rc, out = _augment_tool("stats", "--json", timeout=30)
    if rc != 0:
        return {"ok": False, "error": out.strip()[:200]}
    try:
        d = json.loads(out)
    except ValueError:
        return {"ok": False, "error": "输出解析失败"}
    rc2, out2 = _augment_tool("suggestions", "--json", timeout=30)
    try:
        d["suggestions_items"] = json.loads(out2) if rc2 == 0 else []
    except ValueError:
        d["suggestions_items"] = []
    d["augment"] = dict(AUG)
    d["ok"] = True
    return d


def bank_ai_fill(limit):
    """后台线程用本地 AI 给未命中题批量补答（逐题更新进度）。"""
    limit = max(1, min(int(limit or 10), 100))
    if AUG["running"]:
        return False, "已有补答任务在进行中"
    tool = os.path.join(HERE, "tiku-augment.py")
    if not os.path.isfile(tool):
        return False, "缺少 tiku-augment.py（请先更新到最新版）"
    AUG.update(running=True, done=0, total=limit, msg="启动中…", started=time.time())

    def _run():
        try:
            proc = subprocess.Popen([sys.executable, tool, "ai-fill", "--limit", str(limit)],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, cwd=HERE)
            for line in proc.stdout:
                line = line.rstrip()
                if line.strip().startswith("["):
                    AUG["done"] += 1
                if line.strip():
                    AUG["msg"] = line.strip()[:120]
            proc.wait()
            AUG.update(msg="完成：成功 %d 题" % AUG["done"] if proc.returncode == 0 else "结束（见日志）")
        except Exception as exc:  # noqa: BLE001
            AUG["msg"] = "失败: %s" % exc
        finally:
            AUG["running"] = False

    threading.Thread(target=_run, daemon=True).start()
    return True, "已开始（本地 AI 逐题作答，可在面板看进度）"


def bank_adopt(ids, adopt_all):
    args = ["adopt"] + (["--all"] if adopt_all else [str(int(i)) for i in ids])
    rc, out = _augment_tool(*args, timeout=60)
    last = [l for l in out.strip().splitlines() if l.strip()]
    return rc == 0, (last[-1] if last else "无输出")


def bank_drop_suggestions(ids, drop_all):
    args = ["drop-suggestions"] + (["--all"] if drop_all else [str(int(i)) for i in ids])
    rc, out = _augment_tool(*args, timeout=60)
    last = [l for l in out.strip().splitlines() if l.strip()]
    return rc == 0, (last[-1] if last else "无输出")


def bank_export_pack():
    """导出分享包，直接把 JSON 内容返回给前端下载。"""
    tmp = tempfile.mktemp(suffix=".json")
    try:
        rc, out = _augment_tool("export", tmp, timeout=60)
        if rc != 0:
            return False, out.strip()[:200], None
        with open(tmp, encoding="utf-8") as f:
            pack = json.load(f)
        return True, "导出 %d 题 / 待处理 %d 题" % (
            pack["count"]["questions"], pack["count"]["pending"]), pack
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def bank_import_pack(pack):
    """导入分享包（前端读文件后把 JSON 发来，避免 multipart）。"""
    if not isinstance(pack, dict) or pack.get("format") != "xuexiton-tiku-pack":
        return False, "不是有效的题库分享包"
    tmp = tempfile.mktemp(suffix=".json")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(pack, f, ensure_ascii=False)
        rc, out = _augment_tool("import", tmp, timeout=120)
        lines = [l.strip() for l in out.strip().splitlines() if l.strip()]
        return rc == 0, " ｜ ".join(lines[-2:]) if lines else "无输出"
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def api_bank():
    """本地题库统计（直接只读 sqlite，不依赖 8001 是否在跑）。"""
    tdir = os.path.expanduser(os.path.expandvars(env_values().get("TOOLKIT_DIR") or "~/Projects/chaoxing-lab/chaoxing-toolkit"))
    db = os.path.join(tdir, "tiku", "questions.db")
    ports = env_values()
    out = {"db": db, "count": 0, "pending": 0, "harvested": 0, "skipped": 0,
           "by_type": {}, "recent": [], "activity": [], "trend": [],
           "links": {"manage": "http://127.0.0.1:%s/" % (ports.get("TIKU_PORT") or "8001"),
                     "aggregate": "http://127.0.0.1:%s/" % (ports.get("ADAPTER_PORT") or "8060")}}
    try:
        h = json.load(open(harvest_log_path(), encoding="utf-8"))
        out["harvested"] = int(h.get("total", 0))
        out["skipped"] = int(h.get("skipped_total", 0))
        out["last_ts"] = h.get("last_ts", "")
        out["last_added"] = int(h.get("last_added", 0))
        out["last_skipped"] = int(h.get("last_skipped", 0))
    except (OSError, ValueError):
        pass
    try:
        conn = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        try:
            out["count"] = conn.execute("select count(*) from questions").fetchone()[0]
            try:
                out["pending"] = conn.execute("select count(*) from pending_questions").fetchone()[0]
            except sqlite3.Error:
                pass
            try:
                for t, c in conn.execute("select type, count(*) from questions group by type"):
                    out["by_type"][str(t)] = c
            except sqlite3.Error:
                pass
            try:
                rows = conn.execute(
                    "select question, type, answer, created_at from questions order by id desc limit 6"
                ).fetchall()
                out["recent"] = [{"question": r[0], "type": str(r[1]), "answer": r[2],
                                  "created_at": r[3]} for r in rows]
            except sqlite3.Error:
                pass
            # 活动流：最近 10 条入库事件（按时间倒序）
            try:
                rows = conn.execute(
                    "select question, type, answer, created_at from questions order by id desc limit 10"
                ).fetchall()
                TYPE_LABEL = {"0": "单选", "1": "多选", "3": "判断"}
                out["activity"] = [{"question": r[0], "type": str(r[1]),
                                   "type_label": TYPE_LABEL.get(str(r[1]), r[1]),
                                   "answer": r[2], "created_at": r[3]} for r in rows]
            except sqlite3.Error:
                pass
            # 趋势图：最近 7 天入库量
            try:
                rows = conn.execute(
                    "select date(created_at) as d, count(*) from questions "
                    "where created_at >= date('now', '-7 days') group by date(created_at) order by d"
                ).fetchall()
                out["trend"] = [{"date": r[0], "count": r[1]} for r in rows]
            except sqlite3.Error:
                pass
        finally:
            conn.close()
    except sqlite3.Error as e:
        out["note"] = "读取题库失败: %s" % e
    out["quarantine"] = load_quarantine()
    return out


def _llama_port():
    return env_values().get("LLAMA_PORT") or "8080"


def _llama_get(path, timeout=3):
    """GET llama-server（同机 127.0.0.1）。失败返回 None。"""
    try:
        with urlopen("http://127.0.0.1:%s%s" % (_llama_port(), path), timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "ignore"))
    except (HTTPError, URLError, OSError, ValueError):
        return None


def _llama_proc():
    """llama-server 进程信息 {pid, rss_mb, uptime_s}（无则 {}）。"""
    try:
        p = subprocess.run(["ps", "-eo", "pid,rss,etimes,comm"], capture_output=True,
                           text=True, timeout=10)
        for line in (p.stdout or "").splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[3] == "llama-server":
                return {"pid": int(parts[0]), "rss_mb": round(int(parts[1]) / 1024.0, 1),
                        "uptime_s": int(parts[2])}
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return {}


def _llama_stats(tail=2000):
    """解析 llama-server 日志尾：最近一次 prompt/生成吞吐 + 累计请求数。"""
    path = os.path.join(LOG_DIR, "llama-server.log")
    try:
        lines = open(path, encoding="utf-8", errors="replace").read().splitlines()[-tail:]
    except OSError:
        return {}
    out = {"requests": 0, "prompt_tps": 0.0, "gen_tps": 0.0, "last_ms": 0}
    for ln in lines:
        if "prompt eval time" in ln:
            out["requests"] += 1
            m = re.search(r"([\d.]+) tokens per second", ln)
            if m:
                out["prompt_tps"] = float(m.group(1))
        elif "eval time" in ln and "prompt" not in ln:
            m = re.search(r"([\d.]+) tokens per second", ln)
            if m:
                out["gen_tps"] = float(m.group(1))
        elif "total time" in ln:
            m = re.search(r"total time =\s*([\d.]+) ms", ln)
            if m:
                out["last_ms"] = round(float(m.group(1)))
    return out


def _model_files():
    """MODELS_DIR(默认 ~/models) 下可切换的 .gguf 列表（按大小降序）。"""
    root = os.path.expanduser(os.path.expandvars(env_values().get("MODELS_DIR") or "~/models"))
    files = []
    for dirpath, _dirs, names in os.walk(root):
        for n in names:
            if n.lower().endswith(".gguf"):
                full = os.path.join(dirpath, n)
                try:
                    mb = round(os.path.getsize(full) / 1048576.0, 1)
                except OSError:
                    mb = 0
                files.append({"path": full, "name": n, "size_mb": mb})
    files.sort(key=lambda x: x["size_mb"], reverse=True)
    return files


def api_model():
    """模型运行观测：状态/参数/进程/吞吐/日志尾/最近输出/可切换文件。"""
    port = _llama_port()
    running = service_running(SERVICES[0])
    props = _llama_get("/props") if running else None
    served = _llama_get("/v1/models") if running else None
    model_path = ""
    if served and served.get("data"):
        model_path = (served["data"][0] or {}).get("id") or ""
    elif served and served.get("models"):
        model_path = (served["models"][0] or {}).get("name") or ""
    gen = (props or {}).get("default_generation_settings") or {}
    params = gen.get("params") or {}
    out = {
        "running": running,
        "port": port,
        "endpoint": "http://127.0.0.1:%s/v1" % port,
        "model": os.path.basename(model_path) or "-",
        "model_path": model_path,
        "ctx": gen.get("n_ctx"),
        "params": {k: params.get(k) for k in ("temperature", "top_k", "top_p", "n_predict")},
        "active_model_path": env_values().get("MODEL_PATH") or "",
        "proc": _llama_proc(),
        "stats": _llama_stats(),
        "log_tail": "",
        "outputs": [],
        "files": _model_files(),
    }
    try:
        out["log_tail"] = "\n".join(
            open(os.path.join(LOG_DIR, "llama-server.log"), encoding="utf-8",
                 errors="replace").read().splitlines()[-40:])
    except OSError:
        pass
    try:
        cache = json.load(open(os.path.join(HERE, "cache.json"), encoding="utf-8"))
        if isinstance(cache, dict):
            items = list(cache.items())[-8:]
            out["outputs"] = [{"q": str(q), "a": str(a)} for q, a in reversed(items)]
    except (OSError, ValueError):
        pass
    return out


def llama_chat(prompt, max_tokens=256):
    """向本地模型发一条提示词，返回原始输出 + 计时（「试问」）。"""
    prompt = str(prompt or "").strip()
    if not prompt:
        return False, "提示词为空", {}
    body = json.dumps({
        "model": "local",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0, "max_tokens": int(max_tokens),
    }).encode("utf-8")
    url = "http://127.0.0.1:%s/v1/chat/completions" % _llama_port()
    t0 = time.time()
    try:
        with urlopen(Request(url, data=body, headers={"Content-Type": "application/json"}),
                     timeout=120) as r:
            res = json.loads(r.read().decode("utf-8", "ignore"))
    except (HTTPError, URLError, OSError, ValueError) as e:
        return False, "模型调用失败: %s" % e, {}
    ms = round((time.time() - t0) * 1000)
    try:
        content = res["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        content = ""
    return True, "ok", {"content": content, "ms": ms}


def _portable_path(p):
    """$HOME 下的绝对路径写成 $HOME/... 形式，便于换机（onclick.sh 会展开 $HOME）。"""
    home = os.path.expanduser("~")
    if home and home != "/" and p.startswith(home + os.sep):
        return "$HOME" + p[len(home):]
    return p


def model_switch(path):
    """写 deploy.env 的 MODEL_PATH 并重启 llama-server（切模型，默认关→按需）。"""
    path = str(path or "").strip()
    path = os.path.expanduser(os.path.expandvars(path))
    root = os.path.expanduser(os.path.expandvars(env_values().get("MODELS_DIR") or "~/models"))
    if not (path and path.startswith(root + os.sep) and path.lower().endswith(".gguf")
            and os.path.exists(path)):
        return False, "只允许切换 %s 下存在的 .gguf 文件" % root
    portable = _portable_path(path)
    try:
        if not os.path.exists(DEPLOY_ENV):
            with open(ENV_EXAMPLE, encoding="utf-8") as src:
                text = src.read()
            with open(DEPLOY_ENV, "w", encoding="utf-8") as f:
                f.write(text)
        lines = open(DEPLOY_ENV, encoding="utf-8").read().split("\n")
        found = False
        for i, line in enumerate(lines):
            s = line.strip()
            if s and not s.startswith("#") and "=" in s and s.split("=", 1)[0].strip() == "MODEL_PATH":
                lines[i] = "MODEL_PATH=%s" % portable
                found = True
        if not found:
            lines.append("MODEL_PATH=%s" % portable)
        with open(DEPLOY_ENV, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    except OSError as e:
        return False, "写入 deploy.env 失败: %s" % e
    try:
        subprocess.run(svc_cmd("stop", "llama-server"), cwd=HERE,
                       capture_output=True, timeout=30)
        subprocess.Popen(svc_cmd("start", "llama-server"), cwd=HERE, stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except (OSError, subprocess.SubprocessError) as e:
        return False, "重启失败: %s" % e
    return True, "已切换模型，正在重启（约 10–30s 后生效）"


def _ini_section(path, section):
    """极简 ini 单段读取（键=值；忽略注释行）。"""
    vals, cur = {}, ""
    try:
        for line in open(path, encoding="utf-8"):
            s = line.strip()
            if not s or s.startswith(";") or s.startswith("#"):
                continue
            if s.startswith("[") and s.endswith("]"):
                cur = s[1:-1].strip()
                continue
            if cur == section and "=" in s:
                k, v = s.split("=", 1)
                vals[k.strip()] = v.strip()
    except OSError:
        pass
    return vals


def env_payload():
    example = _ini_like(ENV_EXAMPLE)
    vals = env_values()
    return {"values": {k: vals.get(k, "") for k in ENV_KEYS},
            "defaults": {k: example.get(k, "") for k in ENV_KEYS}}


def _ini_like(path):
    """env.example 风格的 KEY=VALUE 读取。"""
    out = {}
    try:
        for line in open(path, encoding="utf-8"):
            s = line.strip()
            if s and not s.startswith("#") and "=" in s:
                k, v = s.split("=", 1)
                out[k.strip()] = v.strip()
    except OSError:
        pass
    return out


def env_save(data):
    vals = data.get("values") or {}
    try:
        lines = open(ENV_EXAMPLE, encoding="utf-8").read().split("\n")
    except OSError as e:
        return False, "读取 deploy.env.example 失败: %s" % e
    for i, line in enumerate(lines):
        s = line.strip()
        if s and not s.startswith("#") and "=" in s:
            k = s.split("=", 1)[0].strip()
            if k in vals and k in ENV_KEYS:
                lines[i] = "%s=%s" % (k, str(vals[k]).strip())
    try:
        with open(DEPLOY_ENV, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    except OSError as e:
        return False, "写入 deploy.env 失败: %s" % e
    return True, "已保存（重启对应服务后生效）"


def export_data():
    return {"accounts": load_accounts(), "tasks": load_tasks(), "env": env_payload()}


def reset_data(what):
    what = str(what or "")
    if what in ("all", "tasks"):
        save_tasks([])
    if what in ("all", "accounts"):
        save_accounts([])
    if what in ("all", "env"):
        try:
            os.remove(DEPLOY_ENV)
        except OSError:
            pass
    return True, "已清空: %s" % (what or "（未指定）")


def notify_payload():
    return _ini_section(cfg_template_path(), "notification")


def notify_save(data):
    """只改 config.ini 模板 [notification] 段的 provider / url 两行。"""
    tpl = cfg_template_path()
    tgt = cfg_overlay_path() or tpl
    # 覆盖文件不存在则从模板复制一份（只带 [notification] 段即可，这里整份复制最稳）
    if tgt != tpl and not os.path.isfile(tgt):
        try:
            shutil.copyfile(tpl, tgt)
        except OSError as e:
            return False, "创建 config.ini 失败: %s" % e
    try:
        lines = open(tgt, encoding="utf-8").read().split("\n")
    except OSError as e:
        return False, "读取配置文件失败: %s" % e
    cur = ""
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            cur = s[1:-1].strip()
        if cur == "notification" and "=" in s and not s.startswith(";"):
            k = s.split("=", 1)[0].strip()
            if k == "provider":
                lines[i] = "provider = " + str(data.get("provider", "")).strip()
            elif k == "url":
                lines[i] = "url = " + str(data.get("url", "")).strip()
    try:
        with open(tgt, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    except OSError as e:
        return False, "写入配置文件失败: %s" % e
    return True, "通知设置已保存"


def service_action(name, action):
    """面板触发单服务启停（复用 onclick 脚本，服务逻辑单一真源；跨平台）。"""
    if name not in LOG_SVCS:
        return False, "未知服务: %s" % name
    if action == "start":
        args = svc_cmd("start", name)
        try:
            subprocess.Popen(args, cwd=HERE, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except OSError as e:
            return False, "启动失败: %s" % e
        return True, "启动命令已发出（几秒后刷新状态）"
    if action == "stop":
        try:
            p = subprocess.run(svc_cmd("stop", name), cwd=HERE,
                               capture_output=True, text=True, timeout=30)
        except Exception as e:  # noqa: BLE001 - 面板兜底
            return False, "停止失败: %s" % e
        out = (p.stdout or "").strip().replace("\n", "；")
        return True, out or "已停止"
    return False, "未知动作: %s" % action


# ---------- 在线更新（面板内一键更新） ----------

UPDATE_CACHE = {"t": 0.0, "info": None}
UPDATE_SKIP_NAMES = {"accounts.json", "deploy.env", "config.ini", "config.docker.ini", "tasks.json",
                     "events.json", "settings.json", "signwatch.json",
                     "harvest.json", "harvest-quarantine.json", "cache.json"}
UPDATE_SKIP_PREFIXES = ("accounts.json", "cookies", "config.run.", "harvest", "cache",
                        "备份-更新前", "__pycache__")


def _update_skip(name):
    """私有文件与运行时文件：更新/备份时一律跳过（对齐 update.sh 排除清单）。"""
    if name in UPDATE_SKIP_NAMES:
        return True
    if name.endswith(".log"):
        return True
    return name.startswith(UPDATE_SKIP_PREFIXES)


def read_version():
    try:
        return open(os.path.join(HERE, "VERSION"), encoding="utf-8").read().strip()
    except OSError:
        return "?"


# 内置默认更新源（与 update.sh 的 DEFAULT_FEED、在线更新.ps1 的内置地址保持一致）：
# 未在 deploy.env 配置任何更新地址时，控制台「一键更新」也能用，装好即用。
DEFAULT_UPDATE_FEED = "https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json"
# 同一份清单的备用地址：jsdelivr 在仓库每次推送后约 2 分钟内不可用（CDN 重建窗口，报 SSL
# UNEXPECTED_EOF_WHILE_READING），raw.githubusercontent 始终可用。只对内置默认源加这个兜底，
# 用户自定义的 UPDATE_FEED 不受影响。
DEFAULT_UPDATE_FEED_ALT = "https://raw.githubusercontent.com/guish207423-ux/xuexiton-release/main/latest.json"


def update_feed():
    vals = env_values()
    feed = (vals.get("UPDATE_FEED") or "").strip()
    fixed = (vals.get("UPDATE_URL") or "").strip()
    if not feed and not fixed:
        feed = DEFAULT_UPDATE_FEED          # 未配置 → 用内置默认源（与命令行侧一致）
    return feed, fixed


def _ver_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")) or (0,)


def _http_get_json(url):
    req = Request(url, headers={"User-Agent": "xuexiton-panel/1.0"})
    with urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))


def check_update(force=False):
    """查最新版本（5 分钟缓存）。供前端弹「在线更新」横幅。"""
    feed, _fixed = update_feed()
    cur = read_version()
    info = {"current": cur, "latest": None, "has_update": False, "notes": "",
            "url": "", "url_raw": "", "sha256": "", "configured": bool(feed), "error": None}
    if not feed:
        return info
    now = time.time()
    cached = UPDATE_CACHE.get("info")
    if not force and cached and now - UPDATE_CACHE.get("t", 0) < 300:
        return cached
    try:
        sources = [feed]
        if feed == DEFAULT_UPDATE_FEED:
            sources.append(DEFAULT_UPDATE_FEED_ALT)
        data, last = None, None
        for src_url in sources:
            try:
                data = _http_get_json(src_url)
                break
            except Exception as e:  # noqa: BLE001 - 换下一个源，最后一个失败才报错
                last = e
        if data is None:
            raise last
        info["latest"] = str(data.get("version") or "")
        info["notes"] = str(data.get("notes") or "")
        info["url"] = str(data.get("url") or "")
        info["url_raw"] = str(data.get("url_raw") or "")
        info["sha256"] = str(data.get("sha256") or "")
        info["has_update"] = bool(info["latest"]) and _ver_tuple(info["latest"]) > _ver_tuple(cur)
    except Exception as e:  # noqa: BLE001 - 网络问题静默，不打扰用户
        info["error"] = "检查更新失败: %s" % e
    if not info["error"]:
        UPDATE_CACHE["info"] = info
        UPDATE_CACHE["t"] = now
    return info


def _prune_stale_assets(newdir, curdir):
    """删掉新版本已不再包含的旧前端构建产物（console-dist/assets 纯输出目录，不碰用户数据）。"""
    if not os.path.isdir(newdir) or not os.path.isdir(curdir):
        return 0
    try:
        keep = set(os.listdir(newdir))
        stale = [f for f in os.listdir(curdir) if f not in keep]
    except OSError:
        return 0
    n = 0
    for f in stale:
        try:
            os.remove(os.path.join(curdir, f))
            n += 1
        except OSError:
            pass
    return n


def _copy_update_tree(src, dst):
    """递归拷贝（跳过私有文件），返回拷贝文件数。"""
    n = 0
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if not _update_skip(d)]
        rel = os.path.relpath(root, src)
        tdir = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(tdir, exist_ok=True)
        for f in files:
            if _update_skip(f):
                continue
            shutil.copy2(os.path.join(root, f), os.path.join(tdir, f))
            n += 1
    return n


def _restart_after_update():
    """更新后自动重启 bridge 与 panel（独立进程执行，不随本进程退出而中断）。"""
    devnull = subprocess.DEVNULL
    if os.name == "nt":
        ps1 = os.path.join(HERE, "onclick.ps1")
        cmd = "Start-Sleep 2; & '%s' stop bridge; & '%s' panel" % (ps1, ps1)
        try:
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-Command", cmd], cwd=HERE,
                             stdin=devnull, stdout=devnull, stderr=devnull,
                             creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except OSError:
            pass
        return
    sh = os.path.join(HERE, "onclick.sh")
    cmd = ("sleep 2; bash '%s' stop bridge >/dev/null 2>&1; bash '%s' start bridge >/dev/null 2>&1; "
           "bash '%s' stop panel >/dev/null 2>&1; sleep 1; bash '%s' panel >/dev/null 2>&1"
           % (sh, sh, sh, sh))
    try:
        subprocess.Popen(["bash", "-c", cmd], cwd=HERE, stdin=devnull,
                         stdout=devnull, stderr=devnull, start_new_session=True)
    except OSError:
        pass


def apply_update():
    """下载 → 校验 → 解压 → 备份 → 覆盖程序文件 → 自动重启服务。"""
    info = check_update(force=True)
    if not info.get("configured"):
        return False, "未配置在线更新地址（在 deploy.env 里加 UPDATE_FEED=... 后重试）"
    if info.get("error"):
        return False, info["error"]
    if not info.get("has_update"):
        return False, "已是最新版本 v%s" % info.get("current")
    url, sha = info.get("url"), info.get("sha256")
    if not url:
        return False, "版本清单里缺少 url 字段"
    tmp = tempfile.mkdtemp(prefix="xuexiton-upd-")
    try:
        zpath = os.path.join(tmp, "u.zip")
        # CDN 下载同样会撞上重建窗口，url_raw 是同一份文件的备用地址
        tried, last = [], None
        for cand in (url, info.get("url_raw")):
            if not cand or cand in tried:
                continue
            tried.append(cand)
            try:
                req = Request(cand, headers={"User-Agent": "xuexiton-panel/1.0"})
                with urlopen(req, timeout=180) as r, open(zpath, "wb") as f:
                    shutil.copyfileobj(r, f)
                last = None
                break
            except Exception as e:  # noqa: BLE001 - 换下一个地址
                last = e
        if last is not None:
            return False, "下载更新包失败: %s" % last
        if sha:
            h = hashlib.sha256()
            with open(zpath, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
            if h.hexdigest().lower() != sha.lower():
                return False, "SHA256 校验失败，已中止（文件下载不完整）"
        xdir = os.path.join(tmp, "x")
        with zipfile.ZipFile(zpath) as z:
            for zi in z.infolist():
                z.extract(zi, xdir)
                mode = (zi.external_attr >> 16) & 0o777
                tgt = os.path.join(xdir, zi.filename)
                if mode and os.path.exists(tgt):
                    try:
                        os.chmod(tgt, mode)
                    except OSError:
                        pass
        src = os.path.join(xdir, "deploy")
        if not os.path.isdir(src):
            src = xdir
        if not os.path.isfile(os.path.join(src, "panel.py")):
            return False, "更新包结构不对（缺 panel.py），已中止，什么都没改"
        # 备份当前程序（保留最近 2 份，更旧的自动清理——对齐 update.sh 策略）
        try:
            olds = sorted((d for d in os.listdir(HERE) if d.startswith("备份-更新前-")),
                          reverse=True)[2:]
            for d in olds:
                shutil.rmtree(os.path.join(HERE, d), ignore_errors=True)
        except OSError:
            pass
        bk = os.path.join(HERE, "备份-更新前-" + time.strftime("%Y%m%d-%H%M%S"))
        try:
            os.makedirs(bk, exist_ok=True)
            _copy_update_tree(HERE, bk)
        except OSError:
            pass
        # 覆盖（跳过私有文件）
        n = _copy_update_tree(src, HERE)
        # 清掉被新版本替换掉的旧前端构建产物，否则每次发版旧 chunk 都在 assets/ 里堆积
        pruned = _prune_stale_assets(os.path.join(src, "console-dist", "assets"),
                                     os.path.join(HERE, "console-dist", "assets"))

        # 清理已知的无用运行时残留（白名单；绝不触碰账号/配置/进度等私有数据）
        for junk in ("chaoxing.log", "config.docker.ini", "nohup.out"):
            try:
                os.remove(os.path.join(HERE, junk))
            except OSError:
                pass
        cache = os.path.join(HERE, "__pycache__")
        if os.path.isdir(cache):
            shutil.rmtree(cache, ignore_errors=True)

        # 更新后自检：关键文件完整性
        missing = [f for f in ("panel.py", "onclick.sh", "onclick.ps1", "bridge.py")
                   if not os.path.isfile(os.path.join(HERE, f))]
        if missing:
            return False, "更新后缺少关键文件：%s（备份在 %s，可手动拷回）" % (
                "、".join(missing), os.path.basename(bk))

        UPDATE_CACHE["info"] = None
        new_ver = read_version()
        _restart_after_update()
        return True, "已更新到 v%s（%d 个文件%s）。服务正在自动重启，几秒后本页会自动刷新…" % (
            new_ver, n, "，清理旧文件 %d 个" % pruned if pruned else "")
    except Exception as e:  # noqa: BLE001 - 面板兜底
        return False, "更新失败: %s" % e
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------- HTTP ----------

def build_state():
    accounts = load_accounts()
    tasks = load_tasks()
    dockers = engine_status()
    accs = []
    for a in accounts:
        cp = cookies_path(a["id"])
        cached = ""
        if os.path.exists(cp):
            try:
                cached = time.strftime("%m-%d %H:%M", time.localtime(os.path.getmtime(cp)))
            except OSError:
                cached = "有"
        accs.append({
            "id": a["id"], "name": a.get("name", ""), "username": mask(a.get("username", "")),
            "remark": a.get("remark", ""), "courses": a.get("courses", []),
            "speed": a.get("speed", 1), "jobs": a.get("jobs", 4),
            "work_redo": bool(a.get("work_redo")), "work_max_retries": a.get("work_max_retries", 3),
            "notopen_action": a.get("notopen_action", "retry"),
            "retry_interval": a.get("retry_interval", 1.0),
            "auto_sign": bool(a.get("auto_sign")),
            "cookies": cached,
        })
    name_of = {a["id"]: a.get("name", "") for a in accounts}
    tks = []
    for t in tasks:
        st = t["status"]
        logs = ""
        desc = ""
        if st == "running" and t["container"] in dockers:
            desc = dockers[t["container"]]
            logs = engine_logs(t["container"])
        elif st in ("done", "error", "stopped"):
            logs = t.get("logs_tail", "")
            if t.get("exit") is not None:
                desc = "退出码 %s" % t["exit"]
        tks.append({
            "id": t["id"], "account": t["account"], "acct_name": name_of.get(t["account"], t["account"]),
            "cid": t["cid"], "title": t.get("title", ""), "status": st, "status_cn": STATUS_CN.get(st, st),
            "status_desc": desc, "created": t.get("created", ""), "finished": t.get("finished", ""),
            "note": t.get("note", ""), "logs": logs,
            "retries": t.get("retries", 0), "next_ts": t.get("next_ts", 0),
            "err_class": t.get("err_class", ""),
            "progress": t.get("progress") or {},
            "scores": t.get("scores") or [], "accuracy": t.get("accuracy") or {},
        })
    return {"engine": engine_backend(), "accounts": accs, "tasks": tks}


class Handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_html(self, html):
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_console(self, raw):
        """优先从 console-dist/ 提供前端构建产物；不存在则回退旧内嵌页。"""
        index = os.path.join(CONSOLE_DIST, "index.html")
        if not os.path.isfile(index):
            return False
        rel = raw.lstrip("/") or "index.html"
        full = os.path.normpath(os.path.join(CONSOLE_DIST, rel))
        if not full.startswith(CONSOLE_DIST + os.sep) and full != index:
            self._send({"error": "bad path"}, 404)
            return True
        if not os.path.isfile(full):
            full = index  # SPA 回退
        try:
            data = open(full, "rb").read()
        except OSError:
            self._send({"error": "read error"}, 500)
            return True
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return True

    def _serve_stream(self):
        """SSE：每 2 秒推送一次全量状态，前端免刷新实时更新。"""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        try:
            while True:
                payload = json.dumps(build_state(), ensure_ascii=False)
                self.wfile.write(("data: " + payload + "\n\n").encode("utf-8"))
                self.wfile.flush()
                time.sleep(2)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def do_GET(self):
        raw, _, query = self.path.partition("?")
        path = raw.rstrip("/")
        q = {}
        for kv in query.split("&"):
            if "=" in kv:
                k, v = kv.split("=", 1)
                q[k] = v
        if path == "/api/state":
            self._send(build_state())
            return
        if path == "/api/services":
            self._send(api_services())
            return
        if path == "/api/bank":
            self._send(api_bank())
        if path == "/api/bank/augment":
            self._send(bank_augment_stats())
            return
        if path == "/api/update/check":
            self._send(check_update(force=("force" in q)))
            return
        if path == "/api/model":
            self._send(api_model())
            return
        if path == "/api/env":
            self._send(env_payload())
            return
        if path == "/api/export":
            self._send(export_data())
            return
        if path == "/api/notify":
            self._send(notify_payload())
            return
        if path == "/api/events":
            self._send({"events": load_events()})
            return
        if path == "/api/signwatch":
            self._send(api_signwatch())
            return
        if path == "/api/smart":
            self._send({"settings": load_settings(), "defaults": DEFAULT_SETTINGS})
            return
        if path == "/api/stream":
            self._serve_stream()
            return
        if path == "/api/logs":
            tail = 200
            try:
                tail = int(q.get("tail", "200"))
            except ValueError:
                pass
            self._send(api_logs(q.get("svc", ""), tail))
            return
        if raw.startswith("/api/"):
            self._send({"error": "not found"}, 404)
            return
        if self._serve_console(raw):
            return
        self._send_html(PAGE)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            payload = {}
        path = self.path.rstrip("/")
        try:
            if path == "/api/account/save":
                ok, msg = upsert_account(payload)
            elif path == "/api/account/delete":
                ok, msg = delete_account(str(payload.get("id", "")))
            elif path == "/api/account/fetch":
                ok, msg, _ = fetch_courses(str(payload.get("id", "")))
            elif path == "/api/account/autosign":
                ok, msg = api_account_autosign(
                    str(payload.get("id", "")), bool(payload.get("auto_sign")))
            elif path == "/api/course/save":
                ok, msg = save_courses(str(payload.get("account", "")), str(payload.get("text", "")))
            elif path == "/api/course/delete":
                ok, msg = delete_course(str(payload.get("account", "")), str(payload.get("cid", "")))
            elif path == "/api/task/start":
                cids = payload.get("cids") or []
                if isinstance(cids, str):
                    cids = [x for x in re.split(r"[,，\s]+", cids) if x]
                ok, msg = add_tasks(str(payload.get("account", "")), cids)
            elif path == "/api/task/stop":
                ok, msg = stop_task(str(payload.get("id", "")))
            elif path == "/api/task/remove":
                ok, msg = remove_task(str(payload.get("id", "")))
            elif path == "/api/task/clear":
                ok, msg = clear_done()
            elif path == "/api/model/chat":
                ok, msg, data = llama_chat(str(payload.get("prompt", "")),
                                           payload.get("max_tokens", 256))
                self._send({"ok": ok, "message": msg, **data})
                return
            elif path == "/api/model/switch":
                ok, msg = model_switch(str(payload.get("path", "")))
            elif path == "/api/service":
                ok, msg = service_action(str(payload.get("name", "")), str(payload.get("action", "")))
            elif path == "/api/env":
                ok, msg = env_save(payload)
            elif path == "/api/reset":
                ok, msg = reset_data(str(payload.get("what", "")))
            elif path == "/api/notify":
                ok, msg = notify_save(payload)
            elif path == "/api/smart":
                ok, msg = save_settings(payload)
            elif path == "/api/task/retry":
                ok, msg = retry_task(str(payload.get("id", "")))
            elif path == "/api/bank/adopt":
                ok, msg = adopt_quarantine(str(payload.get("question", "")))
            elif path == "/api/bank/drop":
                quarantine_remove(str(payload.get("question", "")))
                ok, msg = True, "已移出隔离区"
            elif path == "/api/bank/sync":
                ok, msg = harvest_all_caches()
            elif path == "/api/bank/clear_quarantine":
                ok, msg = clear_quarantine()
            elif path == "/api/bank/ai-fill":
                ok, msg = bank_ai_fill(payload.get("limit", 10))
            elif path == "/api/bank/augment/adopt":
                ok, msg = bank_adopt(payload.get("ids", []), bool(payload.get("all")))
            elif path == "/api/bank/augment/drop":
                ok, msg = bank_drop_suggestions(payload.get("ids", []), bool(payload.get("all")))
            elif path == "/api/bank/augment/export":
                ok, msg, pack = bank_export_pack()
                if ok:
                    self._send({"ok": True, "message": msg, "pack": pack})
                    return
            elif path == "/api/bank/augment/import":
                ok, msg = bank_import_pack(payload.get("pack"))
            elif path == "/api/signwatch":
                act = str(payload.get("action", ""))
                aid = str(payload.get("account", ""))
                if act == "start":
                    ok, msg = launch_signwatch(aid)
                elif act == "stop":
                    ok, msg = stop_signwatch(aid)
                else:
                    ok, msg = False, "未知动作: %s" % act
            elif path == "/api/update/apply":
                ok, msg = apply_update()
            else:
                self._send({"error": "not found"}, 404)
                return
        except Exception as e:  # 兜底：不让一个坏请求打垮面板
            ok, msg = False, "操作失败: %s" % e
        self._send({"ok": ok, "message": msg})


def save_courses(aid, text):
    items = parse_course_input(text)
    if not items:
        return False, "没识别到课程ID（格式：123 或 123 高数，可逗号分隔）"
    with LOCK:
        accounts = load_accounts()
        acc = find_account(accounts, aid)
        if acc is None:
            return False, "账号不存在"
        known = {c["cid"]: c for c in acc.setdefault("courses", [])}
        added = 0
        for it in items:
            if it["cid"] in known:
                if it["name"] and not known[it["cid"]].get("name"):
                    known[it["cid"]]["name"] = it["name"]
            else:
                acc["courses"].append(it)
                added += 1
        save_accounts(accounts)
        return True, "已添加 %d 门课程" % added


def delete_course(aid, cid):
    with LOCK:
        accounts = load_accounts()
        acc = find_account(accounts, aid)
        if acc is None:
            return False, "账号不存在"
        before = len(acc.get("courses", []))
        acc["courses"] = [c for c in acc.get("courses", []) if c["cid"] != cid]
        save_accounts(accounts)
        return True, "已删除" if len(acc["courses"]) < before else "课程不存在"


def _selfcheck():
    assert mask("13800001111") == "138****11"
    assert mask("") == ""
    assert mask("ab") == "**"
    items = parse_course_input("123,456 高数，789:线代;bad;")
    assert items == [
        {"cid": "123", "name": ""},
        {"cid": "456", "name": "高数"},
        {"cid": "789", "name": "线代"},
    ], items
    table = parse_course_table("x ID: 111 班级ID: 222 课程名: 高等数学（上）\nID:333 班级ID: 444 课程名: 大学英语")
    assert table == [
        {"cid": "111", "name": "高等数学（上）", "clazz": "222"},
        {"cid": "333", "name": "大学英语", "clazz": "444"},
    ], table
    acc = {"id": "selfchk", "username": "13800001111", "password": "pw",
           "speed": 2, "jobs": 6, "work_redo": True, "work_max_retries": 5,
           "notopen_action": "continue", "retry_interval": 2.5}
    path, err = write_run_config(acc)
    assert path and not err, err
    try:
        txt = open(path, encoding="utf-8").read()
        assert "username = 13800001111" in txt
        assert "password = pw" in txt
        assert "speed = 2" in txt and "jobs = 6" in txt
        assert "work_redo_enabled = true" in txt and "work_max_retries = 5" in txt
        assert "notopen_action = continue" in txt and "retry_interval = 2.5" in txt
        assert "course_list =" in txt
    finally:
        os.remove(path)
    assert remove_task("nope-nope")[0] is False
    assert stop_task("nope-nope")[0] is False
    assert sign_container("a1cdcc8") == "xxt-sign-a1cdcc8"
    assert sign_container("a1cdcc8") != PREFIX + "a1cdcc8" + "-123"
    assert stop_signwatch("nope-nope")[0] is False
    assert classify_error("网络超时 Timeout") == "transient"
    assert classify_error("用户名或密码错误") == "auth"
    assert classify_error("cookies 已失效，请更新") == "cookies"
    assert classify_error("普通错误") == "unknown"
    assert retry_task("nope-nope")[0] is False
    sc, ac = parse_scores("章节检测有 2/5 题回答错误（成绩 60 分）")
    assert sc == [{"score": 60.0, "wrong": 2, "total": 5}], sc
    assert ac == {"correct": 3, "total": 5, "percent": 60}, ac
    assert parse_scores("无成绩信息") == ([], {"correct": 0, "total": 0, "percent": 0})
    assert harvest_cache("nope-nope") == 0
    # 签到常驻意愿：落盘到临时文件，验证记录/清除，不碰真实 signwatch.json
    _sw = SIGNWATCH_FILE + ".selfcheck"
    try:
        set_signwatch_wanted("selfchk-aid", True, path=_sw)
        assert load_signwatch(_sw).get("selfchk-aid") is True
        set_signwatch_wanted("selfchk-aid", False, path=_sw)
        assert "selfchk-aid" not in load_signwatch(_sw)
    finally:
        if os.path.exists(_sw):
            os.remove(_sw)
    # 自动签到开关：只改 auto_sign，其它字段原样
    _accts = [{"id": "selfchk", "auto_sign": True, "username": "u", "courses": []}]
    assert apply_autosign(_accts, "selfchk", False) is True
    assert _accts[0]["auto_sign"] is False
    assert set(_accts[0]) == {"id", "auto_sign", "username", "courses"}
    assert apply_autosign(_accts, "nope-nope", True) is False
    # 路径可移植化：家目录路径写成 $HOME/...，其它原样
    assert _portable_path(os.path.expanduser("~/models/x.gguf")) == "$HOME/models/x.gguf"
    assert _portable_path("/etc/x") == "/etc/x"
    print("selfcheck ok")


def main():
    threading.Thread(target=scheduler_loop, daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print("刷课控制台: http://127.0.0.1:%d/  (Ctrl+C 退出)" % PORT)
    srv.serve_forever()


if __name__ == "__main__":
    if "--selfcheck" in sys.argv:
        _selfcheck()
    else:
        main()
