#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""题库自动扩充引擎（tiku-augment）

围绕「未命中题目」的完整闭环：统计 → 列表 → 本地 AI 补答 → 采纳入库 → 导出/导入分享。

直接操作题库 SQLite（WAL 并发安全，无需题库服务在线）；AI 补答调用本机 llama-server。
数据库位置：--db > 环境变量 XUEXITON_DB > deploy.env 的 TOOLKIT_DIR/tiku/questions.db

用法：
  ./tiku-augment stats                        统计报告（总数/高频/类型/近 7 天）
  ./tiku-augment list [--top N] [--json]      待处理题列表（按出现次数降序）
  ./tiku-augment ai-fill [--limit N]          本地 AI 为高频未命中题生成答案（存建议区）
  ./tiku-augment suggestions [--json]         查看 AI 建议答案
  ./tiku-augment adopt <id...> | --all        采纳建议 → 写入正式题库
  ./tiku-augment export <分享包.json>          导出分享包（题库+待处理题）
  ./tiku-augment import <分享包.json>          导入分享包（自动去重合并）
  ./tiku-augment dedup                        待处理表内部去重合并
"""
import argparse
import json
import os
import re
import sqlite3
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
PACK_FORMAT = "xuexiton-tiku-pack"
PACK_VERSION = 1


# ---------- 定位数据库 ----------
def env_values():
    out = {}
    p = os.path.join(HERE, "deploy.env")
    if os.path.isfile(p):
        with open(p, encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out[k.strip()] = os.path.expandvars(v.strip().strip('"').strip("'"))
    return out


def db_path(cli_arg=None):
    if cli_arg:
        return cli_arg
    if os.environ.get("XUEXITON_DB"):
        return os.environ["XUEXITON_DB"]
    td = os.environ.get("TOOLKIT_DIR") or env_values().get("TOOLKIT_DIR")
    if td:
        cand = os.path.join(td, "tiku", "questions.db")
        if os.path.isfile(cand):
            return cand
    raise SystemExit(
        "找不到题库数据库。请用 --db /path/to/questions.db 指定，"
        "或在 deploy.env 里配置 TOOLKIT_DIR。"
    )


def connect(path):
    conn = sqlite3.connect(path, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=8000")
    conn.execute(
        """CREATE TABLE IF NOT EXISTS ai_answers (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               pending_id INTEGER,
               question TEXT NOT NULL,
               type TEXT NOT NULL,
               options TEXT DEFAULT '[]',
               answer TEXT NOT NULL,
               model TEXT DEFAULT '',
               created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
           )"""
    )
    conn.commit()
    return conn


# ---------- 统计 ----------
def cmd_stats(conn, args):
    total = conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
    if getattr(args, "json", False):
        pend_rows = [dict(r) for r in conn.execute(
            "SELECT id, question, type, options, search_count FROM pending_questions "
            "ORDER BY search_count DESC, id")]
        print(json.dumps({
            "questions": total,
            "pending": conn.execute("SELECT COUNT(*) FROM pending_questions").fetchone()[0],
            "suggestions": conn.execute("SELECT COUNT(*) FROM ai_answers").fetchone()[0],
            "pending_items": pend_rows,
            "by_type": {str(r[0]): r[1] for r in conn.execute(
                "SELECT type, COUNT(*) FROM questions GROUP BY type")},
            "new_7d": conn.execute(
                "SELECT COUNT(*) FROM pending_questions "
                "WHERE created_at >= datetime('now','-7 days')").fetchone()[0],
        }, ensure_ascii=False))
        return
    pend = conn.execute("SELECT COUNT(*) FROM pending_questions").fetchone()[0]
    sugg = conn.execute("SELECT COUNT(*) FROM ai_answers").fetchone()[0]
    print("题库现状")
    print("  正式题目: %d" % total)
    print("  待处理题: %d" % pend)
    print("  AI 建议:  %d" % sugg)
    if pend:
        print("\n待处理题 · 按出现次数 Top 10")
        for r in conn.execute(
            "SELECT id, search_count, type, substr(question,1,46) q "
            "FROM pending_questions ORDER BY search_count DESC, id LIMIT 10"
        ):
            print("  [%s] x%-4d (t%s) %s" % (r["id"], r["search_count"], r["type"], r["q"]))
        print("\n待处理题 · 按题型")
        for r in conn.execute(
            "SELECT type, COUNT(*) c FROM pending_questions GROUP BY type ORDER BY c DESC"
        ):
            print("  type %s: %d" % (r["type"], r["c"]))
        print("\n近 7 天新增待处理题: %d" % conn.execute(
            "SELECT COUNT(*) FROM pending_questions "
            "WHERE created_at >= datetime('now','-7 days')").fetchone()[0])
    if total:
        print("\n正式题库 · 按题型")
        for r in conn.execute(
            "SELECT type, COUNT(*) c FROM questions GROUP BY type ORDER BY c DESC"
        ):
            print("  type %s: %d" % (r["type"], r["c"]))


# ---------- 列表 ----------
def cmd_list(conn, args):
    rows = conn.execute(
        "SELECT id, question, type, options, search_count, created_at "
        "FROM pending_questions ORDER BY search_count DESC, id LIMIT ?",
        (args.top,),
    ).fetchall()
    items = [dict(r) for r in rows]
    if args.json:
        print(json.dumps(items, ensure_ascii=False, indent=2))
        return
    if not items:
        print("没有待处理题目。")
        return
    for it in items:
        print("[%s] x%-4d (t%s) %s" % (it["id"], it["search_count"], it["type"], it["question"][:60]))
        opts = json.loads(it["options"] or "[]")
        if opts:
            print("      " + " | ".join(str(o)[:28] for o in opts))


# ---------- AI 补答 ----------
PROMPT = """你在解答中国大学生在线课程的题目。只输出答案，不要解释，不要 Markdown。

题型：{tp}
题目：{q}
{opts}
严格按以下格式输出一行 JSON：
- 单选题：{{"answer": "B"}}
- 多选题：{{"answer": "A#C"}}（多个选项字母用 # 连接，按字母升序）
- 判断题：{{"answer": "正确"}} 或 {{"answer": "错误"}}
- 填空题：{{"answer": "答案文本"}}"""

TYPE_NAME = {"0": "单选题", "1": "多选题", "2": "填空题", "3": "判断题"}


def llama_chat(prompt, port, timeout=180):
    body = {
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1,
        "max_tokens": 512,
        "stream": False,
    }
    req = urllib.request.Request(
        "http://127.0.0.1:%s/v1/chat/completions" % port,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        d = json.loads(r.read().decode("utf-8", "ignore"))
    return d["choices"][0]["message"]["content"]


def strip_think(text):
    """去掉模型可能输出的思考段。"""
    return re.sub(r"(?s) thinking.*?</think>", "", text or "").strip()


def parse_answer(text, qtype, options):
    """从模型输出提取并校验答案；不合法返回 None。"""
    body = strip_think(text)
    m = re.search(r'\{[^{}]*"answer"\s*:\s*"([^"]*)"[^{}]*\}', body)
    if not m:
        m2 = re.search(r'"answer"\s*:\s*"([^"]*)"', body)
        if not m2:
            return None
        raw = m2.group(1)
    else:
        raw = m.group(1)
    raw = raw.strip()
    if qtype == "3":
        if raw in ("正确", "对", "是", "T", "true", "True", "A"):
            return "正确"
        if raw in ("错误", "错", "否", "F", "false", "False", "B"):
            return "错误"
        return None
    if qtype == "1":
        letters = sorted(set(re.findall(r"[A-Za-z]", raw.upper())))
        if not letters:
            return None
        n = len(options) or 26
        letters = [c for c in letters if ord(c) - 65 < n]
        return "#".join(letters) if len(letters) >= 2 else (letters[0] if letters else None)
    if qtype == "0":
        letters = re.findall(r"[A-Za-z]", raw.upper())
        if not letters:
            return None
        c = letters[0]
        return c if ord(c) - 65 < (len(options) or 26) else None
    return raw or None


def cmd_ai_fill(conn, args):
    port = args.port
    rows = conn.execute(
        "SELECT p.id, p.question, p.type, p.options, p.search_count "
        "FROM pending_questions p "
        "LEFT JOIN ai_answers a ON a.pending_id = p.id "
        "WHERE a.id IS NULL "
        "ORDER BY p.search_count DESC, p.id LIMIT ?",
        (args.limit,),
    ).fetchall()
    if not rows:
        print("没有需要 AI 补答的题目（都有建议了）。")
        return
    print("将用本地 AI 处理 %d 道题（llama-server :%s）..." % (len(rows), port))
    ok = fail = 0
    for i, r in enumerate(rows, 1):
        opts = json.loads(r["options"] or "[]")
        opts_txt = ""
        if opts:
            opts_txt = "选项：\n" + "\n".join(
                "%s. %s" % (chr(65 + n), o) for n, o in enumerate(opts))
        prompt = PROMPT.format(tp=TYPE_NAME.get(r["type"], "未知"), q=r["question"], opts=opts_txt)
        try:
            out = llama_chat(prompt, port)
            ans = parse_answer(out, r["type"], opts)
        except urllib.error.URLError as e:
            print("  !! 连不上本地模型（127.0.0.1:%s）：%s" % (port, getattr(e, "reason", e)))
            print("     请先启动服务：./onclick.sh start llama（或控制台「总览」里启动 AI 模型）")
            return
        except Exception as e:  # noqa: BLE001
            print("  [%s] 调用失败: %s" % (r["id"], e))
            fail += 1
            continue
        if not ans:
            print("  [%s] 输出无法解析，跳过：%s" % (r["id"], strip_think(out)[:60].replace("\n", " ")))
            fail += 1
            continue
        print("  [%s] x%-3d t%s → %s" % (r["id"], r["search_count"], r["type"], ans))
        if not args.dry_run:
            conn.execute(
                "INSERT INTO ai_answers (pending_id, question, type, options, answer, model) "
                "VALUES (?,?,?,?,?,?)",
                (r["id"], r["question"], r["type"], r["options"] or "[]", ans, args.model),
            )
            conn.commit()
        ok += 1
        if args.limit == 1:
            break
    print("\n完成：成功 %d，失败 %d%s" % (ok, fail, "（演练，未写入）" if args.dry_run else ""))


def cmd_suggestions(conn, args):
    rows = conn.execute(
        "SELECT a.id, a.pending_id, a.question, a.type, a.options, a.answer, a.created_at, "
        "       p.search_count "
        "FROM ai_answers a LEFT JOIN pending_questions p ON p.id = a.pending_id "
        "ORDER BY (p.search_count IS NULL), p.search_count DESC, a.id"
    ).fetchall()
    items = [dict(r) for r in rows]
    if args.json:
        print(json.dumps(items, ensure_ascii=False, indent=2))
        return
    if not items:
        print("还没有 AI 建议。先运行: tiku-augment ai-fill")
        return
    for it in items:
        print("[建议 %s] 原题 #%s (x%s) %s" % (
            it["id"], it["pending_id"], it["search_count"], it["question"][:52]))
        print("         AI 答案: %s" % it["answer"])


def cmd_adopt(conn, args):
    if args.all:
        rows = conn.execute("SELECT * FROM ai_answers").fetchall()
    else:
        if not args.ids:
            raise SystemExit("用法: tiku-augment adopt <建议id...> | --all")
        qs = ",".join("?" * len(args.ids))
        rows = conn.execute("SELECT * FROM ai_answers WHERE id IN (%s)" % qs, args.ids).fetchall()
    if not rows:
        print("没有匹配的建议。")
        return
    added = 0
    for r in rows:
        # 已存在同题则不重复入库
        exist = conn.execute(
            "SELECT id FROM questions WHERE question = ? AND type = ?",
            (r["question"], r["type"]),
        ).fetchone()
        if not exist:
            conn.execute(
                "INSERT INTO questions (question, type, options, answer) VALUES (?,?,?,?)",
                (r["question"], r["type"], r["options"] or "[]", r["answer"]),
            )
            added += 1
        conn.execute("DELETE FROM pending_questions WHERE id = ?", (r["pending_id"],))
        conn.execute("DELETE FROM ai_answers WHERE id = ?", (r["id"],))
        print("  采纳 #%s → %s（%s）" % (r["pending_id"], r["answer"], r["question"][:40]))
    conn.commit()
    print("\n完成：新入库 %d 题，其余为重复跳过；对应待处理题已清除。" % added)


# ---------- 导出 / 导入 ----------
def cmd_export(conn, args):
    questions = [dict(r) for r in conn.execute(
        "SELECT question, type, options, answer FROM questions")]
    pending = [dict(r) for r in conn.execute(
        "SELECT question, type, options, search_count FROM pending_questions")]
    pack = {
        "format": PACK_FORMAT,
        "version": PACK_VERSION,
        "exported_at": __import__("time").strftime("%Y-%m-%d %H:%M:%S"),
        "count": {"questions": len(questions), "pending": len(pending)},
        "questions": questions,
        "pending": pending,
    }
    with open(args.file, "w", encoding="utf-8") as f:
        json.dump(pack, f, ensure_ascii=False, indent=1)
    print("已导出分享包: %s" % args.file)
    print("  正式题目 %d 题 / 待处理 %d 题" % (len(questions), len(pending)))
    print("  把它发给同学，对方用 `tiku-augment import %s` 合并即可。" % os.path.basename(args.file))


def cmd_import(conn, args):
    with open(args.file, encoding="utf-8") as f:
        pack = json.load(f)
    if pack.get("format") != PACK_FORMAT:
        raise SystemExit("不是有效的分享包（format 字段不匹配）。")
    q_add = q_dup = p_merge = p_new = 0
    for q in pack.get("questions", []):
        exist = conn.execute(
            "SELECT id FROM questions WHERE question = ? AND type = ?",
            (q["question"], str(q.get("type", "0"))),
        ).fetchone()
        if exist:
            q_dup += 1
            continue
        conn.execute(
            "INSERT INTO questions (question, type, options, answer) VALUES (?,?,?,?)",
            (q["question"], str(q.get("type", "0")),
             json.dumps(q.get("options") or [], ensure_ascii=False),
             str(q.get("answer", ""))),
        )
        q_add += 1
    for p in pack.get("pending", []):
        exist = conn.execute(
            "SELECT id, search_count FROM pending_questions WHERE question = ?",
            (p["question"],),
        ).fetchone()
        if exist:
            conn.execute(
                "UPDATE pending_questions SET search_count = search_count + ?, "
                "updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (int(p.get("search_count") or 1), exist["id"]),
            )
            p_merge += 1
        else:
            conn.execute(
                "INSERT INTO pending_questions (question, type, options, search_count) "
                "VALUES (?,?,?,?)",
                (p["question"], str(p.get("type", "0")),
                 json.dumps(p.get("options") or [], ensure_ascii=False),
                 int(p.get("search_count") or 1)),
            )
            p_new += 1
    conn.commit()
    print("导入完成：")
    print("  正式题目：新增 %d，重复跳过 %d" % (q_add, q_dup))
    print("  待处理题：新增 %d，合并（次数累加）%d" % (p_new, p_merge))


def cmd_dedup(conn, args):
    rows = conn.execute(
        "SELECT question, SUM(search_count) c, MIN(id) keep, COUNT(*) n "
        "FROM pending_questions GROUP BY question HAVING n > 1"
    ).fetchall()
    if not rows:
        print("待处理表没有重复项。")
        return
    for r in rows:
        conn.execute("UPDATE pending_questions SET search_count = ? WHERE id = ?",
                     (r["c"], r["keep"]))
        conn.execute("DELETE FROM pending_questions WHERE question = ? AND id != ?",
                     (r["question"], r["keep"]))
        print("  合并 %d 条 → [%s] x%d %s" % (r["n"], r["keep"], r["c"], r["question"][:40]))
    conn.commit()
    print("\n完成：合并 %d 组。" % len(rows))


def cmd_drop_suggestions(conn, args):
    """丢弃 AI 建议（不影响正式题库；对应待处理题保留，可再次补答）。"""
    if args.all:
        rows = conn.execute("SELECT id, pending_id, question FROM ai_answers").fetchall()
    else:
        if not args.ids:
            raise SystemExit("用法: tiku-augment drop-suggestions <建议id...> | --all")
        qs = ",".join("?" * len(args.ids))
        rows = conn.execute("SELECT id, pending_id, question FROM ai_answers WHERE id IN (%s)" % qs,
                            args.ids).fetchall()
    if not rows:
        print("没有匹配的建议。")
        return
    for r in rows:
        conn.execute("DELETE FROM ai_answers WHERE id = ?", (r["id"],))
        print("  丢弃建议 #%s（原题 #%s %s）" % (r["id"], r["pending_id"], r["question"][:36]))
    conn.commit()
    print("\n完成：丢弃 %d 条建议（待处理题仍在，可重新 AI 补答）。" % len(rows))


def main():
    ap = argparse.ArgumentParser(prog="tiku-augment", description="题库自动扩充引擎")
    ap.add_argument("--db", help="questions.db 路径（默认取 deploy.env 的 TOOLKIT_DIR）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_stats = sub.add_parser("stats", help="统计报告")
    p_stats.add_argument("--json", action="store_true")

    p_list = sub.add_parser("list", help="待处理题列表")
    p_list.add_argument("--top", type=int, default=50)
    p_list.add_argument("--json", action="store_true")

    p_fill = sub.add_parser("ai-fill", help="本地 AI 为未命中题生成答案")
    p_fill.add_argument("--limit", type=int, default=20)
    p_fill.add_argument("--port", default=os.environ.get("LLAMA_PORT", "8080"))
    p_fill.add_argument("--model", default="local")
    p_fill.add_argument("--dry-run", action="store_true", help="只演练不写入")

    p_sug = sub.add_parser("suggestions", help="查看 AI 建议答案")
    p_sug.add_argument("--json", action="store_true")

    p_drop = sub.add_parser("drop-suggestions", help="丢弃 AI 建议（待处理题保留）")
    p_drop.add_argument("ids", nargs="*", type=int)
    p_drop.add_argument("--all", action="store_true")

    p_ad = sub.add_parser("adopt", help="采纳建议入库")
    p_ad.add_argument("ids", nargs="*", type=int, help="建议 id 列表")
    p_ad.add_argument("--all", action="store_true", help="采纳全部")

    p_ex = sub.add_parser("export", help="导出分享包")
    p_ex.add_argument("file")

    p_im = sub.add_parser("import", help="导入分享包")
    p_im.add_argument("file")

    sub.add_parser("dedup", help="待处理表去重合并")

    args = ap.parse_args()
    conn = connect(db_path(args.db))
    try:
        {
            "stats": cmd_stats,
            "list": cmd_list,
            "ai-fill": cmd_ai_fill,
            "suggestions": cmd_suggestions,
            "adopt": cmd_adopt,
            "drop-suggestions": cmd_drop_suggestions,
            "export": cmd_export,
            "import": cmd_import,
            "dedup": cmd_dedup,
        }[args.cmd](conn, args)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
