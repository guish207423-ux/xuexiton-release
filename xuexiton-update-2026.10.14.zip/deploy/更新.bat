﻿@echo off
chcp 65001 >nul
rem ============================================================
rem  更新 deploy 程序文件（本地 zip 或直链下载）
rem  用法:
rem    把更新包 zip 拖到本文件上，或: 更新.bat <zip路径|下载链接>
rem    也可在 deploy.env 设置 UPDATE_URL=... 后直接双击本文件
rem  安全: 只覆盖程序文件；accounts.json / cookies / config.ini /
rem        deploy.env / tasks.json 等私有文件永不被触碰。
rem ============================================================
setlocal enabledelayedexpansion
if exist "%~dp0deploy\panel.py" ( set "DEPLOY=%~dp0deploy" ) else if exist "%~dp0panel.py" ( set "DEPLOY=%~dp0" ) else (
  echo 找不到 deploy 目录。请把本脚本放在 deploy 文件夹里（或旁边）再运行。
  pause & exit /b 1
)

set "ING=%~1"
if "%ING%"=="" if exist "%DEPLOY%\deploy.env" (
  for /f "usebackq tokens=1,* delims==" %%a in ("%DEPLOY%\deploy.env") do (
    if /i "%%a"=="UPDATE_URL" set "ING=%%b"
  )
)
if "%ING%"=="" (
  echo 用法: 把更新包 zip 拖到本文件上，或: 更新.bat ^<zip路径或下载链接^>
  echo 提示: 也可以先在 deploy.env 里设置 UPDATE_URL=...
  pause & exit /b 1
)

set "TMP=%TEMP%\xuexiton-upd-%RANDOM%%RANDOM%"
mkdir "%TMP%"
set "ZIP=%ING%"
set "IS_URL="
if /i "!ING:~0,7!"=="http://" set "IS_URL=1"
if /i "!ING:~0,8!"=="https://" set "IS_URL=1"
if defined IS_URL (
  echo == 下载: %ING%
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "try { Invoke-WebRequest -Uri '%ING%' -OutFile '%TMP%\u.zip' -UseBasicParsing -TimeoutSec 180 } catch { Write-Host '下载失败（GitHub 直链在国内可能不稳，可换网盘直链或让对方直接传文件）'; exit 1 }"
  if errorlevel 1 ( pause & exit /b 1 )
  set "ZIP=%TMP%\u.zip"
)

call "%~dp0应用更新.bat" "%ZIP%"
if errorlevel 1 ( pause & exit /b 1 )
rmdir /s /q "%TMP%" 2>nul
pause
