/* xuexiton GM shims —— 为「学习通脚本.js」在普通 Chrome 扩展环境里补齐油猴 API（最小实现）。
   运行于隔离世界；DOM / Cookie 与页面共享，网络走 fetch（本地服务均已配置 CORS）。 */
(function () {
  if (typeof GM_info !== "undefined") return; // 已在油猴环境 → 不重复注入

  var PREFIX = "xxt_";
  var RES = (typeof __XXT_RESOURCES !== "undefined") ? __XXT_RESOURCES : {}; // 由构建脚本注入

  function cookie(name) {
    var m = document.cookie.match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
    return m ? decodeURIComponent(m[1]) : "";
  }

  window.GM_info = { script: { name: "xuexiton-bundled", version: "2.1.6" } };

  window.GM_getValue = function (k, d) {
    try { var v = localStorage.getItem(PREFIX + k); return v === null ? d : JSON.parse(v); }
    catch (e) { return d; }
  };
  window.GM_setValue = function (k, v) {
    try { localStorage.setItem(PREFIX + k, JSON.stringify(v)); } catch (e) {}
  };
  window.GM_addStyle = function (css) {
    var s = document.createElement("style");
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
    return s;
  };
  window.GM_getResourceText = function (name) { return RES[name] || ""; };
  window.GM_xmlhttpRequest = function (opts) {
    var ctl = new AbortController();
    var timer = opts.timeout ? setTimeout(function () { ctl.abort(); }, opts.timeout) : null;
    fetch(opts.url, {
      method: opts.method || "GET",
      headers: opts.headers || {},
      body: opts.data,
      signal: ctl.signal,
      credentials: "omit"
    })
      .then(function (r) {
        return r.text().then(function (t) {
          if (timer) clearTimeout(timer);
          if (opts.onload) opts.onload({ status: r.status, statusText: r.statusText, responseText: t, response: t, finalUrl: r.url });
        });
      })
      .catch(function (e) {
        if (timer) clearTimeout(timer);
        if (opts.onerror) opts.onerror({ error: e, status: 0 });
      });
  };

  // unsafeWindow：页面全局的替身。uid / getCookie 从 document.cookie 解析，其余透传。
  window.unsafeWindow = new Proxy(window, {
    get: function (t, prop) {
      if (prop === "uid") return t.uid || cookie("_uid");
      if (prop === "getCookie") return function (n) { return cookie(n); };
      return Reflect.get(t, prop);
    }
  });
})();
