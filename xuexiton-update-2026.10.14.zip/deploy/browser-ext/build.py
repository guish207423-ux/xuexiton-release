#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""重建 bundle.js：shims + 资源内联 + 依赖库 + 学习通脚本（原文）。
    在 browser-ext/ 目录下运行：python3 build.py
    修改 shims.js 或更新 userscript 后重跑即可。"""
import json
import pathlib

d = pathlib.Path(__file__).resolve().parent

LIBS = [
    "vendor/vue.global.prod.js",
    "vendor/vue-demi.iife.min.js",
    "vendor/pinia.iife.prod.js",
    "vendor/element-plus.full.min.js",
    "vendor/md5.min.js",
    "vendor/jquery.min.js",
]
USERSCRIPT = d.parent / "userscript" / "学习通脚本.js"

parts = []
parts.append((d / "shims.js").read_text(encoding="utf-8"))

css = (d / "vendor" / "element-plus.css").read_text(encoding="utf-8")
ttf_path = d / "vendor" / "ttf-table.json"
ttf = ttf_path.read_text(encoding="utf-8") if ttf_path.exists() else "{}"
parts.append(
    "var __XXT_RESOURCES = "
    + json.dumps({"element-plus": css, "ttf": ttf}, ensure_ascii=False)
    + ";"
)

for name in LIBS:
    parts.append((d / name).read_text(encoding="utf-8"))

parts.append(USERSCRIPT.read_text(encoding="utf-8"))

out = d / "bundle.js"
out.write_text("\n;\n".join(parts), encoding="utf-8")
print(f"OK bundle.js {out.stat().st_size} bytes  (libs: {len(LIBS)}, css: {len(css)}, ttf: {len(ttf)})")
