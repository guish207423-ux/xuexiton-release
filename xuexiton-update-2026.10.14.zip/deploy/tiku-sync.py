#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tiku-sync.py — 题库同步工具：把 chaoxing-toolkit 题库灌入 tikuAdapter 聚合题库

背景：
  tikuAdapter 用 MD5(question + json(排序后选项) + type + plat) 精确匹配本地题库，
  hash 由 tikuAdapter 自己计算。本工具通过它提供的 HTTP API 批量写入，
  避免手工拼 hash 造成的格式不一致（旧版迁移脚本即因此失败）。

用法：
  python3 tiku-sync.py                 # 默认路径同步
  python3 tiku-sync.py --check         # 只检查两边数量，不写入
  python3 tiku-sync.py --questions DB  # 指定 questions.db 路径
  python3 tiku-sync.py --adapter URL   # 指定 tikuAdapter 地址（默认 127.0.0.1:8060）
  python3 tiku-sync.py --reset         # 先清空 tikuAdapter 本地题库再灌入

退出码：0 成功；1 参数/连接错误；2 部分失败
"""
import argparse
import json
import os
import sqlite3
import sys
import urllib.request

DEFAULT_QUESTIONS = os.path.expanduser("~/Projects/chaoxing-lab/chaoxing-toolkit/tiku/questions.db")
DEFAULT_ADAPTER = "http://127.0.0.1:8060"
DEFAULT_TIKU_DB = os.path.expanduser("~/Projects/chaoxing-lab/tiku-run/tiku.db")

# 绕过系统代理（feeds 在本机）
_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def post_json(url, payload, timeout=60):
    req = urllib.request.Request(url, json.dumps(payload, ensure_ascii=False).encode(),
                                 {"Content-Type": "application/json"})
    with _opener.open(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def answer_to_texts(qtype, answer, options):
    """题库 answer（单字母 / 字母串 / 判断题文本）→ 选项文本数组（tikuAdapter 期望格式）"""
    t = int(qtype)
    if t == 3:  # 判断题：规范化为 正确/错误
        if answer in ("正确", "对", "√", "是", "A", "T", "ri", "true"):
            return ["正确"]
        if answer in ("错误", "错", "×", "否", "B", "F", "fa", "false"):
            return ["错误"]
        return [answer]
    letters = [c for c in answer.replace("#", "").upper() if c in "ABCDEFGHIJ"]
    return [options[ord(c) - 65] for c in letters if ord(c) - 65 < len(options)]


def load_questions(db_path):
    db = sqlite3.connect(db_path)
    cur = db.cursor()
    cur.execute("SELECT question, type, options, answer FROM questions")
    rows = cur.fetchall()
    db.close()
    return rows


def build_payload(rows):
    payload = []
    skipped = 0
    for q, t, o, a in rows:
        try:
            opts = json.loads(o) if o else []
        except Exception:
            opts = []
        t = int(t)
        texts = answer_to_texts(t, str(a), opts)
        if not texts or not q:
            skipped += 1
            continue
        payload.append({
            "question": q,
            "type": t,
            "options": json.dumps(opts, ensure_ascii=False),
            "answer": json.dumps(texts, ensure_ascii=False),
            "plat": 0,
            "course_name": "",
        })
    return payload, skipped


def main():
    ap = argparse.ArgumentParser(description="同步题库到 tikuAdapter")
    ap.add_argument("--questions", default=DEFAULT_QUESTIONS, help="questions.db 路径")
    ap.add_argument("--adapter", default=DEFAULT_ADAPTER, help="tikuAdapter 地址")
    ap.add_argument("--tiku-db", default=DEFAULT_TIKU_DB, help="tiku adapter 的 tiku.db 路径（--reset 用）")
    ap.add_argument("--check", action="store_true", help="只检查不写入")
    ap.add_argument("--reset", action="store_true", help="先清空 tikuAdapter 本地题库")
    ap.add_argument("--batch", type=int, default=300, help="每批条数（默认 300）")
    args = ap.parse_args()

    if not os.path.exists(args.questions):
        print(f"!! 找不到题库: {args.questions}")
        return 1

    # 1. tikuAdapter 在线检查
    try:
        post_json(args.adapter + "/adapter-service/search?use=local",
                  {"question": "__ping__", "type": 0, "options": []}, timeout=5)
    except Exception as e:
        print(f"!! tikuAdapter 未响应（{args.adapter}）：{e}")
        print("   请先启动 tikuAdapter 后重试")
        return 1

    rows = load_questions(args.questions)
    print(f"源题库: {len(rows)} 题")

    if args.check:
        if os.path.exists(args.tiku_db):
            n = sqlite3.connect(args.tiku_db).execute("SELECT COUNT(*) FROM tiku").fetchone()[0]
            print(f"tikuAdapter 本地题库（{args.tiku_db}）: {n} 条")
        return 0

    if args.reset:
        n = sqlite3.connect(args.tiku_db).execute("SELECT COUNT(*) FROM tiku").fetchone()[0]
        sqlite3.connect(args.tiku_db).execute("DELETE FROM tiku")
        print(f"已清空 tikuAdapter 本地题库（{n} 条）")

    payload, skipped = build_payload(rows)
    print(f"待写入: {len(payload)} 题" + (f"（跳过 {skipped} 题不完整）" if skipped else ""))

    total, failed = 0, 0
    for i in range(0, len(payload), args.batch):
        chunk = payload[i:i + args.batch]
        try:
            msg = post_json(args.adapter + "/adapter-service/questions", chunk).get("message", "")
            n = int("".join(c for c in msg if c.isdigit()) or 0)
            total += n
            print(f"批次 {i // args.batch + 1}: {msg}")
        except Exception as e:
            failed += 1
            print(f"批次 {i // args.batch + 1} 失败: {e}")

    print(f"\n完成：写入 {total} 题，失败批次 {failed}")

    # 抽样验证
    sample = payload[:3]
    hit = 0
    for item in sample:
        try:
            d = post_json(args.adapter + "/adapter-service/search?use=local",
                          {"question": item["question"], "type": item["type"],
                           "options": json.loads(item["options"])}, timeout=10)
            if (d.get("answer") or {}).get("bestAnswer"):
                hit += 1
        except Exception:
            pass
    print(f"抽样验证: {hit}/{len(sample)} 命中")
    return 2 if (failed or hit < len(sample)) else 0


if __name__ == "__main__":
    sys.exit(main())
