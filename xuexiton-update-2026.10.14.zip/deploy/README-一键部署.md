# 一键部署与使用说明（Linux / Windows · 小白版）

启动后本地会跑起一套「超星学习通自动答题」工具：本地 AI 答题 + 题库管理 + 两种用法（浏览器可视化 / 命令行）。

## 🚀 60 秒上手（已完成安装的话，看这三行就够）

| 步骤 | 怎么做 | 说明 |
|---|---|---|
| 1️⃣ 启动 | Windows **双击 `onclick.bat`**；Linux 终端 `./onclick.sh start` | 自动拉起全部服务并打开控制台 |
| 2️⃣ 开刷 | 双击 `onclick.bat browser` → 登录你自己的学习通 → 页面右下角面板点「开始」 | 免装油猴的专用浏览器 |
| 3️⃣ 管理 | 控制台 <http://127.0.0.1:8003/>：多账号 / 课程 / 任务 / 实时日志 | 两个网页后台都不需要密码 |

> **还没安装？** 插上 U 盘 → 双击 U 盘里的 `安装.bat`（Linux 在 U 盘目录跑 `bash 安装.sh`）→ 安装完问「现在启动吗？」直接回车，即完成从安装到启动的全部过程。详见 U 盘里的《使用说明.md》。

## ⚠️ 先读这三条（重要，能省你半小时）

1. **本工具不提供学习通账号**。你需要用自己平时看网课的那个账号（学校给你注册的学号 / 手机号 + 密码）。工具里没有、也无法附带任何账号。
2. **启动完就能直接打开的，是两个网页后台，都不需要密码**：
   - 本地题库管理：<http://127.0.0.1:8001/>（1036 道题：搜索 / 导入 / 待处理）
   - 聚合题库：<http://127.0.0.1:8060/>（多个题库源的开关）
3. **「自动刷课 / 自动答题」本身是在浏览器里进行的**：一条命令（`browser`）会打开一个**已装好脚本的专用浏览器**（免装油猴），登录一次即可，见第四节。

## 一、一键启动 / 停止

**Linux**（终端里，路径按你的实际位置改）：

```bash
cd ~/Desktop/xuexiton/deploy
./onclick.sh start     # 启动全部服务（含管理控制台），随后自动打开控制台页面
```

**Windows**：进入 `deploy` 文件夹，**双击 `onclick.bat`**——一键启动全部服务，并自动在浏览器打开管理控制台。（也可命令行 `onclick.bat start`。）

看到「就绪情况」清单 = 启动成功；浏览器会自动弹到管理控制台（<http://127.0.0.1:8003/>）。

- **单独启停某个服务**：`./onclick.sh start tiku` / `./onclick.sh stop tiku`（Windows 同：`onclick.bat start tiku`）。服务名：`llama-server` / `tiku` / `tikuAdapter` / `bridge` / `panel`。管理控制台「总览」页也有每个服务的启停按钮。
- **Docker 刷课镜像**（命令行版用）：装机/首次启动后一般已自动就绪；想手动检查或重试：`./onclick.sh docker`（Windows：`onclick.bat docker`）——已有则秒回「已就绪」，没有则自动导入或构建（带进度）。

- **打开专用浏览器（推荐）**：`./onclick.sh browser`（Windows：`onclick.bat browser`）——已预装脚本，免装油猴；登录一次学习通后免重复登录。
- **命令行开刷（不用浏览器）**：`./onclick.sh run`（Windows：`onclick.bat run`）——直接按提示填账号 / 密码 / 课程ID 就开刷，见方式 B。
- **管理控制台（多账号一起刷）**：`./onclick.sh panel`（Windows：`onclick.bat panel`）→ 浏览器打开 <http://127.0.0.1:8003/>：七个页面（总览 / 账号 / 课程 / 任务 / 题库 / 日志 / 设置）——多账号与课程管理、速率参数、任务队列（同账号串行 / 不同账号并行）、五服务独立启停、实时日志。内置智能系统：失败任务自动分类重试（退避 + 上限）、服务掉线自动拉起、完成 / 失败通知、容器自动清理。
- 停止：`./onclick.sh stop`（Windows：`onclick.bat stop`）
- 查看状态：`./onclick.sh status`（Windows 同）
- **换新电脑先自检**：`./onclick.sh check`（Windows：`onclick.bat check`）——逐项列出依赖 / 文件 / 端口哪些 OK、哪些缺，缺什么一目了然。
- 日志：Linux `/tmp/xuexiton-deploy/`，Windows `%TEMP%\xuexiton-deploy\`

首次启动会自动完成（无需手动）：加载 AI 模型（1-3 分钟）；若题库后台前端未构建自动构建（约 1 分钟）；Windows 首次还会自动安装 Python 依赖（1-2 分钟）。

## 二、换一台新电脑要先准备什么

| 组件 | 必需？ | 怎么弄 |
|---|---|---|
| llama.cpp 的 `llama-server` + 一个 GGUF 模型 | 要用 AI 答题则需要 | 官方 release 下载（Windows 选 vulkan 版）；模型放 `~/models`（Win：`%USERPROFILE%\models`），或改 `deploy.env` 的 `MODEL_PATH` / `MODELS_DIR` |
| Python 3 | 题库后台 / 桥接需要 | Linux 一般自带；Windows 从 python.org 装并勾 **Add to PATH** |
| chaoxing-toolkit 目录（含 `tiku/`，1036 题） | 要用本地题库则需要 | 没有则自动跳过，纯 AI 模式仍可用；换机需一并拷贝该目录（或改 `deploy.env` 的 `TOOLKIT_DIR`） |
| tikuAdapter 二进制 | 可选 | 聚合多题库源；有则自动启动（或改 `TIKU_ADAPTER_BIN`） |
| Node.js + npm | 可选 | 仅在「题库后台前端未构建」的首次构建时需要 |
| Docker + `chaoxing:local` 镜像 | 仅命令行版 `run` 需要 | 镜像**不会自带**，需在 chaoxing 源码目录执行 `docker build -t chaoxing:local .`；换机请一并拷贝该源码目录 |

> **一句话换机清单**：把整个 `deploy/` 文件夹拷过去，再按上表备好 `llama-server` + 一个 GGUF 模型即可（其余可选项缺了会自动跳过）。落地后先跑一次 `./onclick.sh check` 看缺什么。**三个外部目录**（chaoxing-toolkit、tiku-run、chaoxing 源码）若不在默认位置，在 `deploy.env` 里改 `TOOLKIT_DIR` / `TIKU_ADAPTER_BIN` / 构建镜像时的路径即可。

> ⚠️ **换机前先处理 `deploy.env`**：若你已经用过控制台「模型」页的切换功能，会生成一个 `deploy.env`，其中 `MODEL_PATH` 可能被写成**旧机器的绝对路径**——换机后请把它改成新机器的路径（或直接删掉 `deploy.env` 用默认值）。其余键都用 `$HOME` 开头，会自动适配。

> 🔒 **以下文件是私有登录态/运行数据，不要随包外传**（换机可重建，或单独安全迁移）：`accounts.json`（账号）、`cookies*.txt`（会话 cookie）、`config.ini` / `config.run.*.ini`（含账号密码）、`deploy.env`、`tasks.json` / `events.json` / `settings.json` / `harvest.json` / `cache*.json`（任务与运行记录）。已在 `deploy/.gitignore` 中登记。

所有路径都在 `deploy.env.example` 里（复制为 `deploy.env` 后修改；默认已按本机配置好）。共 15 个键：`LLAMA_BIN`、`MODEL_PATH`、`MODELS_DIR`、`LOG_DIR`、`TOOLKIT_DIR`、`TIKU_ADAPTER_BIN`、`TIKU_ADAPTER_DIR`、5 个端口（`LLAMA_PORT`/`TIKU_PORT`/`ADAPTER_PORT`/`BRIDGE_PORT`/`PANEL_PORT`）、`LLAMA_NGL`、`LLAMA_DEV`、`LLAMA_CTX`。

## 三、五个服务与端口（哪些有网页、要不要密码）

| 服务 | 端口 | 打开后能看到什么 | 要密码吗 |
|---|---|---|---|
| AI 模型（llama-server） | 8080 | 无网页（纯接口 `/v1/chat/completions`） | — |
| 题库管理后台 | 8001 | **有网页**：1036 题管理（两种玩法都先从这查题） | **不要** |
| 聚合题库 | 8060 | **有网页**：多题库源管理 | **不要** |
| 题库桥接 | 8002 | 无网页（给用户脚本和命令行版用的接口） | — |
| 管理控制台 | 8003 | **有网页**：控制台主界面——总览（服务启停）/ 账号 / 课程 / 任务 / 题库 / 日志 / 设置（`./onclick.sh panel` 启动） | **不要** |

## 四、启动之后，怎么开始用

### 方式 A · 推荐（免装油猴）：专用浏览器，一条命令打开

1. 运行 `./onclick.sh browser`（Windows：`onclick.bat browser`）→ 打开一个**已预装脚本的专用浏览器**（不用装 Tampermonkey）。数据保存在 `~/.xuexiton-browser`（Windows：`C:\Users\你的用户名\.xuexiton-browser`），**登录一次学习通后不再重复要求登录**。
2. 在这个浏览器里登录**你自己的学习通账号**（只需第一次）→ 打开课程 → 页面右下角出现脚本面板。
3. 面板里按下表填好 → 脚本自动开始答题 / 视频 / 切换章节（面板能看到进度）。

| 面板位置 | 字段 | 填什么 |
|---|---|---|
| 基础配置 | 启用自定义题库 | 勾选；地址 = `http://127.0.0.1:8002/search`；密钥留空 |
| 基础配置 | 启用AI自动答题 | 勾选；AI API 地址 = `http://127.0.0.1:8080/v1/chat/completions`；AI模型名称 = `bonsai`（任意非空）；AI密钥 = `local`（任意非空） |
| 章节配置 | | 勾选 自动答题 / 自动视频 / 自动切换 / 自动提交；最低正确率按需（默认 0.8） |
| 作业/考试配置 | | 按需勾选 考试自动切换 |

查题顺序：本地题库（8001）→ 聚合题库（8060）→ 都查不到才问本地 AI。

> 备选（效果相同）：用你平时的浏览器 + 油猴（Tampermonkey）安装 `userscript/学习通脚本.js`，填表内容一致。

### 方式 B · 命令行版（不用浏览器，推荐给想省事的）

一条命令，按提示填 3 样东西就开刷：

```bash
./onclick.sh run          # Windows: onclick.bat run
```

它做的事：
1. 提示填**你自己的**学习通手机号 + 密码（填过一次就保存在本地 `config.ini`，以后不用再填；换账号可编辑 `config.ini` 或清空对应值重跑）。
2. 提示填**课程ID**（逗号分隔）。**不知道课程ID？直接回车** → 运行后程序会列出你的课程清单（ID + 课程名）让你选；全程回车则默认学全部课程。
3. 自动把后台服务（AI 答题等）拉起来，然后启动刷课容器，进度直接打印在终端里。
4. 答题时**先查本地题库**（题库管理后台 8001 里的题，命中秒回）→ 查不到才问本地 AI。

> 登录成功一次后，会话 cookie 会自动保存到 `cookies.txt`；想完全免密复用：把 `config.ini` 里 `use_cookies` 改为 `true` 再运行（cookie 失效会自动回落密码登录）。
> **Windows**：`onclick.bat run` 同款流程；若不用 Docker，也可从 Samueli924/chaoxing 的 Releases 下载 exe，与 `config.ini` 放同一目录运行（未在本机实测）。

**想一次刷多门课（推荐）？** 跑 `./onclick.sh panel`（Windows：`onclick.bat panel`）→ 打开 <http://127.0.0.1:8003/> 管理控制台：① 总览页可单独启停五个服务；② 先添加账号（手机号 / 密码），再给账号加课程（支持一键拉取你的课程列表）；③ 设置速率参数后把课程加入队列——**同一账号串行跑（防风控）、不同账号可并行**；④ 实时看日志、单独停止 / 移除。不用开多个终端。⑤ 智能系统自动工作：失败任务按类型自动重试（网络类退避重试、密码错误不白试）、服务掉线自动拉起；设置页可开关调参。

## 五、常见问题

- **命令行版报「用户名或密码错误 LoginError」**：`config.ini` 里 `username`/`password` 还是占位符（unused/unused）。填**你自己的**学习通账号再运行。
- **课程ID 在哪看**：跑 `./onclick.sh run` 时对「课程ID」直接回车，程序会把你的课程列表（ID + 课程名）打印出来让你选；想固定课程，之后把 ID 填进 `config.ini` 的 `course_list` 即可。
- **多门课要开多个终端吗**：不用。用管理控制台（`./onclick.sh panel` → <http://127.0.0.1:8003/>）统一管理多账号、多课程：同一账号串行、不同账号并行，统一看日志、统一停止。
- **专用浏览器和我的日常浏览器冲突吗 / 每次都要重新登录吗**：不冲突（独立数据目录，互不影响）；只要 `~/.xuexiton-browser` 目录还在，登录一次后长期免重复登录。
- **能不能不装油猴**：能。`browser` 命令打开的专用浏览器已内置脚本；油猴只是备选路线。
- **题库后台（8001）显示「请先构建前端」**：这是旧问题的提示，现已修复——我们已构建好，新电脑首次 `start` 也会自动构建（约 1 分钟）。无需手动跑 npm；注意 `deploy` 文件夹里**没有** `frontend` 目录，不要在 deploy 里跑 `cd frontend`。
- **我不知道账户密码**：学习通账号 = 你平时看网课登录的那个（学校注册的学号/手机号），工具没有账号可用。两个网页后台（8001 / 8060）则完全不需要密码（登录模块已移除，打开即用）。
- **AI 回答为空 / 超时**：脚本已内置 `--reasoning off`（thinking 模型必需）；内存紧张时把 `LLAMA_CTX` 改 2048。
- **纯 CPU 运行**：`LLAMA_NGL=0`，且 `LLAMA_DEV=` 留空。
- **改了端口**：`deploy.env` 里改，同时记得改脚本面板里的两个地址。
- **为什么要有桥接（8002）**：8001 的返回格式用户脚本不识别（实测命中标记为 `code=-1`，脚本只认 `1/0`），桥接做了格式转换与双库回退。
- **首次弹「找不到 llama-server / 模型」**：属正常提示，按第二节准备后重跑即可；纯题库模式可无视。
- **停止**：`stop` 只会停止**本脚本启动**的进程；手动启动的服务请自行关闭。

## 六、题库自动扩充（进阶）

做题时**没匹配到答案的题目会自动记入「待处理」**。这套工具把待处理题变成题库增长的动力。

**最简单的方式：控制台「题库」页** —— 有「待处理题目 · 自动扩充」面板：点「用本地 AI 补答」看进度、
「采纳全部建议」入库、「导出/导入分享包」在浏览器里直接完成。下面是等效的命令行方式（无界面时用）：

```bash
cd deploy
python3 tiku-augment.py stats                  # 概况：题库总量 / 待处理题数 / 哪些题被问得最多
python3 tiku-augment.py list --top 20          # 列出高频未命中题（按出现次数降序）
python3 tiku-augment.py ai-fill --limit 20     # 用本地 AI 给它们生成答案（存入「建议区」，不动正式题库）
python3 tiku-augment.py suggestions            # 查看 AI 建议答案
python3 tiku-augment.py adopt --all            # 采纳全部 → 写入正式题库（同题自动跳过）
python3 tiku-augment.py drop-suggestions --all # 丢弃全部建议（待处理题保留，可重新补答）
python3 tiku-augment.py export 我的题库包.json  # 导出分享包
python3 tiku-augment.py import 同学的包.json    # 导入同学分享的包（自动去重合并）
```

- AI 答案先进「**建议区**」，**你确认后才入正式题库** —— 不会污染题库；
- 用的全是本地模型（不花 API 钱），一题约 3 秒；
- 题库越用越大、命中率越来越高；同学之间还能交换题库包。

## 七、更新到新版本

**最省事：控制台里一键更新。** 打开管理控制台 <http://127.0.0.1:8003/> → 「设置」页 → 检查更新 → 有新版本时页面顶部会出现更新横幅，点一下即可自动完成（自动备份当前程序，出问题可回滚）。

手动方式（收到新版更新包时）：

- **Linux**：`cd deploy && ./update.sh <zip路径或下载链接>`（也可以在 `deploy.env` 设置 `UPDATE_URL=...` 后直接跑 `./update.sh`；`./update.sh --latest` 直接检查最新版）
- **Windows**：把 zip 放到 deploy 文件夹（或桌面），双击 `更新.bat`（或把 zip 拖到它上面）

更新是「只换程序」的：账号、cookie、配置、任务记录（`accounts.json` / `cookies*.txt` / `config.ini` / `deploy.env` / `tasks.json` / `events.json` 等）**永远不会被覆盖**。更新前会自动备份当前程序到 `备份-更新前-时间戳/`（出问题把里面文件拷回来即可）。更新后重启服务（`stop` → `start`），浏览器刷新一次页面即可用上新界面。

## 八、合规提示

本套件为本地个人学习辅助工具。填写真实账号前，请自行评估并遵守学习通平台服务条款；工具用途风险自负。

---

各版本改进记录见 `CHANGELOG.md`（本目录）。
