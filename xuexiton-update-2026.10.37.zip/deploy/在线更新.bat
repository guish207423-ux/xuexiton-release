@echo off
chcp 65001 >nul
rem --- UTF-8 bootstrap. ASCII ONLY: keep this block above any non-ASCII byte. ---
rem --- Reason: cmd.exe decodes a .bat with the *system* code page (936 on a    ---
rem --- Chinese Windows), so UTF-8 Chinese bytes re-pair, a line gets cut and   ---
rem --- its tail is executed as a command ("X is not recognized as an internal  ---
rem --- or external command"). chcp inside the file is too late: the decode     ---
rem --- pass already happened. Re-launch under an already-UTF-8 console.        ---
if "%~1"=="--u8" goto u8_main
cmd /c ""%~f0" --u8 %*"
exit /b %ERRORLEVEL%
:u8_main
shift
rem ============================================================
rem  在线更新（Windows）：从 deploy.env 的 UPDATE_FEED 检查最新版并应用
rem  双击运行即可。首次使用前在 deploy.env 里配置：
rem    UPDATE_FEED=https://cdn.jsdelivr.net/gh/xxx/latest.json
rem ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0在线更新.ps1"
echo.
pause
