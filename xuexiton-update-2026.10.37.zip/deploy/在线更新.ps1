﻿# ============================================================
#  在线更新（Windows）：从 deploy.env 的 UPDATE_FEED 检查最新版并应用
#  由 在线更新.bat 调用；也可直接右键「使用 PowerShell 运行」。
# ============================================================
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# 找 deploy 目录（脚本所在目录，或它的 deploy 子目录）
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Test-Path (Join-Path $here 'deploy\panel.py')) { $Deploy = Join-Path $here 'deploy' }
elseif (Test-Path (Join-Path $here 'panel.py')) { $Deploy = $here }
else { Write-Host '找不到 deploy 目录。请把本脚本放在 deploy 文件夹里（或旁边）再运行。'; exit 1 }

# 读 deploy.env 的 UPDATE_FEED（环境变量优先其次）
$feed = $env:UPDATE_FEED
$envFile = Join-Path $Deploy 'deploy.env'
if (Test-Path $envFile) {
    foreach ($line in Get-Content -LiteralPath $envFile) {
        if ($line -match '^\s*UPDATE_FEED\s*=\s*(\S.*?)\s*$') { $feed = $Matches[1] }
    }
}
if (-not $feed) {
    # 内置默认更新源（无需在 deploy.env 配置即可用）
    $feed = 'https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json'
    Write-Host '（未在 deploy.env 配置 UPDATE_FEED，使用内置默认更新源）'
}
# 备用源：CDN 发版后会继续返回旧版本清单（HTTP 200 + 过期版本，并不报错），
# 单看一个源会把「有新版本」误判成「已是最新」。两个源都查、取版本号更高的那个。
$defaultFeed = 'https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json'
$feedAlt = 'https://raw.githubusercontent.com/guish207423-ux/xuexiton-release/main/latest.json'

function Get-HighestFeed($primary, $alt) {
    $best = $null; $err = $null
    foreach ($u in @($primary, $alt)) {
        if (-not $u) { continue }
        try { $d = Invoke-RestMethod -Uri $u -TimeoutSec 30 } catch { $err = $_; continue }
        if (-not $best) { $best = $d; continue }
        if ((Compare-Ver $d.version $best.version) -gt 0) { $best = $d }
    }
    if (-not $best) { throw $err }
    return $best
}

# 版本号比较：-1 旧 / 0 相同 / 1 新（按数字段逐段比，不是字符串相等）
function Compare-Ver($a, $b) {
    $pa = @([regex]::Matches([string]$a, '\d+') | ForEach-Object { [int]$_.Value })
    $pb = @([regex]::Matches([string]$b, '\d+') | ForEach-Object { [int]$_.Value })
    $n = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $x = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
        $y = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
        if ($x -ne $y) { if ($x -gt $y) { return 1 } else { return -1 } }
    }
    return 0
}

Write-Host "== 检查最新版本: $feed"
$alt = ''
if ($feed -eq $defaultFeed) { $alt = $feedAlt }
try { $info = Get-HighestFeed $feed $alt }
catch { Write-Host '!! 检查更新失败（网络不通或地址不对）。可改用「收到文件后双击 更新.bat」方式。'; exit 1 }

$cur = '?'
$verFile = Join-Path $Deploy 'VERSION'
if (Test-Path $verFile) { $cur = (Get-Content -LiteralPath $verFile -First 1).Trim() }
Write-Host "   最新: $($info.version)    当前: $cur"
if ($info.notes) { Write-Host "   说明: $($info.notes)" }
if ((Compare-Ver $info.version $cur) -eq 0) { Write-Host '== 已是最新版本，无需更新。'; exit 0 }
# 必须比当前新才更新：源返回的版本若低于本地（CDN 旧缓存），继续下去就是降级
if ((Compare-Ver $info.version $cur) -lt 0) {
    Write-Host "== 版本源返回的是旧版本（$($info.version) 低于本地 $cur），已中止，不会降级安装。"
    Write-Host '   稍后重试，或让对方直接传更新包，双击 更新.bat 应用。'
    exit 1
}
if (-not $info.url -and -not $info.url_raw) { Write-Host '!! 版本清单里没有 url 字段'; exit 1 }

$tmp = Join-Path $env:TEMP ("xuexiton-online-" + (Get-Random))
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
$zip = Join-Path $tmp 'u.zip'
# 优先 CDN，失败再试备用直链（CDN 发版后短暂不可用/返回旧内容时仍能更新成功）
$got = $false
foreach ($u in @($info.url, $info.url_raw)) {
    if (-not $u) { continue }
    Write-Host "== 下载: $u"
    try {
        Invoke-WebRequest -Uri $u -OutFile $zip -UseBasicParsing -TimeoutSec 180
        $got = $true; break
    } catch { Write-Host '   该地址不可用，换下一个…' }
}
if (-not $got) { Write-Host '!! 下载失败（网络问题）。可让对方直接传更新包，双击 更新.bat 应用。'; exit 1 }

if ($info.sha256) {
    $got = (Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLower()
    if ($got -ne $info.sha256.ToLower()) { Write-Host '!! SHA256 校验失败，已中止，什么都没改。'; exit 1 }
    Write-Host '== SHA256 校验通过'
}

# 应用（复用 应用更新.bat）
$apply = Join-Path $Deploy '应用更新.bat'
if (-not (Test-Path $apply)) { Write-Host "没找到 应用更新.bat，请手动解压应用: $zip"; exit 1 }
& $apply $zip
if ($LASTEXITCODE -ne 0) { Write-Host '!! 应用更新失败，请检查上面的输出。'; exit 1 }
exit 0
