#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""引擎分离运行器：以子进程跑引擎，把 pid 与退出码写盘（供控制台读状态）。
用法: _engine_run.py <engine_main.py> <config.ini> <rc文件> [引擎参数...]
"""
import os
import shutil
import subprocess
import sys

main, cfg, rcf = sys.argv[1], sys.argv[2], sys.argv[3]
extra = sys.argv[4:]
run_dir = os.path.dirname(os.path.abspath(rcf))
engine_dir = os.path.dirname(os.path.abspath(main))
log = open(os.path.join(run_dir, "stdout.log"), "ab", buffering=0)
env = dict(os.environ)
env["PYTHONIOENCODING"] = "utf-8"
env["PYTHONUTF8"] = "1"
# 引擎依赖随包分发在 chaoxing/_vendor/（离线可用，无需 pip 或 Docker）。
# 注意：_vendor 里是 **Windows 轮子**（cp312/win_amd64），只在 Windows 上挂进
# PYTHONPATH；在 Linux/macOS 上挂它会因 pydantic_core 等二进制模块无法加载而直接报错。
vendor = os.path.join(engine_dir, "_vendor" if os.name == "nt" else "_vendor_linux")
if os.path.isdir(vendor):
    prev = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (prev + os.pathsep + vendor) if prev else vendor   # 追加：不遮蔽已有依赖
# 引擎的 resource_path() 在非打包环境按 CWD 解析（base_path = os.path.abspath(".")），
# Docker 时代靠 WorkDir /app 满足这一契约。这里把 resource/ 复制进运行目录：
# 既让引擎找得到 resource/font_map_table.json（否则超星字体混淆题会静默降级），
# 又保持“一次任务一个运行目录”的隔离不变，且不修改引擎源码。
res_src = os.path.join(engine_dir, "resource")
res_dst = os.path.join(run_dir, "resource")
if os.path.isdir(res_src) and not os.path.isdir(res_dst):
    try:
        shutil.copytree(res_src, res_dst)
    except Exception:
        pass
# cwd 必须显式指定为运行目录（不要依赖继承来的 CWD，否则 resource/ 会找不到）
p = subprocess.Popen([sys.executable, main, "-c", cfg, *extra],
                     stdout=log, stderr=subprocess.STDOUT, env=env, cwd=run_dir)
with open(os.path.join(run_dir, "pid"), "w") as f:
    f.write(str(p.pid))
rc = p.wait()
with open(rcf, "w") as f:
    f.write(str(rc))
