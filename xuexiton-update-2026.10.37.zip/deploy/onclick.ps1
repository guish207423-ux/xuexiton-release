﻿param([string]$Action = "start", [string]$Service = "")
# 空值安全的 Test-Path：变量为空时返回 $false 而不是抛 ParameterArgumentValidationError
# （用户直接从 U 盘跑 doctor 时 deploy.env 尚未生成，多个路径变量会是空串）
function Test-Path2([string]$p) { if ([string]::IsNullOrWhiteSpace($p)) { return $false } return (Test-Path $p) }

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

# ---------- 配置（deploy.env 可覆盖） ----------
$cfg = @{}
if (Test-Path "deploy.env") {
  foreach ($line in Get-Content "deploy.env" -Encoding UTF8) {
    $t = $line.Trim()
    if ($t -eq "" -or $t.StartsWith("#")) { continue }
    $i = $t.IndexOf("=")
    if ($i -gt 0) {
      $k = $t.Substring(0, $i).Trim()
      $v = $t.Substring($i + 1).Trim().Trim('"')
      $v = $v.Replace('$HOME', $env:USERPROFILE)
      $cfg[$k] = $v
    }
  }
}

function CfgVal([string]$k, [string]$d) {
  if ($cfg.ContainsKey($k) -and $cfg[$k] -ne "") { return $cfg[$k] }
  return $d
}

# 服务过滤：onclick.ps1 start [服务名] / stop [服务名]（供控制台守护与切模型重启使用）
function Want([string]$name) {
  if ($Service -eq "") { return $true }
  $alias = @{ "llama" = "llama-server"; "adapter" = "tikuAdapter" }
  $s = $Service
  if ($alias.ContainsKey($s)) { $s = $alias[$s] }
  return ($s -eq $name)
}

$LlamaBin = CfgVal "LLAMA_BIN" ""
if (-not $LlamaBin) {
  foreach ($c in @("$PSScriptRoot\llama-server.exe", "$env:USERPROFILE\llama.cpp\build\bin\llama-server.exe", "$env:USERPROFILE\llama.cpp\llama-server.exe")) {
    if (Test-Path2 $c) { $LlamaBin = $c; break }
  }
}
$ModelPath = CfgVal "MODEL_PATH" ""
if (-not $ModelPath) { $ModelPath = "$env:USERPROFILE\models\qwen3-4b\Qwen3-4B-Q4_K_M.gguf" }
# gguf 自动归位：默认路径不存在时，扫描常见位置找第一个 .gguf
if (-not (Test-Path2 $ModelPath)) {
  foreach ($md in @("$env:USERPROFILE\models", $PSScriptRoot, (Join-Path $PSScriptRoot "models"), "$env:USERPROFILE\Downloads")) {
    if (-not (Test-Path2 $md)) { continue }
    $g = Get-ChildItem $md -Recurse -Filter *.gguf -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($g) { $ModelPath = $g.FullName; break }
  }
}
$ToolkitDir = CfgVal "TOOLKIT_DIR" "$env:USERPROFILE\Projects\chaoxing-lab\chaoxing-toolkit"
$AdapterBin = CfgVal "TIKU_ADAPTER_BIN" "$env:USERPROFILE\Projects\chaoxing-lab\tiku-run\tikuAdapter.exe"
$AdapterDir = CfgVal "TIKU_ADAPTER_DIR" (Split-Path $AdapterBin)
$LlamaPort   = [int](CfgVal "LLAMA_PORT" "8080")
$TikuPort    = [int](CfgVal "TIKU_PORT" "8001")
$AdapterPort = [int](CfgVal "ADAPTER_PORT" "8060")
$BridgePort  = [int](CfgVal "BRIDGE_PORT" "8002")
$PanelPort   = [int](CfgVal "PANEL_PORT" "8003")
$LlamaNgl    = CfgVal "LLAMA_NGL" "99"
$LlamaDev    = if ($cfg.ContainsKey("LLAMA_DEV")) { $cfg["LLAMA_DEV"] } else { "Vulkan0" }
# 无 Vulkan 的机器不能传 -dev Vulkan0、也不能 -ngl 99：llama-server 会立刻退出
# （2026-10-15 真机事故：裸机无显卡驱动 → "error ... invalid device: Vulkan0"，而启动器仍傻等 200 秒）
# 这里直接自动降级为纯 CPU（慢但可用）——不再让收件人自己去改配置。
$HasVulkanRun = Test-Path "$env:SystemRoot\System32\vulkan-1.dll"
if (-not $HasVulkanRun) { $LlamaDev = ""; $LlamaNgl = "0" }
$LlamaCtx    = CfgVal "LLAMA_CTX" "4096"
$LogDir      = CfgVal "LOG_DIR" "$env:TEMP\xuexiton-deploy"
# 同一台机器上可能同时存在多份安装（已安装副本 + 从 U 盘直接跑的副本）：
# pid 文件名带上本安装目录的指纹，避免两份安装互相覆盖记录 → stop 误杀对方的服务
$InstanceTag = "inst"
try {
  $md5 = [System.Security.Cryptography.MD5]::Create()
  $bytes = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($PSScriptRoot))
  $InstanceTag = (($bytes | ForEach-Object { $_.ToString("x2") }) -join "").Substring(0, 8)
  $md5.Dispose()
} catch { }
function PidFile([string]$name) { Join-Path $LogDir "$name.$InstanceTag.pid" }
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$BundledPy = Join-Path (Split-Path -Parent $PSScriptRoot) "py\python.exe"
# 英文 Windows 上 Python 的标准流默认用 cp1252：服务打印中文会直接 UnicodeEncodeError 崩掉（真机事故）。
$env:PYTHONUTF8 = '1'   # 对 Python 进程强制 UTF-8 标准流；对其他程序无影响
# Python 解析顺序：包内免安装版 → 系统 python → py launcher（三者都不用装任何东西）
$PyCmd = if (Test-Path2 $BundledPy) { $BundledPy } elseif (Get-Command python -ErrorAction SilentlyContinue) { "python" } else { "py" }

# ---------- 工具函数 ----------
function TestOk([string]$url) {
  try {
    $r = Invoke-WebRequest -Uri $url -TimeoutSec 3 -UseBasicParsing
    return ($r.StatusCode -ge 200 -and $r.StatusCode -lt 300)
  } catch { return $false }
}
function TestOkPat([string]$url, [string]$pat) {
  try {
    $r = Invoke-WebRequest -Uri $url -TimeoutSec 3 -UseBasicParsing
    return ($r.Content -match [regex]::Escape($pat))
  } catch { return $false }
}
function TestUp([string]$url) {
  try { Invoke-WebRequest -Uri $url -TimeoutSec 3 -UseBasicParsing | Out-Null; return $true }
  catch { return ($null -ne $_.Exception.Response) }
}
function WaitOk([string]$name, [string]$url, [int]$tries = 40, [string]$pat = "") {
  $total = $tries * 5
  for ($i = 1; $i -le $tries; $i++) {
    $readyNow = if ($pat) { TestOkPat $url $pat } else { TestOk $url }
    if ($readyNow) {
      if ($i -le 1) { Write-Host "OK  [$name] 就绪" } else { Write-Host "OK  [$name] 就绪（用时约 $($i*5)s）" }
      return $true
    }
    if ($i % 2 -eq 0) { Write-Host "  ...[$name] 启动中（$($i*5)s/${total}s）" }
    # 子进程已经退出就不可能等到端口：立刻失败并把日志尾巴摆出来，别让用户白等（2026-10-15 真机事故）
    $pf = PidFile $name
    if (Test-Path2 $pf) {
      $pidTxt = (Get-Content $pf -ErrorAction SilentlyContinue | Select-Object -First 1)
      if ($pidTxt -and -not (Get-Process -Id ([int]$pidTxt) -ErrorAction SilentlyContinue)) {
        Write-Host "!!  [$name] 进程已退出（pid $pidTxt），不再等待"
        $errLog = Join-Path $LogDir "$name.err.log"
        if (Test-Path2 $errLog) { Get-Content $errLog -Tail 6 | ForEach-Object { Write-Host "      $_" } }
        Write-Host "      完整日志: $LogDir"
        return $false
      }
    }
    Start-Sleep -Seconds 5
  }
  Write-Host "!!  [$name] 等待超时（${total}s）"
  return $false
}
function SpawnBg([string]$name, [string]$cwd, [string]$exe, [string]$arguments) {
  if (-not (Test-Path2 $cwd)) { Write-Host "!!  [$name] 目录不存在: $cwd"; return $null }
  $sp = @{
    FilePath = $exe; WorkingDirectory = $cwd; WindowStyle = "Hidden"; PassThru = $true
    RedirectStandardOutput = "$LogDir\$name.out.log"; RedirectStandardError = "$LogDir\$name.err.log"
  }
  if ($arguments) { $sp["ArgumentList"] = $arguments }
  $p = Start-Process @sp
  Set-Content -Path (PidFile $name) -Value $p.Id
  return $p
}
# ---------- 端口让位 / 进程归属（判据与 Linux 侧 onclick.sh 完全一致） ----------
function Test-PortBusy([int]$Port) {
  # 只认「有进程正在 LISTEN」这一个事实。绝不用「能否连上」或「netstat 里有没有这一行」做判据：
  # 刚停掉的服务留下的 TIME_WAIT 会让这两种判据误报"被占用" → 端口无谓漂移
  # （2026-10-15 真机事故：stop 之后紧接 start，8080/8060/8002/8003 全被误判占用并漂到 8081/8061/8004/8005）
  try { if (@(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop).Count -gt 0) { return $true } } catch { }
  try {
    $ns = netstat -ano -p tcp 2>$null | Select-String -Pattern "LISTENING" | Select-String -Pattern (":" + $Port + "\s")
    if ($ns) { return $true }
  } catch { }
  return $false
}
function Get-PortOwnerPid([int]$Port) {
  try { return [int]((Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop | Select-Object -First 1).OwningProcess) } catch { }
  return 0
}
function Test-PidIsOurs([int]$ProcId) {
  # 这个监听进程是不是本套件的服务（既别把自家服务当端口冲突，也别让残留进程顶替服务看不出来）
  if (-not $ProcId) { return $false }
  try {
    $w = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $ProcId) -ErrorAction Stop
    $blob = "$($w.ExecutablePath) $($w.CommandLine)"
    foreach ($m in @($LlamaBin, $AdapterBin, $ToolkitDir, $PSScriptRoot)) {
      if ($m -and $blob.Contains([string]$m)) { return $true }
    }
  } catch { }
  try {
    foreach ($f in @(Get-ChildItem -Path $LogDir -Filter "*.pid" -ErrorAction SilentlyContinue)) {
      $v = (Get-Content $f -ErrorAction SilentlyContinue | Select-Object -First 1)
      if ("$v".Trim() -eq "$ProcId") { return $true }
    }
  } catch { }
  return $false
}
function Get-SvcPort([string]$Name) {
  switch ($Name) {
    "llama-server" { return $LlamaPort }
    "tiku"         { return $TikuPort }
    "tikuAdapter"  { return $AdapterPort }
    "bridge"       { return $BridgePort }
    "panel"        { return $PanelPort }
  }
  return 0
}
function Get-SvcMarker([string]$Name) {
  switch ($Name) {
    "llama-server" { return '"status"' }
    "tiku"         { return "題庫管理" }
    "tikuAdapter"  { return "chunk-vendors" }
    "bridge"       { return "bridge ok" }
    "panel"        { return "刷课控制台" }
  }
  return ""
}
function Find-OursByPort([string]$Name) {
  # 精确兜底判据：该端口上应答的确实是"我们这台的服务"（响应特征串对得上）才认。
  # 为什么需要：Windows 上服务是相对命令行（python panel.py），按路径认不出来；
  # 而"端口+特征串"既能认准、又不会误杀别人同名的进程。
  $port = Get-SvcPort $Name
  $pat = Get-SvcMarker $Name
  if (-not $port -or -not $pat) { return 0 }
  $url = "http://127.0.0.1:$port/"
  if ($Name -eq "llama-server") { $url = "http://127.0.0.1:$port/health" }
  if (-not (TestOkPat $url $pat)) { return 0 }
  return (Get-PortOwnerPid $port)
}
function Find-OursByName([string]$Name) {
  # 没有 pid 文件时，凭进程本身认出「这台的某个服务」
  $marker = ""
  switch ($Name) {
    "llama-server" { $marker = $LlamaBin }
    "tikuAdapter"  { $marker = $AdapterBin }
    "tiku"         { $marker = $ToolkitDir }
    "bridge"       { $marker = (Join-Path $PSScriptRoot "bridge.py") }
    "panel"        { $marker = (Join-Path $PSScriptRoot "panel.py") }
  }
  if (-not $marker) { return 0 }
  try {
    foreach ($w in @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
      $blob = "$($w.ExecutablePath) $($w.CommandLine)"
      if ($blob.Contains([string]$marker) -and (Test-PidIsOurs ([int]$w.ProcessId))) { return [int]$w.ProcessId }
    }
  } catch { }
  return 0
}
function Set-EnvValue([string]$Key, [string]$Value) {
  # 写回 deploy.env（UTF-8 无 BOM）——面板与桥接都读这个文件，不写回它们就还用老端口
  $f = Join-Path $PSScriptRoot "deploy.env"
  $lines = @()
  if (Test-Path2 $f) { $lines = @(Get-Content $f) }
  $hit = $false
  $out = @()
  foreach ($l in $lines) {
    if ($l -match ("^\s*" + [regex]::Escape($Key) + "\s*=")) { $out += ("$Key=$Value"); $hit = $true } else { $out += $l }
  }
  if (-not $hit) { $out += ("$Key=$Value") }
  [System.IO.File]::WriteAllLines($f, [string[]]$out, (New-Object System.Text.UTF8Encoding($false)))
}
function Marker-ForName([string]$Name) {
  # 中文服务名 → 该服务的响应特征串（判"这个端口是不是本套件自己的服务"用）
  if ($Name -like "*AI*")      { return '"status"' }
  if ($Name -like "*题库后台*") { return "題庫管理" }
  if ($Name -like "*聚合*")    { return "chunk-vendors" }
  if ($Name -like "*桥接*")    { return "bridge ok" }
  if ($Name -like "*控制台*")  { return "刷课控制台" }
  return ""
}
function Test-OursByMarker([int]$Port, [string]$Marker) {
  if (-not $Marker) { return $false }
  return (TestOkPat "http://127.0.0.1:$Port/" $Marker)
}
function Resolve-Port([string]$Var, [int]$Port, [string]$Name) {
  # 空闲→保持；占用者是本套件自己的服务（重启场景）→保持；外来占用→顺延并写回 deploy.env
  if (-not (Test-PortBusy $Port)) { return $Port }
  # ★ 先按「响应特征串」认自己人。服务可能是用相对命令行起的（python panel.py / 包内 Python），
  #   按 exe/cwd 的 PID 归属判断会失败 → 端口被误判成"外人占用" → 每次启动都漂移并改写 deploy.env，
  #   守卫也探不到在跑的服务（2026-10-15 真机事故：端口一路漂到 8035）。
  if (Test-OursByMarker $Port (Marker-ForName $Name)) { return $Port }
  $owner = Get-PortOwnerPid $Port
  if ($owner -gt 0 -and (Test-PidIsOurs $owner)) { return $Port }
  $all = @($LlamaPort, $TikuPort, $AdapterPort, $BridgePort, $PanelPort)
  for ($i = 1; $i -le 30; $i++) {
    $cand = $Port + $i
    if (Test-PortBusy $cand) { continue }
    if ($all -contains $cand) { continue }
    Write-Host "!!  [$Name] 默认端口 :$Port 被占用 → 自动改用 :$cand（别人占着端口不再让整个功能起不来）"
    Set-EnvValue $Var "$cand"
    Write-Host "    已记入 deploy.env（$Var=$cand），控制台与桥接会一起用新端口；想改回去先腾出 :$Port"
    return $cand
  }
  Write-Host "!!  [$Name] 从 :$Port 起连续 30 个端口都被占用——仍按 :$Port 尝试（日志里能看到绑定失败原因）"
  return $Port
}
function Probe-Url([string]$Url) {
  try {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $r = Invoke-WebRequest -Uri $Url -Method Head -TimeoutSec 8 -UseBasicParsing -ErrorAction Stop
    $sw.Stop()
    return ("[" + [int]$r.StatusCode + "] " + [math]::Round($sw.Elapsed.TotalSeconds, 2) + "s")
  } catch { return "不可达" }
}
function Get-ClockDrift {
  # "更新失败"常见真因其实是系统时间不对（TLS 直接失败）
  try {
    $r = Invoke-WebRequest -Uri "https://cdn.jsdelivr.net" -Method Head -TimeoutSec 8 -UseBasicParsing -ErrorAction Stop
    $h = $r.Headers["Date"]
    if ($h -is [array]) { $h = $h[0] }
    $d = [datetime]::Parse($h).ToUniversalTime()
    $delta = [int]([datetime]::UtcNow - $d).TotalSeconds
    if ([math]::Abs($delta) -le 5) { return ("正常（" + $delta + " 秒）") }
    $warn = ""
    if ([math]::Abs($delta) -gt 300) { $warn = " ⚠ 偏差过大，会导致更新/联网失败（请校准系统时间）" }
    return ("偏差 " + $delta + " 秒" + $warn)
  } catch { return "未能测出（网络不通？）" }
}

# ---------- doctor：一页「设备体检报告」（对方出问题先跑这条） ----------
function DoDoctor {
  Write-Host "================ 设备体检报告（复制下面整段发给维护者）================"
  $osName = "未知"; try { $osName = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { }
  $arch = "32 位"; if ([Environment]::Is64BitOperatingSystem) { $arch = "64 位" }
  Write-Host "[系统] $osName $([System.Environment]::OSVersion.Version) | $arch | PowerShell $($PSVersionTable.PSVersion)"
  $cp = "未知"; try { $cp = (chcp.com) } catch { }
  Write-Host "[语言] 区域=$((Get-Culture).Name) | $cp"
  $nonascii = "否"
  if (("$PSScriptRoot $env:USERPROFILE") -match "[^\x00-\x7f]") { $nonascii = "是（中文用户名/路径，个别工具会踩坑）" }
  Write-Host "[路径] 安装目录 $PSScriptRoot | 用户目录 $env:USERPROFILE | 含非ASCII: $nonascii"
  $admin = "普通用户"
  try { if (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { $admin = "管理员" } } catch { }
  Write-Host "[权限] $admin"
  $pyVer = "缺失（题库后台/控制台需要）"
  if (Test-Path2 $BundledPy) { $pyVer = "$((& $BundledPy --version 2>&1)) → $BundledPy（包内免安装）" }
  else { try { $pv = Get-Command python -ErrorAction Stop; $pyVer = "$((& $pv.Source --version 2>&1)) → $($pv.Source)" } catch { } }
  Write-Host "[Python] $pyVer"
  $dk = "未安装（仅命令行刷课需要；网页版刷课不受影响）"
  try {
    $null = docker info 2>&1
    if ($LASTEXITCODE -eq 0) {
      $dk = "已装且引擎在跑"
      if (docker image inspect chaoxing:local 2>&1 | Select-String -Pattern "chaoxing" -Quiet) { $dk = "$dk；镜像 chaoxing:local 已就绪" }
      else { $dk = "$dk；镜像 chaoxing:local 未导入（首次命令行刷课会自动导入/构建）" }
    } else { $dk = "已装但引擎未启动（仅命令行刷课需要）" }
  } catch { }
  if (Test-Path2 (Join-Path $PSScriptRoot "chaoxing\main.py")) { Write-Host "[命令行引擎] 原生就绪（无需 Docker）" }
  else { Write-Host "[Docker] $dk" }
  $gpu = "未识别"
  try { $gpu = ((Get-CimInstance Win32_VideoController -ErrorAction Stop | Select-Object -First 2 | ForEach-Object { $_.Name }) -join " / ") } catch { }
  Write-Host "[显卡] $gpu"
  if (Test-Path "$env:SystemRoot\System32\vulkan-1.dll") {
    Write-Host "[Vulkan] 已装 Vulkan 运行库（可尝试 GPU 加速；AI 起不来就把 LLAMA_NGL 改 0 走 CPU）"
  } else {
    Write-Host "[Vulkan] 未找到 vulkan-1.dll（无 GPU 加速 → 启动器自动以 CPU 运行 AI，慢但可用）"
  }
  if (Test-Path2 $LlamaBin) { Write-Host "[AI] llama-server 可执行 ✓" } elseif ($LlamaBin) { Write-Host "[AI] llama-server 缺失 → $LlamaBin" } else { Write-Host "[AI] llama-server 未随包提供（本包不含 AI 组件）" }
  if (Test-Path2 $ModelPath) { Write-Host "[AI] 模型文件 ✓" } elseif ($ModelPath) { Write-Host "[AI] 模型文件缺失 → $ModelPath" } else { Write-Host "[AI] 模型文件未随包提供" }
  $memTxt = "未知"
  try { $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop; $memTxt = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1).ToString() + " GB 总" } catch { }
  $diskTxt = "未知"
  try {
    $drv = $PSScriptRoot.Substring(0, 1)
    $d = Get-PSDrive -Name $drv -ErrorAction Stop
    $diskTxt = [math]::Round(($d.Used + $d.Free) / 1GB, 1).ToString() + " GB 总 / " + [math]::Round($d.Free / 1GB, 1).ToString() + " GB 可用"
  } catch { }
  Write-Host "[内存] $memTxt | [磁盘] $diskTxt"
  Write-Host "[端口] 默认端口占用情况（只看是不是本套件自己，别被自家服务吓到）："
  $svc = @()
  $svc += ,@("AI 模型", $LlamaPort)
  $svc += ,@("题库后台", $TikuPort)
  $svc += ,@("聚合题库", $AdapterPort)
  $svc += ,@("题库桥接", $BridgePort)
  $svc += ,@("管理控制台", $PanelPort)
  foreach ($s in $svc) {
    $nm = [string]$s[0]; $pt = [int]$s[1]
    if (-not (Test-PortBusy $pt)) { Write-Host "        :$pt 空闲"; continue }
    $owner = Get-PortOwnerPid $pt
    if ($owner -gt 0 -and (Test-PidIsOurs $owner)) {
      Write-Host "        :$pt 本套件服务在用（pid=$owner）"
    } else {
      if ($owner -le 0) {
        Write-Host "        :$pt 有人在用但取不到进程信息（可能需要管理员权限）→ 该服务会改用其他端口或起不来"
      } else {
        $exe = "?"
        try { $exe = (Get-CimInstance Win32_Process -Filter ("ProcessId=" + $owner) -ErrorAction Stop).ExecutablePath } catch { }
        Write-Host "        :$pt ⚠ 被外部程序/残留进程占用（pid=$owner $exe）→ 该服务会改用其他端口或起不来"
      }
    }
  }
  Write-Host "[网络] jsDelivr: $(Probe-Url 'https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json')"
  Write-Host "[网络] raw.githubusercontent: $(Probe-Url 'https://raw.githubusercontent.com/guish207423-ux/xuexiton-release/main/latest.json')"
  Write-Host "[时钟] 与联网时间偏差: $(Get-ClockDrift)"
  $feed = CfgVal "UPDATE_FEED" ""
  if (-not $feed) { $feed = "未在 deploy.env 配置（将使用内置默认源）" }
  Write-Host "[更新源] $feed"
  Write-Host ""
  Write-Host "---------------- 结论与下一步 ----------------"
  $ladder = 1
  $hasDocker = $false
  try { $null = docker info 2>&1; if ($LASTEXITCODE -eq 0) { $hasDocker = $true } } catch { }
  $hasPy = $false
  $hasPy = (Test-Path2 $BundledPy)
  if (-not $hasPy) { try { $null = Get-Command python -ErrorAction Stop; $hasPy = $true } catch { } }
  $hasEngine = (Test-Path2 (Join-Path $PSScriptRoot "chaoxing\main.py"))
  if ($hasEngine) {
    Write-Host "· 命令行刷课：可用（原生引擎，无需 Docker）"
  } elseif ($hasDocker) {
    Write-Host "· 命令行刷课：可用（Docker 回退）"
  } else {
    Write-Host "· 命令行刷课：包内引擎缺失且无 Docker → 用【网页版刷课】（或浏览器脚本兜底）"
    $ladder = 2
  }
  if (Test-Path (Join-Path $ToolkitDir "tiku\main.py")) {
    if (Test-Path (Join-Path $ToolkitDir "tiku\.venv\Scripts\python.exe")) { Write-Host "· 本地题库后台：依赖已装好，可用" }
    elseif ((Test-Path2 $BundledPy) -and (Test-Path (Join-Path (Split-Path -Parent $BundledPy) "Lib\site-packages\fastapi"))) { Write-Host "· 本地题库后台：可用（包内 Python + 随包依赖树，离线可用）" }
    else { Write-Host "· 本地题库后台：缺少依赖（首次启动会联网 pip 安装；离线设备需完整交付包）" }
  } else {
    Write-Host "· 本地题库后台：未找到 → $ToolkitDir"
  }
  if (Test-Path "$env:SystemRoot\System32\vulkan-1.dll") { Write-Host "· AI 答题：检测到 Vulkan，可尝试 GPU 加速" }
  else { Write-Host "· AI 答题：未检测到 Vulkan → 已自动使用 CPU（慢但可用）；也可只用题库" }
  Write-Host "（降级层级：$ladder —— 1=全功能（含命令行刷课），2=命令行刷课不可用，其余功能不受影响）"
  Write-Host "================================================================"
}
function StopOne([string]$name) {
  $pf = PidFile $name
  if (-not (Test-Path2 $pf)) {
    # 兼容旧版共用的 <名字>.pid（升级后第一次 stop 会走到这里）
    $legacy = Join-Path $LogDir "$name.pid"
    if (-not (Test-Path2 $legacy)) {
      # 没有 pid 文件 ≠ 没在跑：可能由控制台守护拉起、或上次崩溃/重启留下残留。
      # 用归属判定兜底收掉，否则它一直占端口，下一次 start 就起不来。
      $ours = Find-OursByPort $name
      if ($ours -le 0) { $ours = Find-OursByName $name }
      if ($ours -gt 0) {
        Stop-Process -Id $ours -Force -ErrorAction SilentlyContinue
        Write-Host "已停止 [$name] (pid $ours；无 pid 文件——由控制台拉起或上次残留)"
      } else {
        Write-Host "跳过 [$name]（未发现本安装的该服务在跑）"
      }
      return
    }
    $pf = $legacy
  }
  $procId = [int](Get-Content $pf)
  if (Get-Process -Id $procId -ErrorAction SilentlyContinue) {
    Stop-Process -Id $procId -Force
    Write-Host "已停止 [$name] (pid $procId)"
  } else {
    Write-Host "跳过 [$name]（进程已退出）"
  }
  Remove-Item $pf -Force -ErrorAction SilentlyContinue
}

# ---------- start ----------
# 是否从 U 盘（可移动盘）直接运行
function Test-OnUsb {
  if ($PSScriptRoot -match '^([A-Za-z]):') {
    try { return ((Get-Volume -DriveLetter $Matches[1] -ErrorAction Stop).DriveType -eq 'Removable') } catch {}
  }
  return $false
}

function DoStart {
  if (Test-OnUsb) {
    Write-Host "!!  注意：你正在直接从 U 盘运行本工具（$PSScriptRoot）。"
    Write-Host "    账号、进度、日志等数据会写进 U 盘，并且 U 盘将无法安全弹出。"
    Write-Host "    正确做法：运行 U 盘根目录的 安装.bat 装到本机，"
    Write-Host "    再从 桌面\xuexiton\deploy\onclick.bat 启动。"
    $a = ""
    try { $a = Read-Host "  仍要从 U 盘临时运行？(y/N)" } catch { $a = "" }
    if ($a -notin @("y", "Y", "yes", "YES")) { Write-Host "  已退出。"; return }
  }
  # 端口让位（一次算好；写 script: 作用域，保证 status/check 也读到新端口）
  $script:LlamaPort   = Resolve-Port "LLAMA_PORT"   $LlamaPort   "AI 模型"
  $script:TikuPort    = Resolve-Port "TIKU_PORT"    $TikuPort    "题库后台"
  $script:AdapterPort = Resolve-Port "ADAPTER_PORT" $AdapterPort "聚合题库"
  $script:BridgePort  = Resolve-Port "BRIDGE_PORT"  $BridgePort  "题库桥接"
  $script:PanelPort   = Resolve-Port "PANEL_PORT"   $PanelPort   "管理控制台"

  # 幂等：先探一遍「哪些服务其实已经在跑」。收件人连点两次启动时，第二个实例会抢端口自死
  # （2026-10-15 真机事故：tiku 第二次启动 → [Errno 10048] bind ... only one usage of each socket address）
  $UpSet = @{}
  $svcProbe = @{
    "llama-server" = @($LlamaPort,    '"status"',       "/health")
    "tiku"         = @($TikuPort,     "題庫管理",        "/")
    "tikuAdapter"  = @($AdapterPort,  "chunk-vendors",  "/")
    "bridge"       = @($BridgePort,   "bridge ok",      "/")
    "panel"        = @($PanelPort,    "",               "/")
  }
  foreach ($k in @($svcProbe.Keys)) {
    $pp = $svcProbe[$k][0]; $mk = $svcProbe[$k][1]; $ppath = $svcProbe[$k][2]
    $u = "http://127.0.0.1:$pp$ppath"
    $UpSet[$k] = if ($mk) { TestOkPat $u $mk } else { TestUp $u }
    if ($UpSet[$k]) { Write-Host "跳过 $k（已在运行 :$pp）" }
  }

  # 1) AI 模型 llama-server
  if ((Want "llama-server") -and -not $UpSet["llama-server"]) {
  if (TestOkPat "http://127.0.0.1:$LlamaPort/health" '"status"') {
    Write-Host "跳过 AI 模型（已在运行 :$LlamaPort）"
  } elseif (TestUp "http://127.0.0.1:$LlamaPort/") {
    Write-Host "!!  端口 :$LlamaPort 已被其他程序占用（不是本套件的 AI 模型）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$LlamaPort）"
  } elseif ((Test-Path2 $LlamaBin) -and (Test-Path2 $ModelPath)) {
    Write-Host "启动 AI 模型 llama-server（首次加载模型约 1-3 分钟）..."
    $devArg = if ($LlamaDev) { " -dev $LlamaDev" } else { "" }
    $llamaArgs = "-m `"$ModelPath`" -ngl $LlamaNgl -c $LlamaCtx --parallel 1 -n 1024 --temp 0.7 --top-p 0.95 --top-k 20 --reasoning off --host 127.0.0.1 --port $LlamaPort --no-webui$devArg"
    [void](SpawnBg "llama-server" $env:USERPROFILE $LlamaBin $llamaArgs)
    [void](WaitOk "llama-server" "http://127.0.0.1:$LlamaPort/health" 40 '"status"')
  } else {
    Write-Host "!!  跳过 AI 模型：找不到 $LlamaBin 或模型 $ModelPath"
    Write-Host "    （复制 deploy.env.example 为 deploy.env 后修改路径）"
  }
  }

  # 2) 本地题库 Web 管理后台（chaoxing-toolkit）
  if ((Want "tiku") -and -not $UpSet["tiku"]) {
  if (TestOkPat "http://127.0.0.1:$TikuPort/" '題庫管理') {
    Write-Host "跳过 题库后台（已在运行 :$TikuPort）"
  } elseif (TestUp "http://127.0.0.1:$TikuPort/") {
    Write-Host "!!  端口 :$TikuPort 已被其他程序占用（不是本套件的题库后台）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$TikuPort）"
  } elseif (Test-Path "$ToolkitDir\tiku\main.py") {
    # 题库后台前端未构建（static\index.html 缺失）时自动构建（需要 Node/npm）
    $feDir = "$ToolkitDir\tiku\frontend"
    if ((-not (Test-Path "$ToolkitDir\tiku\static\index.html")) -and (Test-Path2 $feDir)) {
      if (Get-Command npm -ErrorAction SilentlyContinue) {
        Write-Host "首次准备：构建题库后台前端（约 1 分钟，日志 $LogDir\tiku-build.log）..."
        Push-Location $feDir
        & npm install --no-audit --no-fund *> "$LogDir\tiku-build.log"
        $ok = ($LASTEXITCODE -eq 0)
        if ($ok) { & npm run build *>> "$LogDir\tiku-build.log"; $ok = ($LASTEXITCODE -eq 0) }
        if ($ok) {
          New-Item -ItemType Directory -Force -Path "$ToolkitDir\tiku\static" | Out-Null
          Copy-Item -Recurse -Force "$feDir\dist\*" "$ToolkitDir\tiku\static\"
          Write-Host "题库后台前端构建完成"
        } else {
          Write-Host "!!  题库后台前端构建失败（日志 $LogDir\tiku-build.log），后台页可能显示构建提示"
        }
        Pop-Location
      } else {
        Write-Host "!!  题库后台前端未构建且未装 Node/npm；后台页可能显示构建提示（不影响其他功能）"
      }
    }
    # 题库后台用哪个 Python：优先「包内免安装 Python + 随包依赖树」（离线可用，不需要 pip/网络）
    $tikuPy = ""
    $bundledSite = Join-Path (Split-Path -Parent $BundledPy) "Lib\site-packages"
    if ((Test-Path2 $BundledPy) -and (Test-Path (Join-Path $bundledSite "fastapi"))) {
      $tikuPy = $BundledPy
      Write-Host "使用包内 Python + 随包依赖树启动题库后台（离线可用）"
    } else {
      $venvPy = "$ToolkitDir\tiku\.venv\Scripts\python.exe"
      if (-not (Test-Path2 $venvPy)) {
        Write-Host "初始化题库服务 venv（联网安装依赖，约 1-2 分钟）..."
        & $PyCmd -m venv "$ToolkitDir\tiku\.venv"
        & $venvPy -m pip install -q -r "$ToolkitDir\tiku\requirements.txt"
      }
      $tikuPy = $venvPy
    }
    Write-Host "启动 题库后台 :$TikuPort ..."
    $env:PORT = "$TikuPort"
    [void](SpawnBg "tiku" "$ToolkitDir\tiku" $tikuPy "main.py")
    Remove-Item Env:PORT -ErrorAction SilentlyContinue
    [void](WaitOk "tiku" "http://127.0.0.1:$TikuPort/" 12 '題庫管理')
  } else {
    Write-Host "跳过 题库后台（未找到 $ToolkitDir\tiku\main.py）"
  }
  }

  # 3) 聚合题库 tikuAdapter（可选）
  if ((Want "tikuAdapter") -and -not $UpSet["tikuAdapter"]) {
  if (TestOkPat "http://127.0.0.1:$AdapterPort/" 'chunk-vendors') {
    Write-Host "跳过 tikuAdapter（已在运行 :$AdapterPort）"
  } elseif (TestUp "http://127.0.0.1:$AdapterPort/") {
    Write-Host "!!  端口 :$AdapterPort 已被其他程序占用（不是本套件的聚合题库）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$AdapterPort）"
  } elseif (Test-Path2 $AdapterBin) {
    Write-Host "启动 tikuAdapter :$AdapterPort ..."
    [void](SpawnBg "tikuAdapter" $AdapterDir $AdapterBin "")
    [void](WaitOk "tikuAdapter" "http://127.0.0.1:$AdapterPort/" 6 'chunk-vendors')
  } else {
    Write-Host "跳过 tikuAdapter（未找到 $AdapterBin，可选组件）"
  }
  }

  # 4) 题库桥接
  if ((Want "bridge") -and -not $UpSet["bridge"]) {
  if (TestOkPat "http://127.0.0.1:$BridgePort/" 'bridge ok') {
    Write-Host "跳过 题库桥接（已在运行 :$BridgePort）"
  } elseif (TestUp "http://127.0.0.1:$BridgePort/") {
    Write-Host "!!  端口 :$BridgePort 已被其他程序占用（不是本套件的题库桥接）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$BridgePort）"
  } else {
    Write-Host "启动 题库桥接 :$BridgePort ..."
    $env:PORT = "$BridgePort"; $env:TIKU_PORT = "$TikuPort"; $env:ADAPTER_PORT = "$AdapterPort"
    [void](SpawnBg "bridge" $PSScriptRoot $PyCmd "bridge.py")
    Remove-Item Env:PORT, Env:TIKU_PORT, Env:ADAPTER_PORT -ErrorAction SilentlyContinue
    [void](WaitOk "bridge" "http://127.0.0.1:$BridgePort/" 6 'bridge ok')
  }
  }

  # 5) 管理控制台 panel
  if ((Want "panel") -and -not $UpSet["panel"]) {
  if (TestOkPat "http://127.0.0.1:$PanelPort/" '刷课控制台') {
    Write-Host "跳过 管理控制台（已在运行 :$PanelPort）"
  } elseif (TestUp "http://127.0.0.1:$PanelPort/") {
    Write-Host "!!  端口 :$PanelPort 已被其他程序占用（不是本套件的管理控制台）——未启动，请先排查占用"
    Write-Host "    （查看占用：netstat -ano ^| findstr :$PanelPort）"
  } else {
    Write-Host "启动 管理控制台 :$PanelPort ..."
    $env:PORT = "$PanelPort"
    [void](SpawnBg "panel" $PSScriptRoot $PyCmd "panel.py $PanelPort")
    Remove-Item Env:PORT -ErrorAction SilentlyContinue
    [void](WaitOk "panel" "http://127.0.0.1:$PanelPort/" 4 '刷课控制台')
  }
  }

  Write-Host ""
  Write-Host "================= 就绪情况 ================="
  if (TestOkPat "http://127.0.0.1:$LlamaPort/health" '"status"') { Write-Host "AI 模型      : http://127.0.0.1:$LlamaPort/v1/chat/completions" }
  if (TestOkPat "http://127.0.0.1:$TikuPort/" '題庫管理') { Write-Host "题库管理后台 : http://127.0.0.1:$TikuPort/  （浏览器打开）" }
  if (TestOkPat "http://127.0.0.1:$AdapterPort/" 'chunk-vendors') { Write-Host "聚合题库页   : http://127.0.0.1:$AdapterPort/  （浏览器打开）" }
  if (TestOkPat "http://127.0.0.1:$BridgePort/" 'bridge ok') { Write-Host "题库桥接     : http://127.0.0.1:$BridgePort/search" }
  if (TestOkPat "http://127.0.0.1:$PanelPort/" '刷课控制台') { Write-Host "管理控制台   : http://127.0.0.1:$PanelPort/  （浏览器打开）" }
  if (Get-Command docker -ErrorAction SilentlyContinue) {
    docker info *> $null
    if ($LASTEXITCODE -eq 0) {
      docker image inspect chaoxing:local *> $null
      if ($LASTEXITCODE -eq 0) { Write-Host "Docker 镜像  : 已就绪（命令行刷课可用）" }
      else { Write-Host "Docker 镜像  : 未导入（首次命令行刷课自动导入，或跑 onclick.bat docker）" }
    }
  }
  Write-Host ""
  Write-Host "打开专用浏览器（登录一次免重复登录）: onclick.bat browser"
  Write-Host "（本套件不附带浏览器脚本；只有你自装了油猴脚本时，才需要在右下角面板里填：）"
  Write-Host "  自定义题库地址 = http://127.0.0.1:$BridgePort/search"
  Write-Host "  AI API 地址    = http://127.0.0.1:$LlamaPort/v1/chat/completions"
  Write-Host "  AI 模型名称    = bonsai（任意非空）  AI 密钥 = local（任意非空）"
  Write-Host ""
  Write-Host "日志: $LogDir"
  Write-Host "命令行开刷（不用浏览器）: onclick.bat run"
  Write-Host "多课程并行（统一管理面板）: onclick.bat panel"
}

# ---------- status ----------
function DoStatus {
  if (TestOkPat "http://127.0.0.1:$LlamaPort/health" '"status"') { Write-Host "llama-server :$LlamaPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$LlamaPort/") { Write-Host "llama-server :$LlamaPort  端口被其他程序占用" }
  else { Write-Host "llama-server :$LlamaPort  未运行" }
  if (TestOkPat "http://127.0.0.1:$TikuPort/" '題庫管理') { Write-Host "题库后台     :$TikuPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$TikuPort/") { Write-Host "题库后台     :$TikuPort  端口被其他程序占用" }
  else { Write-Host "题库后台     :$TikuPort  未运行" }
  if (TestOkPat "http://127.0.0.1:$AdapterPort/" 'chunk-vendors') { Write-Host "tikuAdapter  :$AdapterPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$AdapterPort/") { Write-Host "tikuAdapter  :$AdapterPort  端口被其他程序占用" }
  else { Write-Host "tikuAdapter  :$AdapterPort  未运行" }
  if (TestOkPat "http://127.0.0.1:$BridgePort/" 'bridge ok') { Write-Host "题库桥接     :$BridgePort  运行中" }
  elseif (TestUp "http://127.0.0.1:$BridgePort/") { Write-Host "题库桥接     :$BridgePort  端口被其他程序占用" }
  else { Write-Host "题库桥接     :$BridgePort  未运行" }
  if (TestOkPat "http://127.0.0.1:$PanelPort/" '刷课控制台') { Write-Host "管理控制台   :$PanelPort  运行中" }
  elseif (TestUp "http://127.0.0.1:$PanelPort/") { Write-Host "管理控制台   :$PanelPort  端口被其他程序占用" }
  else { Write-Host "管理控制台   :$PanelPort  未运行" }
}

# ---------- check（依赖自检，换新电脑先跑这个） ----------
function DoCheck {
  Write-Host "== 依赖自检（换新电脑先跑这个） =="
  if (Test-Path2 $BundledPy) { Write-Host "  [必需] python          OK（包内免安装：$BundledPy）" }
  elseif (Get-Command python -ErrorAction SilentlyContinue) { Write-Host "  [必需] python          OK" }
  else { Write-Host "  [必需] python          缺失（控制台/桥接需要；请用完整交付包，或安装 Python 3 并勾选 Add to PATH）" }
  if ($LlamaBin -and (Test-Path2 $LlamaBin)) { Write-Host "  [AI  ] llama-server    OK  ($LlamaBin)" }
  else { Write-Host "  [AI  ] llama-server    缺失 → $LlamaBin（纯题库模式可无视）" }
  if (Test-Path2 $ModelPath) { Write-Host "  [AI  ] 模型文件        OK  ($ModelPath)" }
  else { Write-Host "  [AI  ] 模型文件        缺失 → $ModelPath（纯题库模式可无视；缺失时启动会自动扫描常见位置）" }
  if (Test-Path (Join-Path $ToolkitDir "tiku\main.py")) { Write-Host "  [题库] 本地题库后台    OK  ($ToolkitDir)" }
  else { Write-Host "  [题库] 本地题库后台    缺失 → $ToolkitDir（不存在则启动时跳过该服务）" }
  if (Test-Path2 $AdapterBin) { Write-Host "  [聚合] tikuAdapter     OK  ($AdapterBin)" }
  else { Write-Host "  [聚合] tikuAdapter     缺失 → $AdapterBin（可选，跳过）" }
  if (Get-Command docker -ErrorAction SilentlyContinue) {
    $dok = $false
    try { docker info *> $null; $dok = ($LASTEXITCODE -eq 0) } catch { $dok = $false }
    if ($dok) {
      Write-Host "  [选装] docker          OK"
      $img = $false
      try { docker image inspect chaoxing:local *> $null; $img = ($LASTEXITCODE -eq 0) } catch { $img = $false }
      if ($img) { Write-Host "  [选装] 镜像 chaoxing:local  OK" }
      else { Write-Host "  [选装] 镜像 chaoxing:local  未导入（首次 run 自动导入/构建）" }
    } else { Write-Host "  [选装] docker          已安装但未启动（仅命令行版 run 需要）" }
  } else { Write-Host "  [选装] docker          不可用（仅命令行版 run 需要）" }
  if ((Get-Command node -ErrorAction SilentlyContinue) -and (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Host "  [选装] node/npm        OK"
  } else { Write-Host "  [选装] node/npm        缺失（仅题库后台前端「首次构建」需要）" }
  $chrome = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
  ) | Where-Object { $_ -and (Test-Path2 $_) } | Select-Object -First 1
  if ($chrome) { Write-Host "  [选装] 浏览器          OK  ($chrome)" }
  else { Write-Host "  [选装] 浏览器          未找到 Chrome/Edge（browser 子命令需要）" }
  if (Test-Path (Join-Path $PSScriptRoot "console-dist")) { Write-Host "  [控制] 控制台已构建    OK  (console-dist\)" }
  else { Write-Host "  [控制] 控制台未构建    缺失 → 在 console/ 运行: npm install && npm run build" }
  Write-Host ""
  Write-Host "== 配置 =="
  if (Test-Path "deploy.env") { Write-Host "  deploy.env  已存在（覆盖默认配置）" }
  else { Write-Host "  deploy.env  未使用（当前用默认值）；改路径: 复制 deploy.env.example 为 deploy.env 再编辑" }
}

# ---------- browser（专用浏览器；脚本默认不随包，见手册 §1.24） ----------
function Start-LocalBrowser {
  $ext = Join-Path $PSScriptRoot "browser-ext"
  $hasExt = Test-Path (Join-Path $ext "bundle.js")
  if (-not $hasExt) {
    # 没随包带浏览器脚本（第三方闭源件，默认不发）→ 仍然开专用浏览器，并指路自装
    Write-Host "== 未随包提供浏览器脚本（第三方闭源件，默认不随包发出）。"
    Write-Host "   ① 推荐：直接用网页版 —— onclick.bat start 后打开 http://127.0.0.1:8003/"
    Write-Host "   ② 想用浏览器脚本：自装 Tampermonkey，再到 GreasyFork / ScriptCat 搜「学习通」"
    Write-Host "   现在仍会打开一个专用浏览器（登录一次免重复登录，只是没有自动脚本面板）。"
  }
  $prof = Join-Path $env:USERPROFILE ".xuexiton-browser"
  $cands = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
  )
  $bin = $cands | Where-Object { Test-Path2 $_ } | Select-Object -First 1
  if (-not $bin) { Write-Host "!! 未找到 Chrome / Edge，请先安装一个浏览器"; return }
  Write-Host "启动专用浏览器（首次登录学习通即可；数据目录: $prof，下次免重复登录）..."
  $bargs = @("--user-data-dir=`"$prof`"", "--no-first-run", "--no-default-browser-check", "https://i.chaoxing.com")
  if ($hasExt) {
    $bargs = @("--user-data-dir=`"$prof`"", "--load-extension=`"$ext`"", "--disable-extensions-except=`"$ext`"", "--no-first-run", "--no-default-browser-check", "https://i.chaoxing.com")
  }
  Start-Process $bin -ArgumentList $bargs
  if ($hasExt) { Write-Host "已启动：登录后进入课程页，右下角出现脚本面板。" }
  else { Write-Host "已启动专用浏览器（无脚本面板；网页版入口: http://127.0.0.1:8003/）" }
}

# ---------- run（命令行版：填账号/课程后自动开刷） ----------
function EnsureImage {
  # 刷课镜像准备：①已有 → 跳过；②本地 tar.gz → docker load；③源码目录 → docker build
  docker image inspect chaoxing:local *> $null
  if ($LASTEXITCODE -eq 0) { return $true }
  $loaded = $false
  $tbs = @((Join-Path $PSScriptRoot "docker\chaoxing-local.tar.gz"), (Join-Path (Split-Path $PSScriptRoot) "docker\chaoxing-local.tar.gz"))
  foreach ($tb in $tbs) {
    if (-not (Test-Path2 $tb)) { continue }
    Write-Host "  导入 Docker 镜像（约 1-2 分钟，请稍候）..."
    docker load -i "$tb"
    if ($LASTEXITCODE -eq 0) { $loaded = $true; break }
    # tar.gz 直载失败时用系统 tar 解压再载
    $tmpTar = Join-Path $env:TEMP "chaoxing-local.tar"
    tar -xzf "$tb" -C $env:TEMP 2>$null
    if (Test-Path2 $tmpTar) {
      docker load -i "$tmpTar"
      Remove-Item $tmpTar -ErrorAction SilentlyContinue
      if ($LASTEXITCODE -eq 0) { $loaded = $true; break }
    }
    Write-Host "   导入失败，尝试其他方式..."
  }
  if (-not $loaded) {
    $srcDir = Join-Path $PSScriptRoot "chaoxing"
    if (Test-Path (Join-Path $srcDir "Dockerfile")) {
      Write-Host "  构建 Docker 镜像 chaoxing:local（首次约 2-5 分钟，需联网）..."
      docker build -t chaoxing:local $srcDir
      if ($LASTEXITCODE -ne 0) { Write-Host "!!  Docker 镜像构建失败"; return $false }
    } else {
      Write-Host "!!  没有可用镜像：既无 docker\chaoxing-local.tar.gz，也无 chaoxing\ 源码目录"
      return $false
    }
  }
  Write-Host "  [OK] Docker 镜像已就绪"
  return $true
}

function DoDocker {
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Write-Host "!!  未检测到 Docker（仅命令行自动刷课需要它）"; return }
  docker info *> $null
  if ($LASTEXITCODE -ne 0) { Write-Host "!!  Docker 守护进程未运行，请先启动 Docker Desktop 再试"; return }
  docker image inspect chaoxing:local *> $null
  if ($LASTEXITCODE -eq 0) { Write-Host "[OK] 刷课镜像 chaoxing:local 已就绪"; return }
  [void](EnsureImage)
}

function DoRun {
  $cfgPath = Join-Path $PSScriptRoot "config.ini"
  $cookies = Join-Path $PSScriptRoot "cookies.txt"
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Host "!!  未检测到 Docker。Windows 可直接用官方 exe 版（见 README 方式 B），或安装 Docker Desktop 后重试。"
    return
  }
  if (-not (EnsureImage)) { return }
  if (-not (Test-Path2 $cfgPath)) { Write-Host "!!  缺少 config.ini"; return }

  $txt = Get-Content $cfgPath -Encoding UTF8
  $uLine = $txt | Where-Object { $_ -match '^\s*username\s*=' } | Select-Object -First 1
  $pLine = $txt | Where-Object { $_ -match '^\s*password\s*=' } | Select-Object -First 1
  $cLine = $txt | Where-Object { $_ -match '^\s*course_list\s*=' } | Select-Object -First 1
  $user = if ($uLine) { ($uLine -replace '^\s*username\s*=\s*','').Trim() } else { "" }
  $pass = if ($pLine) { ($pLine -replace '^\s*password\s*=\s*','').Trim() } else { "" }
  $courses = if ($cLine) { ($cLine -replace '^\s*course_list\s*=\s*','').Trim() } else { "" }

  Write-Host ""
  Write-Host "===== 命令行版：填账号开始刷课 ====="
  if (-not $user -or $user -eq "unused" -or $user -eq "xxx") { $user = (Read-Host "学习通手机号/账号（= 你自己学校的账号，工具不提供）").Trim() }
  else { Write-Host "账号: $user（已保存；换账号请编辑 config.ini）" }
  if (-not $pass -or $pass -eq "unused" -or $pass -eq "xxx") { $pass = (Read-Host "密码").Trim() }
  if (-not $user -or -not $pass) { Write-Host "!!  账号/密码不能为空"; return }
  $coursesInput = (Read-Host "课程ID（逗号分隔；不知道直接回车 → 运行后列出课程让你选）").Trim()
  if ($coursesInput) { $courses = $coursesInput }

  $newTxt = foreach ($line in $txt) {
    if ($line -match '^\s*username\s*=') { "username = $user" }
    elseif ($line -match '^\s*password\s*=') { "password = $pass" }
    elseif ($line -match '^\s*course_list\s*=') { "course_list = $courses" }
    else { $line }
  }
  [System.IO.File]::WriteAllLines($cfgPath, [string[]]$newTxt)

  DoStart
  if (-not (Test-Path2 $cookies)) { New-Item -ItemType File -Path $cookies | Out-Null }

  $runCfg = $cfgPath
  $nowTxt = Get-Content $cfgPath -Encoding UTF8
  if ($nowTxt -match 'http://127\.0\.0\.1:') {
    $runCfg = Join-Path $PSScriptRoot "config.docker.ini"
    $swapped = $nowTxt -replace 'http://127\.0\.0\.1:', 'http://host.docker.internal:'
    [System.IO.File]::WriteAllLines($runCfg, [string[]]$swapped)
    Write-Host "（容器内访问本机：本地地址已自动换为 host.docker.internal）"
  }

  Write-Host ""
  $engineMain = Join-Path $PSScriptRoot "chaoxing\main.py"
  $extraArgs = @()
  if (-not $courses) { $extraArgs += "-it" }
  if (Test-Path2 $engineMain) {
    Write-Host "启动刷课引擎（原生，无需 Docker；登录成功后 cookies 自动保存，下次免重复登录）..."
    $vendor = Join-Path $PSScriptRoot "chaoxing\_vendor"
    if (Test-Path $vendor) { $env:PYTHONPATH = "$vendor;$env:PYTHONPATH" }
    $env:PYTHONIOENCODING = "utf-8"
    $env:PYTHONUTF8 = "1"
    $engPy = if (Test-Path2 $BundledPy) { $BundledPy } else { "python" }
    Push-Location $PSScriptRoot
    try { & $engPy $engineMain -c $cfgPath @extraArgs } finally { Pop-Location }
  } else {
    Write-Host "启动刷课容器（登录成功后 cookies 自动保存，下次免重复登录）..."
    $dockerArgs = @("run", "--rm", "-v", "${runCfg}:/config/config.ini", "-v", "${cookies}:/app/cookies.txt")
    if (-not $courses) { $dockerArgs += "-it" }
    $dockerArgs += "chaoxing:local"
    & docker @dockerArgs
  }
  if ($runCfg -ne $cfgPath) { Remove-Item $runCfg -ErrorAction SilentlyContinue }  # 临时配置含密码副本，用完即删
  Write-Host "运行结束。"
}

# ---------- panel（多课程并行管理面板） ----------
function OpenPanel {
  if (TestUp "http://127.0.0.1:$PanelPort/") {
    try { Start-Process "http://127.0.0.1:$PanelPort/" | Out-Null } catch {}
    Write-Host "已在浏览器打开管理面板: http://127.0.0.1:$PanelPort/"
  } else {
    Write-Host "（管理面板未就绪，稍后可手动打开 http://127.0.0.1:$PanelPort/）"
  }
}
function DoPanel {
  DoStart
  OpenPanel
}

# ---------- 入口 ----------
function ShowHelp {
  Write-Host "学习通本地套件 · 常用命令"
  Write-Host ""
  Write-Host "  onclick.bat start              启动全部服务并自动打开控制台（最常用）"
  Write-Host "  onclick.bat stop               停止全部服务"
  Write-Host "  onclick.bat status             查看五个服务运行状态"
  Write-Host "  onclick.bat check              依赖自检（换新电脑先跑这个）"
  Write-Host "  onclick.bat doctor             设备体检报告（出问题先跑这个，整段复制发给维护者）"
  Write-Host "  onclick.bat browser            打开专用浏览器（登录一次免重复登录；脚本需自装）"
  Write-Host "  onclick.bat run                命令行版刷课（不用浏览器）"
  Write-Host "  onclick.bat panel              打开管理控制台"
  Write-Host "  onclick.bat docker             检查/导入刷课镜像"
  Write-Host "  onclick.bat start tiku         单独启动某个服务（llama-server/tiku/tikuAdapter/bridge/panel）"
  Write-Host "  onclick.bat stop  tiku         单独停止某个服务"
  Write-Host ""
  Write-Host "  完整文档：本目录 README-一键部署.md ｜ 各版改进：CHANGELOG.md"
}

switch ($Action.ToLower()) {
  "start"   { DoStart; if (-not $Service) { OpenPanel } }
  "stop"    { foreach ($s in @("panel", "bridge", "tikuAdapter", "tiku", "llama-server")) { if (Want $s) { StopOne $s } } }
  "status"  { DoStatus }
  "check"   { DoCheck }
  "doctor"  { DoDoctor }
  "体检"    { DoDoctor }
  "report"  { DoDoctor }
  "browser" { Start-LocalBrowser }
  "run"     { DoRun }
  "panel"   { DoPanel }
  "docker"  { DoDocker }
  "help"    { ShowHelp }
  "h"       { ShowHelp }
  default   { Write-Host "用法: onclick.bat start|stop|status|check|doctor|browser|run|panel|docker|help [服务名]" }
}
