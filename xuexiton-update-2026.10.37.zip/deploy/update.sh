#!/usr/bin/env bash
# ============================================================
# 在线更新 deploy 程序文件（保留账号/配置等私有数据）
#
# 用法:
#   ./update.sh --latest             # 从 UPDATE_FEED 检查并更新到最新版（推荐）
#   ./update.sh                      # deploy.env 里有 UPDATE_FEED 就走最新版；否则用 UPDATE_URL
#   ./update.sh https://.../x.zip    # 指定下载地址
#   ./update.sh /path/to/x.zip       # 本地 zip 文件
#
# deploy.env 可配置:
#   UPDATE_FEED=https://cdn.jsdelivr.net/gh/用户名/仓库@main/latest.json
#   UPDATE_URL=https://.../x.zip     # 固定包直链（无 feed 时用）
#
# 安全设计:
#   - 只覆盖程序文件；accounts.json / cookies / config.ini / deploy.env /
#     tasks.json 等私有文件永不被触碰（rsync 不带 --delete + 显式排除）
#   - 更新前自动备份当前程序到 备份-更新前-时间戳/
#   - feed 提供 sha256 时自动校验；版本相同自动跳过
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

[ -f deploy.env ] && . ./deploy.env

ARG="${1:-}"
FEED=""
SHA_EXPECT=""
NOTES=""

DEFAULT_FEED="https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json"
# 备用源：CDN 在发版后会继续返回旧版本清单（HTTP 200 + 过期版本，并不报错），
# 单看一个源会把「有新版本」误判成「已是最新」。两个源都查、取版本号更高的那个。
DEFAULT_FEED_ALT="https://raw.githubusercontent.com/guish207423-ux/xuexiton-release/main/latest.json"

case "$ARG" in
  --latest) FEED="${UPDATE_FEED:-$DEFAULT_FEED}" ;;
  "")       FEED="${UPDATE_FEED:-}" ;;
esac

if [ -n "$FEED" ]; then
  echo "== 检查最新版本: $FEED"
  INFO="$(python3 - "$FEED" "$DEFAULT_FEED" "$DEFAULT_FEED_ALT" 2>/dev/null <<'PYEOF' || true
import json, sys, urllib.request
from urllib.parse import urljoin

def fetch(u):
    req = urllib.request.Request(u, headers={'User-Agent': 'xuexiton-update/1.0'})
    with urllib.request.urlopen(req, timeout=25) as r:
        return json.load(r)

def vt(v):
    return [int(x) for x in __import__('re').findall(r'\d+', v or '')]

feed = sys.argv[1]
srcs = [feed]
if feed == sys.argv[2]:          # 仅内置默认源才加备用源，自定义 feed 不受影响
    srcs.append(sys.argv[3])
best, err = None, None
for u in srcs:
    try:
        d = fetch(u)
    except Exception as e:
        err = e
        continue
    if best is None or vt(str(d.get('version') or '')) > vt(str(best.get('version') or '')):
        best = d
if best is None:
    raise err
url = str(best.get('url', '') or '')
if url and not url.startswith(('http://', 'https://')):
    url = urljoin(feed, url)
raw = str(best.get('url_raw', '') or '')
if raw and not raw.startswith(('http://', 'https://')):
    raw = urljoin(feed, raw)
notes = str(best.get('notes', '') or '').replace('\t', ' ').replace('\n', ' ')
print('\t'.join([str(best.get('version', '?')), url, raw, str(best.get('sha256', '') or ''), notes]))
PYEOF
)"
  if [ -z "$INFO" ]; then
    echo "!! 检查更新失败（网络不通或 feed 地址不对）"
    echo "   若持续失败，可改用「直接传文件」方式更新：把新 zip 发给对方按本地方式应用"
    exit 1
  fi
  IFS=$'\t' read -r VER_NEW URL URL_RAW SHA_EXPECT NOTES <<<"$INFO"
  VER_CUR="$(cat VERSION 2>/dev/null || echo '?')"
  echo "   最新: $VER_NEW    当前: $VER_CUR"
  [ -n "$NOTES" ] && echo "   说明: $NOTES"
  if [ "$VER_NEW" = "$VER_CUR" ]; then
    echo "== 已是最新版本，无需更新。"
    exit 0
  fi
  # 必须比当前新才更新：feed 指向的版本若低于本地（CDN 旧缓存），继续下去就是降级
  if printf '%s' "$VER_NEW" | grep -qE '^[0-9]+(\.[0-9]+)*$' \
     && printf '%s' "$VER_CUR" | grep -qE '^[0-9]+(\.[0-9]+)*$' \
     && [ "$(printf '%s\n%s\n' "$VER_NEW" "$VER_CUR" | sort -V | head -1)" = "$VER_NEW" ]; then
    echo "== 版本源返回的是旧版本（$VER_NEW ≤ 本地 $VER_CUR），已中止，不会降级安装。"
    echo "   稍后重试，或用「直接传文件」方式更新。"
    exit 1
  fi
  [ -n "$URL$URL_RAW" ] || { echo "!! feed 中缺少 url 字段"; exit 1; }
else
  URL="${ARG:-${UPDATE_URL:-}}"
fi

if [ -z "$URL" ]; then
  echo "用法:"
  echo "  ./update.sh --latest            # 检查并更新到最新版（需在 deploy.env 配置 UPDATE_FEED）"
  echo "  ./update.sh <更新包地址或本地zip>"
  echo "  （也可以先在 deploy.env 里设置 UPDATE_FEED 或 UPDATE_URL）"
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# 优先 CDN，失败再试备用直链（CDN 发版后短暂不可用/返回旧内容时仍能更新成功）
DL=""
for CAND in "$URL" "$URL_RAW"; do
  case "$CAND" in
    http://*|https://*)
      echo "== 获取更新包: $CAND"
      if curl -fL --retry 2 --connect-timeout 15 -o "$TMP/u.zip" "$CAND"; then DL=1; break; fi
      echo "   该地址不可用，换下一个…" ;;
    file://*)
      python3 -c "
import shutil, sys, urllib.request
with urllib.request.urlopen(sys.argv[1], timeout=25) as r, open(sys.argv[2], 'wb') as f:
    shutil.copyfileobj(r, f)
" "$CAND" "$TMP/u.zip" && DL=1 && break ;;
    "") ;;
    *)
      if [ -f "$CAND" ]; then cp -f "$CAND" "$TMP/u.zip" && DL=1 && break; fi ;;
  esac
done
if [ -z "$DL" ]; then
  echo "!! 下载失败。若为 GitHub 直链，国内网络可能不稳定，换用其他分发方式（网盘直链/对方发文件）。"
  exit 1
fi

# SHA256 校验（feed 提供时）
if [ -n "$SHA_EXPECT" ]; then
  GOT="$(sha256sum "$TMP/u.zip" | cut -d' ' -f1)"
  if [ "$GOT" != "$SHA_EXPECT" ]; then
    echo "!! SHA256 校验失败（下载不完整或文件被改动），已中止，什么都没改"
    echo "   期望: $SHA_EXPECT"
    echo "   实际: $GOT"
    exit 1
  fi
  echo "== SHA256 校验通过"
fi

# 解压（优先 unzip，没有则用 python3；两者本机与对方机至少有一个）
if command -v unzip >/dev/null 2>&1; then
  unzip -q "$TMP/u.zip" -d "$TMP/x"
else
  python3 - "$TMP/u.zip" "$TMP/x" <<'PYEOF'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    z.extractall(sys.argv[2])
PYEOF
fi
SRC="$TMP/x/deploy"
[ -d "$SRC" ] || SRC="$TMP/x"
[ -f "$SRC/panel.py" ] || { echo "!! 更新包结构不对（缺 panel.py），已中止，什么都没改"; exit 1; }

# 更新前备份当前程序（只备份程序文件，快，几 MB）
# 保留最近 2 份备份，更旧的自动清理（防跨多次更新累积）
ls -dt 备份-更新前-* 2>/dev/null | tail -n +3 | while read -r oldbk; do rm -rf -- "$oldbk"; done || true
BK="备份-更新前-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BK"
rsync -a --exclude '备份-更新前-*' --exclude 'deploy.env' \
      --exclude 'config.ini' --exclude 'config.run.*' --exclude 'config.docker.ini' \
      --exclude 'accounts.json*' --exclude 'cookies*.txt' \
      --exclude 'tasks.json*' --exclude 'events.json' --exclude 'settings.json' \
      --exclude 'harvest*.json' --exclude 'signwatch.json' --exclude 'cache*.json' \
      --exclude '__pycache__' ./ "$BK/" 2>/dev/null || true
echo "== 已备份当前程序到: $BK/（若更新出问题，把里面的文件拷回来即可）"

# 覆盖程序文件（排除私有文件，绝不 --delete）
rsync -a \
  --exclude 'accounts.json*' --exclude 'cookies*.txt' --exclude 'config.ini' \
  --exclude 'config.run.*' --exclude 'config.docker.ini' --exclude 'deploy.env' --exclude 'tasks.json*' \
  --exclude 'events.json' --exclude 'settings.json' --exclude 'harvest*.json' \
  --exclude 'signwatch.json' --exclude 'cache*.json' --exclude '__pycache__/' \
  --exclude '备份-更新前-*' \
  "$SRC/" ./

# 清理已知的无用运行时残留（白名单；绝不触碰账号/配置/进度等私有数据）
rm -f -- chaoxing.log config.docker.ini nohup.out .DS_Store 2>/dev/null || true
rm -rf -- __pycache__ 2>/dev/null || true

VER="$(cat VERSION 2>/dev/null || echo '?')"
# 确保关键脚本保持可执行
chmod +x onclick.sh update.sh 2>/dev/null || true

# 更新后自检：关键文件完整性
MISS=""
for f in panel.py onclick.sh onclick.ps1 bridge.py update.sh; do
  [ -f "$f" ] || MISS="$MISS $f"
done
if [ -n "$MISS" ]; then
  echo "!! 警告：更新后缺少关键文件:$MISS"
  echo "   备份在 $BK/ 中，可把缺的文件拷回来，或重跑一次更新。"
  exit 1
fi

echo ""
echo "================ 更新完成 ================"
echo "当前版本: $VER"
echo "如果服务正在运行，请重启:"
echo "   ./onclick.sh stop && ./onclick.sh start"
echo "（或控制台里逐个重启；浏览器刷新一次页面即可用上新版界面）"
