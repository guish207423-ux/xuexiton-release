#!/usr/bin/env bash
# 学习通本地套件一键管理（Linux）
# 用法: ./onclick.sh start|stop [服务名...] | status | check | browser | run | panel
set -u
cd "$(dirname "$0")"
HERE="$PWD"    # 引擎相关函数(engine_py/engine_ready/engine_native)按 $HERE 定位包内 chaoxing/

# ---------- 配置（可复制 deploy.env.example 为 deploy.env 覆盖） ----------
[ -f deploy.env ] && . ./deploy.env

LLAMA_BIN="${LLAMA_BIN:-$HOME/llama.cpp/build/bin/llama-server}"
MODEL_PATH="${MODEL_PATH:-$HOME/models/qwen3-4b/Qwen3-4B-Q4_K_M.gguf}"
# gguf 自动归位：默认路径不存在时，扫描常见位置找第一个 .gguf（对齐 Windows 侧逻辑）
if [ ! -f "$MODEL_PATH" ]; then
  for d in "$HOME/models" "$(pwd)" "$(pwd)/models" "$HOME/Downloads"; do
    [ -d "$d" ] || continue
    found="$(find "$d" -maxdepth 3 -name '*.gguf' -type f 2>/dev/null | head -1)"
    if [ -n "$found" ]; then MODEL_PATH="$found"; break; fi
  done
fi
TOOLKIT_DIR="${TOOLKIT_DIR:-$HOME/Projects/chaoxing-lab/chaoxing-toolkit}"
TIKU_ADAPTER_BIN="${TIKU_ADAPTER_BIN:-$HOME/Projects/chaoxing-lab/tiku-run/tikuAdapter}"
TIKU_ADAPTER_DIR="${TIKU_ADAPTER_DIR:-$(dirname "$TIKU_ADAPTER_BIN")}"
LLAMA_PORT="${LLAMA_PORT:-8080}"
TIKU_PORT="${TIKU_PORT:-8001}"
ADAPTER_PORT="${ADAPTER_PORT:-8060}"
BRIDGE_PORT="${BRIDGE_PORT:-8002}"
PANEL_PORT="${PANEL_PORT:-8003}"
LLAMA_NGL="${LLAMA_NGL:-99}"
LLAMA_DEV="${LLAMA_DEV-Vulkan0}"
LLAMA_CTX="${LLAMA_CTX:-4096}"
LOG_DIR="${LOG_DIR:-/tmp/xuexiton-deploy}"
# 同一台机器上可能同时存在多份安装（已安装副本 + 从 U 盘/别处直接跑的副本）。
# pid 文件名带上本安装目录的指纹，避免两份安装互相覆盖记录 → stop 误杀对方的服务。
# 日志仍共用 $LOG_DIR（方便人看），只有 pid 记录按安装隔离。
_tag() {
  local h; h="$(printf '%s' "$1" | md5sum 2>/dev/null | cut -c1-8)"
  [ -n "$h" ] || h="$(printf '%s' "$1" | cksum 2>/dev/null | cut -d' ' -f1)"
  printf '%s' "${h:-inst}"
}
INSTANCE_TAG="$(_tag "$PWD")"
pidfile_of() { printf '%s/%s.%s.pid' "$LOG_DIR" "$1" "$INSTANCE_TAG"; }

# 旧版共用 pid 文件的归属校验：这个 pid 是不是本安装启动的？
# （比对工作目录与命令行里的本安装路径——旧文件只在升级后的第一次 stop 用得到）
owns_pid() {
  local pid="$1" cwd cl pat
  cwd="$(readlink -f "/proc/$pid/cwd" 2>/dev/null || true)"
  case "$cwd" in "$PWD"|"$PWD"/*) return 0 ;; esac
  cl="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
  # 只把非空的路径拼进模式：任一变量为空时模式会退化成 "**" 匹配一切，把别人的进程判成自己的
  #（后果：端口让位失效，甚至有误杀别人进程的风险）。默认值都非空，这里只是不依赖那个前提。
  for pat in "$PWD/" "$LLAMA_BIN" "$TIKU_ADAPTER_BIN" "$TOOLKIT_DIR" "$TIKU_ADAPTER_DIR"; do
    [ -n "$pat" ] || continue
    case "$cl" in *"$pat"*) return 0 ;; esac
  done
  return 1
}

# 监听某端口的进程 pid（拿不到时为空——别的用户的进程需要更高权限）
_port_listener_pid() {
  ss -ltnp 2>/dev/null | grep ":$1 " | head -1 | grep -o 'pid=[0-9]*' | cut -d= -f2 | head -1
}

# 端口让位：默认端口被**别的程序**占用时，自动顺延到空闲端口，并写回 deploy.env。
# 为什么要写回：控制台、桥接等依赖方都从 deploy.env 读端口，写回才能让它们一起用新端口。
# 判据：① 端口空闲 → 保持 ② 占用者是本套件自己的服务（重启场景）→ 保持 ③ 其它 → 让位。
resolve_port() {
  local var="$1" port="$2" name="$3" i cand pid
  if ! ss -ltn 2>/dev/null | grep -q ":$port "; then printf '%s' "$port"; return 0; fi
  # ★ 先按响应特征串认自己人：服务可能是用相对命令行起的（python panel.py），
  #   按 exe/cwd 的 PID 归属判断会失败 → 端口被误判成"外人占用" → 每次启动都漂移并改写 deploy.env。
  local mk=""
  case "$name" in
    *AI*)       mk='"status"' ;;
    *题库后台*) mk="題庫管理" ;;
    *聚合*)     mk="chunk-vendors" ;;
    *桥接*)     mk="bridge ok" ;;
    *控制台*)   mk="刷课控制台" ;;
  esac
  if [ -n "$mk" ] && ok_has "http://127.0.0.1:$port/" "$mk"; then printf '%s' "$port"; return 0; fi
  pid="$(_port_listener_pid "$port")"
  if [ -n "$pid" ] && owns_pid "$pid"; then printf '%s' "$port"; return 0; fi
  for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30; do
    cand=$((port+i))
    ss -ltn 2>/dev/null | grep -q ":$cand " && continue
    case " $LLAMA_PORT $TIKU_PORT $ADAPTER_PORT $BRIDGE_PORT $PANEL_PORT " in *" $cand "*) continue ;; esac
    say "!!  [$name] 默认端口 :$port 被占用 → 自动改用 :$cand（别人占着端口不再让整个功能起不来）" >&2
    if [ -f deploy.env ]; then
      if grep -qE "^[[:space:]]*$var=" deploy.env; then
        sed -i "s|^[[:space:]]*$var=.*|$var=$cand|" deploy.env
      else
        printf '\n# 端口让位自动写入（默认 :%s 被别的程序占用）\n%s=%s\n' "$port" "$var" "$cand" >> deploy.env
      fi
    else
      printf '# 端口让位自动创建（默认 :%s 被别的程序占用）\n%s=%s\n' "$port" "$var" "$cand" > deploy.env
    fi
    say "    已记入 deploy.env（$var=$cand），控制台与桥接会一起用新端口；想改回去先腾出 :$port" >&2
    printf '%s' "$cand"; return 0
  done
  say "!!  [$name] 从 :$port 起连续 30 个端口都被占用——仍按 :$port 尝试（日志里能看到绑定失败原因）" >&2
  printf '%s' "$port"; return 0
}
_service_marker() {
  case "$1" in
    llama-server) printf '%s' "$LLAMA_BIN" ;;
    tikuAdapter)  printf '%s' "$TIKU_ADAPTER_BIN" ;;
    tiku)         printf '%s' "$TOOLKIT_DIR" ;;
    bridge)       printf '%s/bridge' "$PWD" ;;
    panel)        printf '%s/panel.py' "$PWD" ;;
    *)            printf '' ;;
  esac
}
# 服务对应的端口 / 健康判据（与 Windows 侧 Get-SvcPort / Get-SvcMarker 一致）
_svc_port() {
  case "$1" in
    llama-server) printf '%s' "$LLAMA_PORT" ;;
    tiku)         printf '%s' "$TIKU_PORT" ;;
    tikuAdapter)  printf '%s' "$ADAPTER_PORT" ;;
    bridge)       printf '%s' "$BRIDGE_PORT" ;;
    panel)        printf '%s' "$PANEL_PORT" ;;
  esac
}
_svc_has() {
  case "$1" in
    llama-server) ok_has "http://127.0.0.1:$LLAMA_PORT/health" '"status"' ;;
    tiku)         ok_has "http://127.0.0.1:$TIKU_PORT/" '題庫管理' ;;
    tikuAdapter)  ok_has "http://127.0.0.1:$ADAPTER_PORT/" 'chunk-vendors' ;;
    bridge)       ok_has "http://127.0.0.1:$BRIDGE_PORT/" 'bridge ok' ;;
    panel)        ok_has "http://127.0.0.1:$PANEL_PORT/" '刷课控制台' ;;
  esac
}
# 精确兜底：端口上应答的是我们这台的服务 → 取该端口监听者 pid
_find_ours_by_port() {
  _svc_has "$1" || return 1
  _port_listener_pid "$(_svc_port "$1")"
}

# 在进程表里找本安装的某个服务（没有 pid 文件时的兜底）——返回 pid
_find_ours_by_name() {
  local name="$1" mk d pid c e m
  mk="$(_service_marker "$name")"; [ -n "$mk" ] || return 1
  for d in /proc/[0-9]*; do
    pid="${d#/proc/}"
    [ "$pid" = "$$" ] && continue
    [ -r "$d/cmdline" ] || continue
    c="$(readlink "$d/cwd" 2>/dev/null || true)"
    e="$(readlink "$d/exe" 2>/dev/null || true)"
    m="$(tr '\0' ' ' 2>/dev/null < "$d/cmdline" || true)"
    case "$c$e$m" in
      *"$mk"*) owns_pid "$pid" && { printf '%s' "$pid"; return 0; } ;;
    esac
  done
  return 1
}
PY="${PY:-python3}"

mkdir -p "$LOG_DIR"

# ---------- 终端配色（仅 TTY 且未设 NO_COLOR 时启用；日志/管道场景自动无色） ----------
C_OK=; C_ERR=; C_BOLD=; C_DIM=; C_RST=
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
  C_OK=$'\033[32m'; C_ERR=$'\033[31m'; C_BOLD=$'\033[1m'; C_DIM=$'\033[2m'; C_RST=$'\033[0m'
fi
say() {
  if [ -n "$C_RST" ]; then
    case "$*" in
      "OK  "*|"OK "*)      printf '%s%s%s\n' "$C_OK"   "$*" "$C_RST"; return ;;
      "!!  "*|"!! "*)      printf '%s%s%s\n' "$C_ERR"  "$*" "$C_RST"; return ;;
      "== "*|"===="*|"╔"*|"║"*|"╚"*) printf '%s%s%s\n' "$C_BOLD" "$*" "$C_RST"; return ;;
      "  ..."*|"日志"*)    printf '%s%s%s\n' "$C_DIM"  "$*" "$C_RST"; return ;;
    esac
  fi
  printf '%s\n' "$*"
}
ok()      { curl -sf -m 3 "$1" >/dev/null 2>&1; }   # 需要 2xx
ok_has()  { curl -sf -m 3 "$1" 2>/dev/null | grep -q -- "$2"; }   # 2xx 且响应含特征字符串（防其它程序占用端口的误判）
up()      { curl -s  -m 3 "$1" >/dev/null 2>&1; }   # 有响应即可

# 后台启动并写 pid 文件: spawn_bg <名字> <工作目录> <命令...>
spawn_bg() {
  local name="$1" cwd="$2"; shift 2
  if [ ! -d "$cwd" ]; then say "!!  [$name] 目录不存在: $cwd"; return 1; fi
  # 日志轮转：启动前若日志超过 10MB，保留一份 .old（防跨重启累积增长）
  local logf="$LOG_DIR/$name.log"
  if [ -f "$logf" ] && [ "$(stat -c%s "$logf" 2>/dev/null || echo 0)" -gt 10485760 ]; then
    mv -f "$logf" "$logf.old" 2>/dev/null || true
  fi
  "$PY" - "$LOG_DIR/$name.log" "$(pidfile_of "$name")" "$cwd" "$@" <<'EOF'
import subprocess, sys
log, pidfile, cwd, cmd = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:]
p = subprocess.Popen(cmd, cwd=cwd, stdin=subprocess.DEVNULL,
                     stdout=open(log, "ab"), stderr=subprocess.STDOUT,
                     start_new_session=True, close_fds=True)
open(pidfile, "w").write(str(p.pid))
EOF
}

# 等待 URL 就绪: wait_ok <名字> <url> [次数]
wait_ok() {
  local name="$1" url="$2" pat="${4:-}" i ready=0
  local tries="${3:-40}" total=$(( ${3:-40} * 5 ))
  for i in $(seq 1 "$tries"); do
    if [ -n "$pat" ]; then ok_has "$url" "$pat" && ready=1; else ok "$url" && ready=1; fi
    if [ "$ready" = 1 ]; then
      [ "$i" -le 1 ] && say "OK  [$name] 就绪" || say "OK  [$name] 就绪（用时约 $((i*5))s）"
      return 0
    fi
    [ $((i % 2)) -eq 0 ] && say "  ...[$name] 启动中（$((i*5))s/${total}s，日志: $LOG_DIR/$name.log）"
    sleep 5
  done
  say "!!  [$name] 等待超时（日志: $LOG_DIR/$name.log）"; return 1
}

stop_one() {
  local name="$1" f pid
  f="$(pidfile_of "$name")"
  if [ ! -f "$f" ]; then
    # 兼容旧版共用的 <名字>.pid（升级后第一次 stop 会走到这里）
    f="$LOG_DIR/$name.pid"
    if [ ! -f "$f" ]; then
      # 没有 pid 文件 ≠ 没在跑：服务可能由控制台守护拉起、或上次崩溃/重启留下了残留进程。
      # 用「归属判定」兜底收掉——否则它一直占着端口，下一次 start 就起不来（换新电脑常见）。
      pid="$(_find_ours_by_port "$name" || true)"
      [ -n "$pid" ] || pid="$(_find_ours_by_name "$name" || true)"
      if [ -n "$pid" ]; then
        kill "$pid" 2>/dev/null
        for _ in 1 2 3 4 5; do kill -0 "$pid" 2>/dev/null || break; sleep 1; done
        kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
        say "已停止 [$name] (pid $pid；无 pid 文件——由控制台拉起或上次残留)"
      else
        say "跳过 [$name]（未发现本安装的该服务在跑）"
      fi
      return 0
    fi
    pid="$(cat "$f" 2>/dev/null || true)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && ! owns_pid "$pid"; then
      say "跳过 [$name]（pid $pid 属于另一份安装——pid 文件已按安装隔离，不再共用）"
      return 0
    fi
  fi
  pid="$(cat "$f" 2>/dev/null || true)"
  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null
    for _ in 1 2 3 4 5; do kill -0 "$pid" 2>/dev/null || break; sleep 1; done
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
    say "已停止 [$name] (pid $pid)"
  else
    say "跳过 [$name]（进程已退出）"
  fi
  rm -f "$f"
}

# 服务名过滤：无参数=全部；支持 llama→llama-server、adapter→tikuAdapter 别名
wants() {
  local w="$1"; shift
  [ "$#" -eq 0 ] && return 0
  local s; for s in "$@"; do [ "$s" = "$w" ] && return 0; done
  return 1
}

start() {
  local sel=() a
  for a in "$@"; do
    case "$a" in llama) a=llama-server ;; adapter) a=tikuAdapter ;; esac
    sel+=("$a")
  done

  # 直接从外置盘运行？警告并默认拒绝（数据会写外置盘、无法安全弹出）
  local _onusb=0
  case "$(findmnt -no FSTYPE -T . 2>/dev/null || true)" in
    vfat|exfat|ntfs|ntfs3|msdos|iso9660|udf) _onusb=1 ;;
    *) case "$(pwd)" in /run/media/*|/media/*) _onusb=1 ;; esac ;;
  esac
  if [ "$_onusb" = 1 ]; then
      say "!!  注意：你正在直接从 U 盘/外置盘运行本工具（$(pwd)）。"
      say "    账号、进度、日志等数据会写进 U 盘，并且 U 盘将无法安全弹出。"
      say "    正确做法：在 U 盘根目录运行  bash 安装.sh（Windows 双击 安装.bat），"
      say "    装好后从桌面 xuexiton/deploy 启动。"
      if [ -t 0 ]; then
        read -r -p "  仍要从 U 盘临时运行？[y/N] " a
        case "$a" in y|Y|yes|YES) ;; *) say "  已退出。"; return 0 ;; esac
      elif [ -z "${XUEXITON_FORCE:-}" ]; then
        say "  （非交互模式：已停止。确定要从 U 盘运行请设置 XUEXITON_FORCE=1）"
        return 0
      fi
  fi

  # 端口让位（一次算好，后面各服务都用让位后的端口）：默认端口被别的程序占用就顺延，
  # 并写回 deploy.env —— 否则热闹机器上端口一撞，用户看到的就是"服务起不来"。
  LLAMA_PORT="$(resolve_port LLAMA_PORT "$LLAMA_PORT" "AI 模型")"
  TIKU_PORT="$(resolve_port TIKU_PORT "$TIKU_PORT" "题库后台")"
  ADAPTER_PORT="$(resolve_port ADAPTER_PORT "$ADAPTER_PORT" "聚合题库")"
  BRIDGE_PORT="$(resolve_port BRIDGE_PORT "$BRIDGE_PORT" "题库桥接")"
  PANEL_PORT="$(resolve_port PANEL_PORT "$PANEL_PORT" "管理控制台")"
  export LLAMA_PORT TIKU_PORT ADAPTER_PORT BRIDGE_PORT PANEL_PORT

  # 1) AI 模型 llama-server
  if wants llama-server "${sel[@]}"; then
  if ok_has "http://127.0.0.1:$LLAMA_PORT/health" '"status"'; then
    say "跳过 AI 模型（已在运行 :$LLAMA_PORT）"
  elif up "http://127.0.0.1:$LLAMA_PORT/"; then
    say "!!  端口 :$LLAMA_PORT 已被其他程序占用（不是本套件的 AI 模型）——未启动，请先排查占用"
    say "    （查看占用：ss -ltnp | grep \":$LLAMA_PORT \"）"
  elif [ -x "$LLAMA_BIN" ] && [ -f "$MODEL_PATH" ]; then
    say "启动 AI 模型 llama-server（首次加载模型约 1-3 分钟）..."
    local dev=(); [ -n "$LLAMA_DEV" ] && dev=(-dev "$LLAMA_DEV")
    spawn_bg llama-server "$HOME" "$LLAMA_BIN" -m "$MODEL_PATH" \
      -ngl "$LLAMA_NGL" "${dev[@]}" -c "$LLAMA_CTX" --parallel 1 \
      -n 1024 --temp 0.7 --top-p 0.95 --top-k 20 --reasoning off \
      --host 127.0.0.1 --port "$LLAMA_PORT" --no-webui
    wait_ok llama-server "http://127.0.0.1:$LLAMA_PORT/health" 40 '"status"' || true
  else
    say "!!  跳过 AI 模型：找不到 $LLAMA_BIN 或模型 $MODEL_PATH"
    say "    （复制 deploy.env.example 为 deploy.env 后修改路径）"
  fi
  fi

  # 2) 本地题库 Web 管理后台（chaoxing-toolkit）
  if wants tiku "${sel[@]}"; then
  if ok_has "http://127.0.0.1:$TIKU_PORT/" '題庫管理'; then
    say "跳过 题库后台（已在运行 :$TIKU_PORT）"
  elif up "http://127.0.0.1:$TIKU_PORT/"; then
    say "!!  端口 :$TIKU_PORT 已被其他程序占用（不是本套件的题库后台）——未启动，请先排查占用"
    say "    （查看占用：ss -ltnp | grep \":$TIKU_PORT \"）"
  elif [ -f "$TOOLKIT_DIR/tiku/main.py" ]; then
    # 题库后台前端未构建（static/index.html 缺失）时自动构建（需要 Node/npm）
    if [ ! -f "$TOOLKIT_DIR/tiku/static/index.html" ] && [ -d "$TOOLKIT_DIR/tiku/frontend" ]; then
      if command -v npm >/dev/null 2>&1; then
        say "首次准备：构建题库后台前端（约 1 分钟，日志 $LOG_DIR/tiku-build.log）..."
        if ( cd "$TOOLKIT_DIR/tiku/frontend" && npm install --no-audit --no-fund && npm run build && mkdir -p ../static && cp -r dist/* ../static/ ) >>"$LOG_DIR/tiku-build.log" 2>&1; then
          say "题库后台前端构建完成"
        else
          say "!!  题库后台前端构建失败（日志 $LOG_DIR/tiku-build.log），后台页可能显示构建提示"
        fi
      else
        say "!!  题库后台前端未构建且未装 Node/npm；后台页可能显示构建提示（不影响其他功能）"
      fi
    fi
    local venv="$TOOLKIT_DIR/tiku/.venv"
    if [ ! -x "$venv/bin/python" ]; then
      say "初始化题库服务 venv ..."
      "$PY" -m venv "$venv" && "$venv/bin/pip" install -q -r "$TOOLKIT_DIR/tiku/requirements.txt"
    fi
    say "启动 题库后台 :$TIKU_PORT ..."
    ( export PORT="$TIKU_PORT"; spawn_bg tiku "$TOOLKIT_DIR/tiku" "$venv/bin/python" main.py )
    wait_ok tiku "http://127.0.0.1:$TIKU_PORT/" 12 '題庫管理' || true
  else
    say "跳过 题库后台（未找到 $TOOLKIT_DIR/tiku/main.py）"
  fi
  fi

  # 3) 聚合题库 tikuAdapter（可选）
  if wants tikuAdapter "${sel[@]}"; then
  if ok_has "http://127.0.0.1:$ADAPTER_PORT/" 'chunk-vendors'; then
    say "跳过 tikuAdapter（已在运行 :$ADAPTER_PORT）"
  elif up "http://127.0.0.1:$ADAPTER_PORT/"; then
    say "!!  端口 :$ADAPTER_PORT 已被其他程序占用（不是本套件的聚合题库）——未启动，请先排查占用"
    say "    （查看占用：ss -ltnp | grep \":$ADAPTER_PORT \"）"
  elif [ -x "$TIKU_ADAPTER_BIN" ]; then
    say "启动 tikuAdapter :$ADAPTER_PORT ..."
    spawn_bg tikuAdapter "$TIKU_ADAPTER_DIR" "./$(basename "$TIKU_ADAPTER_BIN")"
    wait_ok tikuAdapter "http://127.0.0.1:$ADAPTER_PORT/" 6 'chunk-vendors' || true
  else
    say "跳过 tikuAdapter（未找到 $TIKU_ADAPTER_BIN，可选组件）"
  fi
  fi

  # 4) 题库桥接（把 ①② 统一成用户脚本格式）
  if wants bridge "${sel[@]}"; then
  if ok_has "http://127.0.0.1:$BRIDGE_PORT/" 'bridge ok'; then
    say "跳过 题库桥接（已在运行 :$BRIDGE_PORT）"
  elif up "http://127.0.0.1:$BRIDGE_PORT/"; then
    say "!!  端口 :$BRIDGE_PORT 已被其他程序占用（不是本套件的题库桥接）——未启动，请先排查占用"
    say "    （查看占用：ss -ltnp | grep \":$BRIDGE_PORT \"）"
  else
    say "启动 题库桥接 :$BRIDGE_PORT ..."
    ( export PORT="$BRIDGE_PORT" TIKU_PORT ADAPTER_PORT
      spawn_bg bridge "$(pwd)" "$PY" bridge.py )
    wait_ok bridge "http://127.0.0.1:$BRIDGE_PORT/" 6 'bridge ok' || true
  fi
  fi

  # 5) 管理控制台 panel
  if wants panel "${sel[@]}"; then
  if ok_has "http://127.0.0.1:$PANEL_PORT/" '刷课控制台'; then
    say "跳过 管理控制台（已在运行 :$PANEL_PORT）"
  elif up "http://127.0.0.1:$PANEL_PORT/"; then
    say "!!  端口 :$PANEL_PORT 已被其他程序占用（不是本套件的管理控制台）——未启动，请先排查占用"
    say "    （查看占用：ss -ltnp | grep \":$PANEL_PORT \"）"
  else
    say "启动 管理控制台 :$PANEL_PORT ..."
    ( export PORT="$PANEL_PORT"; spawn_bg panel "$(pwd)" "$PY" panel.py "$PANEL_PORT" )
    wait_ok panel "http://127.0.0.1:$PANEL_PORT/" 4 '刷课控制台' || true
  fi
  fi

  [ ${#sel[@]} -eq 0 ] || { say "已处理: ${sel[*]}"; return 0; }

  say ""
  say "================= 就绪情况 ================="
  ok_has "http://127.0.0.1:$LLAMA_PORT/health" '"status"'    && say "AI 模型      : http://127.0.0.1:$LLAMA_PORT/v1/chat/completions"
  ok_has "http://127.0.0.1:$TIKU_PORT/" '題庫管理'           && say "题库管理后台 : http://127.0.0.1:$TIKU_PORT/  （浏览器打开）"
  ok_has "http://127.0.0.1:$ADAPTER_PORT/" 'chunk-vendors'   && say "聚合题库页   : http://127.0.0.1:$ADAPTER_PORT/  （浏览器打开）"
  ok_has "http://127.0.0.1:$BRIDGE_PORT/" 'bridge ok'        && say "题库桥接     : http://127.0.0.1:$BRIDGE_PORT/search"
  ok_has "http://127.0.0.1:$PANEL_PORT/" '刷课控制台'        && say "管理控制台   : http://127.0.0.1:$PANEL_PORT/  （浏览器打开）"
  # 命令行引擎状态（原生优先，无需 Docker）
  if engine_ready; then
    say "命令行引擎  : 原生就绪（无需 Docker）"
  elif command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    if docker image inspect chaoxing:local >/dev/null 2>&1; then
      say "命令行引擎  : Docker 镜像已就绪"
    else
      say "Docker 镜像  : 未导入（首次命令行刷课自动导入，或先跑 ./onclick.sh docker）"
    fi
  fi
  say ""
  say "打开专用浏览器（登录一次免重复登录）: ./onclick.sh browser"
  say "（本套件不附带浏览器脚本；只有你自装了油猴脚本时，才需要在右下角面板里填：）"
  say "  自定义题库地址 = http://127.0.0.1:$BRIDGE_PORT/search"
  say "  AI API 地址    = http://127.0.0.1:$LLAMA_PORT/v1/chat/completions"
  say "  AI 模型名称    = bonsai（任意非空）  AI 密钥 = local（任意非空）"
  say ""
  say "命令行版（可选，不用浏览器）: ./onclick.sh run   （按提示填账号/课程后自动开刷）"
  say "管理控制台（多账号/课程/速率）: ./onclick.sh panel   （浏览器打开 http://127.0.0.1:$PANEL_PORT/）"
  say "日志: $LOG_DIR"
  # 自动打开管理控制台（图形环境）
  open_panel
}

browser() {
  local bin="" prof="${XXT_PROFILE:-$HOME/.xuexiton-browser}" ext="$(pwd)/browser-ext"
  for c in chromium chromium-browser google-chrome google-chrome-stable microsoft-edge-stable microsoft-edge; do
    if command -v "$c" >/dev/null 2>&1; then bin="$c"; break; fi
  done
  if [ -z "$bin" ]; then say "!!  未找到 Chromium / Chrome / Edge，请先安装一个浏览器"; return 1; fi
  if [ ! -f "$ext/bundle.js" ]; then
    # 没随包带浏览器脚本（第三方闭源，默认不发）→ 仍然开专用浏览器，并指路自装
    say "== 未随包提供浏览器脚本（第三方闭源件，默认不随包发出）。"
    say "   ① 推荐：直接用网页版 —— ./onclick.sh start 后打开 http://127.0.0.1:8003/"
    say "   ② 想用浏览器脚本：自装 Tampermonkey，再到 GreasyFork / ScriptCat 搜「学习通」"
    say "   现在仍会打开一个专用浏览器（登录一次免重复登录，只是没有自动脚本面板）。"
  fi
  if [ -f "$ext/bundle.js" ]; then
    say "启动专用浏览器（含脚本；数据目录: $prof，下次免重复登录）..."
    setsid nohup "$bin" --user-data-dir="$prof" --load-extension="$ext" --disable-extensions-except="$ext" \
      --no-first-run --no-default-browser-check "https://i.chaoxing.com" >/dev/null 2>&1 &
    say "已启动：登录后进入课程页，右下角出现脚本面板（面板配置见 ./onclick.sh start 的输出）。"
  else
    say "启动专用浏览器（无脚本；数据目录: $prof，下次免重复登录）..."
    setsid nohup "$bin" --user-data-dir="$prof" \
      --no-first-run --no-default-browser-check "https://i.chaoxing.com" >/dev/null 2>&1 &
    say "已启动专用浏览器（无脚本面板；网页版入口: http://127.0.0.1:${PANEL_PORT:-8003}/）"
  fi
}

run() {
  local cfg="$(pwd)/config.ini" cookies="$(pwd)/cookies.txt"
  # 原生引擎可用时完全不需要 Docker；只有走 Docker 回退才要求装了 Docker
  if ! engine_ready && ! command -v docker >/dev/null 2>&1; then
    say "!!  未检测到 Docker，且包内原生引擎不可用（需要二者之一）。"
    say "    Linux 安装 docker；Windows 装 Docker Desktop。"
    say "    （也可以改用浏览器版: ./onclick.sh browser）"
    return 1
  fi
  if ! engine_ready; then
  # 自动部署镜像：①已有 → 跳过；②本地 tar.gz → docker load；③源码目录 → docker build
  if docker image inspect chaoxing:local >/dev/null 2>&1; then
    say "  [OK] Docker 镜像已在（chaoxing:local）"
  else
    local loaded=0 tb
    for tb in "$(pwd)/docker/chaoxing-local.tar.gz" "$(pwd)/../docker/chaoxing-local.tar.gz"; do
      if [ -f "$tb" ]; then
        say "  导入 Docker 镜像（$tb；约 1-2 分钟）..."
        if gzip -dc "$tb" | docker load >/dev/null 2>&1; then loaded=1; break; fi
        say "   导入失败，尝试其他方式..."
      fi
    done
    if [ "$loaded" = 0 ]; then
      if [ -f "$(pwd)/chaoxing/Dockerfile" ]; then
        say "  构建 Docker 镜像 chaoxing:local（首次约 2-5 分钟，需联网）..."
        docker build -t chaoxing:local "$(pwd)/chaoxing" || { say "!!  Docker 镜像构建失败"; return 1; }
      else
        say "!!  没有可用镜像：既无 docker/chaoxing-local.tar.gz，也无 chaoxing/ 源码目录"
        say "    （重插 U 盘重新安装，或联网后手动: cd chaoxing && docker build -t chaoxing:local .）"
        return 1
      fi
    fi
    say "  [OK] Docker 镜像已就绪"
  fi
  fi   # 结束「原生引擎不可用时才准备 Docker 镜像」
  [ -f "$cfg" ] || { say "!!  缺少 config.ini"; return 1; }

  local username password courses courses_input=""
  IFS=$'\t' read -r username password courses < <("$PY" - "$cfg" <<'PY'
import sys
d = {}
for line in open(sys.argv[1], encoding="utf-8"):
    s = line.strip()
    if not s or s[0] in ";#[" or "=" not in s:
        continue
    k, v = s.split("=", 1)
    d[k.strip()] = v.strip()
print(d.get("username", ""), d.get("password", ""), d.get("course_list", ""), sep="\t")
PY
)

  say ""
  say "===== 命令行版：填账号开始刷课 ====="
  if [ "$username" = "unused" ] || [ "$username" = "xxx" ] || [ -z "$username" ]; then
    printf "学习通手机号/账号（= 你自己学校的账号，工具不提供）: "
    read -r username
  else
    say "账号: $username（已保存；换账号请编辑 config.ini）"
  fi
  if [ "$password" = "unused" ] || [ "$password" = "xxx" ] || [ -z "$password" ]; then
    printf "密码: "
    read -r -s password; printf "\n"
  fi
  if [ -z "$username" ] || [ -z "$password" ]; then say "!!  账号/密码不能为空"; return 1; fi
  printf "课程ID（逗号分隔；不知道直接回车 → 运行后列出课程让你选）: "
  read -r courses_input
  [ -n "$courses_input" ] && courses="$courses_input"

  "$PY" - "$cfg" "$username" "$password" "$courses" <<'PY'
import sys
cfg = sys.argv[1]
user, pw, courses = sys.argv[2], sys.argv[3], sys.argv[4]
out = []
for line in open(cfg, encoding="utf-8").read().split("\n"):
    s = line.strip()
    if s.startswith("username"): line = "username = " + user
    elif s.startswith("password"): line = "password = " + pw
    elif s.startswith("course_list"): line = "course_list = " + courses
    out.append(line)
open(cfg, "w", encoding="utf-8").write("\n".join(out))
PY

  start

  touch "$cookies"
  say ""
  say "启动刷课容器（登录成功后 cookies 自动保存，下次免重复登录）..."
  local it=(); [ -z "$courses" ] && it=(-it)
  if engine_ready; then
    say "启动刷课引擎（原生，无需 Docker；登录成功后 cookies 自动保存，下次免重复登录）..."
    engine_native "$cfg" "${it[@]}"
  else
    say "!!  包内引擎不可用，尝试 Docker 回退..."
    docker run --rm "${it[@]}" --network host \
      -v "$cfg:/config/config.ini" -v "$cookies:/app/cookies.txt" chaoxing:local
  fi
  say "运行结束。"
}

open_panel() {
  if up "http://127.0.0.1:$PANEL_PORT/"; then
    if command -v xdg-open >/dev/null 2>&1 && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
      ( setsid xdg-open "http://127.0.0.1:$PANEL_PORT/" >/dev/null 2>&1 & )
      say "已在浏览器打开管理控制台: http://127.0.0.1:$PANEL_PORT/"
    else
      say "管理控制台: http://127.0.0.1:$PANEL_PORT/  （浏览器打开）"
    fi
  else
    say "（管理控制台未就绪，稍后可手动打开 http://127.0.0.1:$PANEL_PORT/）"
  fi
}

# ---- 命令行引擎：原生优先（包内 chaoxing/ + _vendor，无需 Docker）；缺失才回退 docker ----
engine_py() {
  if [ -x "$HERE/../py/bin/python3" ]; then printf '%s' "$HERE/../py/bin/python3"
  elif [ -f "$HERE/../py/python.exe" ]; then printf '%s' "$HERE/../py/python.exe"
  else printf '%s' "${PY:-python3}"; fi
}

# 依赖随包分发：Windows 用 chaoxing/_vendor，其它平台用 chaoxing/_vendor_linux
engine_vendor_dir() {
  case "$(uname -s 2>/dev/null)" in
    Linux|Darwin|*BSD) printf '%s' "$HERE/chaoxing/_vendor_linux" ;;
    *)                 printf '%s' "$HERE/chaoxing/_vendor" ;;    # Windows / MSYS
  esac
}

engine_env() {
  local v; v="$(engine_vendor_dir)"
  [ -d "$v" ] && export PYTHONPATH="$v${PYTHONPATH:+:$PYTHONPATH}"   # 追加，不遮蔽已有依赖
  export PYTHONIOENCODING=utf-8 PYTHONUTF8=1
}

# 只看文件存在会骗人：依赖缺失时照样判成「原生就绪」，然后每次都在 import 处崩，
# 还把 Docker 回退一并挡住。跑一次 `main.py -h` 就能把整条 import 链验完。
# 结果在本次调用内缓存，重复调用不重复探活。
engine_ready() {
  if [ -z "${ENGINE_OK:-}" ]; then
    ENGINE_OK=0
    if [ -f "$HERE/chaoxing/main.py" ] && command -v "$(engine_py)" >/dev/null 2>&1; then
      ( cd "$HERE" && engine_env && "$(engine_py)" "$HERE/chaoxing/main.py" -h ) >/dev/null 2>&1 \
        && ENGINE_OK=1
    fi
  fi
  [ "$ENGINE_OK" = 1 ]
}

# engine_native <config.ini> [引擎参数...]   （cwd=deploy，cookies/cache 落在 deploy/ 下）
engine_native() {
  local cfg="$1"; shift
  ( cd "$HERE" && engine_env && "$(engine_py)" "$HERE/chaoxing/main.py" -c "$cfg" "$@" )
}

panel() {
  # start 已包含全部服务（含管理控制台）与「自动打开控制台」逻辑
  start
}

stop() {
  local sel=() a s
  for a in "$@"; do
    case "$a" in llama) a=llama-server ;; adapter) a=tikuAdapter ;; esac
    sel+=("$a")
  done
  for s in panel bridge tikuAdapter tiku llama-server; do
    wants "$s" "${sel[@]}" && stop_one "$s"
  done
}

status() {
  # 三态：运行中（本套件）/ 端口被其他程序占用 / 未运行
  if ok_has "http://127.0.0.1:$LLAMA_PORT/health" '"status"'; then say "llama-server :$LLAMA_PORT  运行中"
  elif up "http://127.0.0.1:$LLAMA_PORT/"; then say "llama-server :$LLAMA_PORT  端口被其他程序占用"
  else say "llama-server :$LLAMA_PORT  未运行"; fi
  if ok_has "http://127.0.0.1:$TIKU_PORT/" '題庫管理'; then say "题库后台     :$TIKU_PORT  运行中"
  elif up "http://127.0.0.1:$TIKU_PORT/"; then say "题库后台     :$TIKU_PORT  端口被其他程序占用"
  else say "题库后台     :$TIKU_PORT  未运行"; fi
  if ok_has "http://127.0.0.1:$ADAPTER_PORT/" 'chunk-vendors'; then say "tikuAdapter  :$ADAPTER_PORT  运行中"
  elif up "http://127.0.0.1:$ADAPTER_PORT/"; then say "tikuAdapter  :$ADAPTER_PORT  端口被其他程序占用"
  else say "tikuAdapter  :$ADAPTER_PORT  未运行"; fi
  if ok_has "http://127.0.0.1:$BRIDGE_PORT/" 'bridge ok'; then say "题库桥接     :$BRIDGE_PORT  运行中"
  elif up "http://127.0.0.1:$BRIDGE_PORT/"; then say "题库桥接     :$BRIDGE_PORT  端口被其他程序占用"
  else say "题库桥接     :$BRIDGE_PORT  未运行"; fi
  if ok_has "http://127.0.0.1:$PANEL_PORT/" '刷课控制台'; then say "管理控制台   :$PANEL_PORT  运行中"
  elif up "http://127.0.0.1:$PANEL_PORT/"; then say "管理控制台   :$PANEL_PORT  端口被其他程序占用"
  else say "管理控制台   :$PANEL_PORT  未运行"; fi
}

check() {
  local miss=0
  say "== 依赖自检（换新电脑先跑这个） =="
  for c in bash "$PY" curl; do
    if command -v "$c" >/dev/null 2>&1; then say "  [必需] $c             OK"; else say "  [必需] $c             缺失"; miss=1; fi
  done
  if [ -x "$LLAMA_BIN" ]; then say "  [AI  ] llama-server    OK  ($LLAMA_BIN)"; else say "  [AI  ] llama-server    缺失 → $LLAMA_BIN（纯题库模式可无视）"; fi
  if [ -f "$MODEL_PATH" ]; then say "  [AI  ] 模型文件        OK  ($MODEL_PATH)"; else say "  [AI  ] 模型文件        缺失 → $MODEL_PATH（纯题库模式可无视）"; fi
  if [ -f "$TOOLKIT_DIR/tiku/main.py" ]; then say "  [题库] 本地题库后台    OK  ($TOOLKIT_DIR)"; else say "  [题库] 本地题库后台    缺失 → $TOOLKIT_DIR（不存在则启动时跳过该服务）"; fi
  if [ -x "$TIKU_ADAPTER_BIN" ]; then say "  [聚合] tikuAdapter     OK  ($TIKU_ADAPTER_BIN)"; else say "  [聚合] tikuAdapter     缺失 → $TIKU_ADAPTER_BIN（可选，跳过）"; fi
  if engine_ready; then say "  [引擎] 原生           OK（无需 Docker）"
  elif command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then say "  [引擎] docker 回退     OK"; else say "  [引擎] 均不可用        命令行刷课需包内 chaoxing/ 完整"; fi
  if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    if docker image inspect chaoxing:local >/dev/null 2>&1; then
      say "  [选装] 镜像 chaoxing:local  OK"
    elif [ -f docker/chaoxing-local.tar.gz ] || { [ -f chaoxing/Dockerfile ] && [ -d chaoxing ]; }; then
      say "  [选装] 镜像 chaoxing:local  未导入（首次 run 自动导入/构建）"
    else
      say "  [选装] 镜像 chaoxing:local  未找到（无镜像包也无源码，命令行版不可用）"
    fi
  fi
  if command -v node >/dev/null 2>&1 && command -v npm >/dev/null 2>&1; then say "  [选装] node/npm        OK"; else say "  [选装] node/npm        缺失（仅题库后台前端「首次构建」需要）"; fi
  if command -v chromium >/dev/null 2>&1 || command -v chromium-browser >/dev/null 2>&1 || command -v google-chrome >/dev/null 2>&1; then say "  [选装] 浏览器          OK"; else say "  [选装] 浏览器          未找到 chromium/chrome（browser 子命令需要）"; fi
  if [ -d console-dist ]; then say "  [控制] 控制台已构建    OK  (console-dist/)"; else say "  [控制] 控制台未构建    缺失 → 在 console/ 运行: npm install && npm run build"; fi
  say ""
  say "== 配置 =="
  if [ -f deploy.env ]; then say "  deploy.env  已存在（覆盖默认配置）"; else say "  deploy.env  未使用（当前用 deploy.env.example 的默认值）；改路径: cp deploy.env.example deploy.env 再编辑"; fi
  say ""
  say "== 端口 =="
  local p
  for p in "$LLAMA_PORT" "$TIKU_PORT" "$ADAPTER_PORT" "$BRIDGE_PORT" "$PANEL_PORT"; do
    if ss -ltn 2>/dev/null | grep -q ":$p "; then say "  :$p  已监听"; else say "  :$p  空闲"; fi
  done
  say ""
  if [ "$miss" -eq 1 ]; then say "自检：缺少必需组件，请先补齐（见 README-一键部署.md 第二节）"; return 1; fi
  say "自检：必需组件就绪。缺失的可选组件，其服务启动时会自动跳过，纯 AI / 纯题库模式仍可用。"
}

docker_prep() {
  command -v docker >/dev/null 2>&1 || { say "未检测到 Docker（仅命令行自动刷课需要它）"; return 1; }
  docker info >/dev/null 2>&1 || { say "Docker 守护进程未运行，请先启动 Docker 再试"; return 1; }
  if docker image inspect chaoxing:local >/dev/null 2>&1; then
    say "[OK] 刷课镜像 chaoxing:local 已就绪"
    return 0
  fi
  if [ -f docker/chaoxing-local.tar.gz ]; then
    say "正在导入刷课镜像（约 1-2 分钟，下方为加载进度）..."
    if docker load -i docker/chaoxing-local.tar.gz; then say "[OK] 导入完成"; return 0; fi
    say "[!!] 导入失败"
  fi
  if [ -f chaoxing/Dockerfile ]; then
    say "从源码构建镜像（约 2-5 分钟，需联网）..."
    if docker build -t chaoxing:local chaoxing; then say "[OK] 构建完成"; return 0; fi
    say "[!!] 构建失败"
  fi
  say "[!!] 既没有镜像文件也没有源码目录"
  return 1
}

help_text() {
  cat <<'EOF'
学习通本地套件 · 常用命令

  ./onclick.sh start              启动全部服务并自动打开控制台（最常用）
  ./onclick.sh stop               停止全部服务
  ./onclick.sh status             查看五个服务运行状态
  ./onclick.sh check              依赖自检（换新电脑先跑这个）
  ./onclick.sh browser            打开专用浏览器（登录一次免重复登录；脚本需自装）
  ./onclick.sh run                命令行版刷课（不用浏览器）
  ./onclick.sh panel              打开管理控制台
  ./onclick.sh docker             检查/导入刷课镜像
  ./onclick.sh start tiku         单独启动某个服务（llama-server/tiku/tikuAdapter/bridge/panel）
  ./onclick.sh stop  tiku         单独停止某个服务

  完整文档：本目录 README-一键部署.md ｜ 各版改进：CHANGELOG.md
EOF
}

# 判断某个监听进程是否属于本套件（权威判据，避免"自家服务被当成端口冲突"、也避免"残留进程顶替服务"看不出来）
_pid_is_ours() {
  local pid="$1" exe cmd
  [ -n "$pid" ] || return 1
  exe="$(readlink "/proc/$pid/exe" 2>/dev/null)"
  cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)"
  case "$exe $cmd" in
    *"$LLAMA_BIN"*|*"$TIKU_ADAPTER_BIN"*) return 0 ;;
  esac
  case "$cmd" in
    *"$TOOLKIT_DIR"*|*panel.py*|*bridge*.py*|*"$PWD"*) return 0 ;;
  esac
  # 运行态 pid 文件里记录过这个 pid（服务自己写下 PID 后再 exec，命令行可能认不出来）
  cat "$LOG_DIR"/*.pid 2>/dev/null | tr -d '\r\n' | grep -q "$pid" && return 0
  return 1
}

# ---------- doctor：一页「设备体检报告」（可直接复制发给维护者） ----------
# 目的：任何一台设备出问题，都能靠这一页定位到"缺什么、下一步做什么"，而不是猜。
doctor() {
  say "================ 设备体检报告（复制下面整段发给维护者）================"
  local os pretty kern arch nonascii vulkan mem free_gb p line pid pname drift
  # --- 系统 ---
  pretty="$( ( . /etc/os-release 2>/dev/null && printf '%s' "$PRETTY_NAME" ) || echo '未知发行版')"
  say "[系统] $pretty | 内核 $(uname -r) | 架构 $(uname -m)"
  say "[语言] LANG=${LANG:-未设置} LC_ALL=${LC_ALL:-未设置} | 终端编码候选: ${LC_CTYPE:-未设置}"
  # 路径里有没有非 ASCII（Docker 挂载 / 部分工具的老坑）
  nonascii="否"
  printf '%s' "$PWD $HOME" | LC_ALL=C grep -q '[^ -~]' && nonascii="是（可能影响 Docker 挂载与个别工具）"
  say "[路径] 安装目录 $PWD | 家目录 $HOME | 含非ASCII: $nonascii"
  say "[权限] $([ "$(id -u)" = 0 ] && echo "管理员(root)" || echo 普通用户)"
  # --- 运行时 ---
  if command -v "$PY" >/dev/null 2>&1; then say "[Python] $("$PY" -V 2>&1) → $(command -v "$PY")"; else say "[Python] 缺失（题库后台/控制台需要）"; fi
  if command -v docker >/dev/null 2>&1; then
    if docker info >/dev/null 2>&1; then
      say "[Docker] 已装且引擎在跑（$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo '?')）"
      docker image inspect chaoxing:local >/dev/null 2>&1 && say "[Docker] 镜像 chaoxing:local 已就绪" || say "[Docker] 镜像 chaoxing:local 未导入（命令行刷课首次运行会自动导入/构建）"
    else
      say "[Docker] 已装但引擎未启动（仅命令行刷课需要）"
    fi
  else
    say "[Docker] 未安装（仅命令行刷课需要；网页版刷课不受影响）"
  fi
  # --- GPU / 加速 ---
  say "[显卡] $( (lspci 2>/dev/null | grep -iE 'vga|3d controller' | head -2 | sed 's/^[0-9a-f:.]* //') || echo '未识别')"
  vulkan="$(ls /usr/share/vulkan/icd.d/*.json 2>/dev/null | head -3 | xargs -r -n1 basename | tr '\n' ' ')"
  say "[Vulkan] ${vulkan:-未发现 ICD（无 GPU 加速 → AI 建议 CPU 模式: LLAMA_NGL=0）}"
  [ -x "$LLAMA_BIN" ] && say "[AI] llama-server 可执行 ✓" || say "[AI] llama-server 缺失或不可执行 → $LLAMA_BIN"
  [ -f "$MODEL_PATH" ] && say "[AI] 模型文件 ✓ ($(du -h "$MODEL_PATH" 2>/dev/null | cut -f1))" || say "[AI] 模型文件缺失 → $MODEL_PATH"
  # --- 资源 ---
  mem="$(free -h 2>/dev/null | awk '/^Mem:/{print $2" 总 / "$7" 可用"}')"
  say "[内存] ${mem:-未知} | [磁盘] $(df -h "$PWD" 2>/dev/null | awk 'NR==2{print $2" 总 / "$4" 可用"}')"
  local avail_mb
  avail_mb="$(awk '/^MemAvailable:/{printf "%d", $2/1024}' /proc/meminfo 2>/dev/null)"
  [ -n "$avail_mb" ] && [ "$avail_mb" -lt 2048 ] && say "        ⚠ 可用内存不足 2G（$((avail_mb/1024)).$((avail_mb*10/1024%10))G）：AI 与题库可能被系统杀掉，建议先关掉浏览器等占内存的程序"
  # --- 端口占用明细 ---
  # 判据优先级：①监听进程的可执行文件/命令行是否属于本套件 ②运行态 pid 文件是否记录了这个 pid
  # 只用"是不是本套件自己"来区分正常与故障——否则会把自家服务当成"被占用"吓人，也会漏掉残留进程顶替服务的情况。
  say "[端口] 默认端口占用情况："
  for p in "$LLAMA_PORT" "$TIKU_PORT" "$ADAPTER_PORT" "$BRIDGE_PORT" "$PANEL_PORT"; do
    line="$(ss -ltnp 2>/dev/null | grep ":$p " | head -1)"
    if [ -z "$line" ]; then
      say "        :$p 空闲"
    else
      pid="$(printf '%s' "$line" | grep -o 'pid=[0-9]*' | cut -d= -f2 | head -1)"
      pname=""
      [ -n "$pid" ] && pname="$(ps -p "$pid" -o comm= 2>/dev/null)"
      if [ -z "$pid" ]; then
        say "        :$p 被占用（pid 需管理员权限才能看到）"
      elif _pid_is_ours "$pid"; then
        say "        :$p 本套件服务在用（pid=$pid ${pname}）"
      else
        say "        :$p ⚠ 被外部程序/残留进程占用（pid=$pid ${pname:-(未知)}，exe=$(readlink "/proc/$pid/exe" 2>/dev/null || echo '?')）"
        say "              → 该服务没起来；先结束这个占用进程，或让本套件换端口"
      fi
    fi
  done
  # --- 测试/仿真残留进程（会占端口、让"绿"变成假的） ---
  local stray="" d c
  for d in /proc/[0-9]*; do
    c="$(readlink "$d/cwd" 2>/dev/null)" || continue
    case "$c" in *"(deleted)"*|*"/.hermes/cache/scratch/"*|*update-sim*) stray="$stray ${d#/proc/}";; esac
  done
  if [ -n "$stray" ]; then
    say "[残留] ⚠ 发现测试/仿真残留进程:$stray"
    say "        → 它们可能占着端口，让「服务在跑」变成假象；处理: kill$stray"
  else
    say "[残留] 无测试/仿真残留进程 ✓"
  fi
  # --- 网络与时钟（更新通道依赖） ---
  local code t js raw
  js="$(curl -s -o /dev/null -w '%{http_code}|%{time_total}' -m 8 'https://cdn.jsdelivr.net/gh/guish207423-ux/xuexiton-release@main/latest.json' 2>/dev/null)"
  raw="$(curl -s -o /dev/null -w '%{http_code}|%{time_total}' -m 8 'https://raw.githubusercontent.com/guish207423-ux/xuexiton-release/main/latest.json' 2>/dev/null)"
  say "[网络] jsDelivr: ${js:-不可达} | raw.githubusercontent: ${raw:-不可达}（HTTP码|耗时秒）"
  drift="$(_clock_drift)"
  say "[时钟] 与联网时间偏差: ${drift:-未能测出（网络不通？）}"
  # 更新源
  local feed fixed
  feed="$(grep -E '^\s*UPDATE_FEED\s*=' deploy.env 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '\r')"
  say "[更新源] ${feed:-未在 deploy.env 配置（将使用内置默认源）}"
  say ""
  say "---------------- 结论与下一步 ----------------"
  local ladder=1
  if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    say "· 命令行刷课：可用（Docker 就绪）"
  elif command -v "$PY" >/dev/null 2>&1; then
    say "· 命令行刷课：本机无 Docker → 先用【网页版刷课】；想要命令行版请装 Docker Desktop（Win10 21H2+ / WSL2），或走浏览器脚本兜底"
    ladder=2
  else
    say "· 命令行刷课：本机无 Python 也无 Docker → 只能用【网页版刷课】/ 浏览器脚本兜底"
    ladder=3
  fi
  if [ -f "$TOOLKIT_DIR/tiku/main.py" ]; then
    [ -x "$TOOLKIT_DIR/tiku/.venv/bin/python" ] && say "· 本地题库后台：依赖已装好，可用" || say "· 本地题库后台：缺少依赖（首次启动会联网 pip 安装；离线设备请预装 python3 依赖）"
  else
    say "· 本地题库后台：未找到 → $TOOLKIT_DIR"
  fi
  [ -n "$vulkan" ] && say "· AI 答题：检测到 Vulkan，可用 GPU 加速" || say "· AI 答题：未检测到 Vulkan → 请把 LLAMA_NGL 改为 0 走 CPU（慢但可用），或只用题库"
  say "· 更新通道：jsDelivr ${js%%|*} / raw ${raw%%|*}（非 200 时改走另一条或 U 盘离线包）"
  say "（降级层级：$ladder —— 1=全功能，2=无 Docker，3=仅网页版/浏览器脚本）"
  say "================================================================"
}

# 时钟偏差（拿 HTTP Date 头对比本地时间；用于排查"更新失败其实是时间不对"）
_clock_drift() {
  local remote local_s r
  r="$(curl -sI -m 8 https://cdn.jsdelivr.net 2>/dev/null | awk 'tolower($1)=="date:"{print $2,$3,$4,$5,$6}' | head -1)"
  [ -n "$r" ] || return 1
  remote="$(date -u -d "${r% GMT} GMT" +%s 2>/dev/null)" || return 1
  local_s="$(date -u +%s)"
  local d=$(( local_s - remote ))
  if [ "${d#-}" -le 5 ]; then printf '正常（%+d 秒）' "$d"; else printf '偏差 %+d 秒%s' "$d" "$([ "${d#-}" -gt 300 ] && printf ' ⚠ 过大，会导致更新/联网失败（请校准系统时间）')"; fi
}

case "${1:-start}" in
  help|-h|--help) help_text ;;
  start)  [ $# -gt 0 ] && shift; start "$@" ;;
  stop)   [ $# -gt 0 ] && shift; stop "$@" ;;
  status)  status ;;
  check)  check ;;
  doctor|体检|report) doctor ;;
  browser) browser ;;
  run)    run ;;
  panel)  panel ;;
  docker) docker_prep ;;
  *) say "用法: $0 start|stop [服务名...] | status | check | doctor | browser | run | panel | docker | help" ;;
esac
